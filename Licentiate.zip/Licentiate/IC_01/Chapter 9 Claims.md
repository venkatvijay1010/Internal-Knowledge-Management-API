### &nbsp;                                         Chapter 9 Claims

&nbsp;                                                                            LO (a): Importance of Claims Settlement



---



---



\### 1. Purpose of Insurance

\- Core Purpose: Insurance exists to provide financial relief when a covered loss occurs.

\- Moment of Truth: The claim stage is when the insurer’s credibility is tested — customers expect timely and fair help.



---



\### 2. Insured Event

\- A claim arises only when an insured event occurs.

\- Usually unexpected (accident, fire, theft).

\- Special case: In Life Insurance, policy maturity is also an insured event (not a “loss” but still payable).



---



\### 3. Examples of Insured Events

\- Death of life assured.

\- Fire in warehouse, earthquake damage.

\- Ship collision, cargo damage (marine).

\- Motor accident (own damage or third-party).

\- Burglary/dacoity in transit.

\- Court award under product liability.

\- Cyber-attack under cyber insurance.



---



\### 4. Common Factor in Claims

All claims arise from loss due to an insured peril.  

Insurer must check:

1\. Did a real loss occur?

2\. Was it caused by an insured peril?

3\. Is the claim payable? If yes, how much? (admissibility + quantum).



---



\### 5. Principle of Indemnity

\- General Insurance: Restore insured to same financial position as before loss — no profit.

\- Life Insurance: Different — pays a fixed sum (benefit contract).



---



\### 6. Deductions That Reduce Claim Payment

\- Depreciation: Deduction for wear \& tear.

\- Deductible/Excess: Part of claim borne by insured.

\- Underinsurance / Average Clause: If sum insured < actual value → proportionate settlement.

\- Other deductions: Policy exclusions, limits, salvage value.



---



&nbsp;                                                                                 LO (b): Different Stages of the Claims Process



---



\## 1. Start: Insured Event → Intimation

\- Trigger: Claim starts when an insured event (operation of insured peril) causes a loss and insured notifies insurer.

\- Examples: Death, fire, earthquake, cargo damage, motor accident, burglary, cyber-attack.

\- Immediate intimation required (policy condition):

&nbsp; - Preserves evidence.

&nbsp; - Enables insurer to advise on loss minimisation.

&nbsp; - Helps salvage and reserve creation.

\- Delay: Should not lead to mechanical repudiation if beyond insured’s control (condonable).



---



\## 2. Surveyor Appointment (Loss Assessor)

\- Purpose: Independent inspection and reporting.

\- Regulation: IRDAI-licensed surveyors under Section 64UM.

\- Thresholds:  

&nbsp; - General claims > ₹100,000.  

&nbsp; - Motor claims > ₹50,000.  

&nbsp; - Exemptions apply (see section 6).

\- Timeline: Appointment within 72 hours of intimation.



---



\## 3. Loss Assessment (Surveyor’s Duties \& Timing)

\- Duties (IRDAI Surveyors Regulations):

&nbsp; 1. Investigate cause \& circumstances.

&nbsp; 2. Assess extent of loss, ownership, insurable interest.

&nbsp; 3. Comment on admissibility.

&nbsp; 4. Give reasons for repudiation (if recommended).

\- Practical steps: Site inspection, document review, interviews, evidence collection.

\- Report timeline: Within 30 days of receiving all info.



---



\## 4. Insurer’s Decision (Liability + Quantum)

\- Final decision rests with insurer, not surveyor.

\- Insurer may accept, reduce, or reject surveyor’s figure — but must record reasons for deviation.



---



\## 5. Admissibility — Core Checklist

Insurer verifies 4 main aspects:



\### A. Coverage

\- Date of loss: Within policy period.  

&nbsp; - Complexities: Marine transit (uncertain date), Liability (Occurrence vs Claims-Made), Discovery basis.

\- Subject matter: What is insured (goods, spares, named items vs floater).

\- Insurable interest: Claimant must have interest (life nominees, bailees, creditors, group covers).

\- Location \& jurisdiction: Property policies often location-specific; liability policies have jurisdiction clauses.



\### B. Operating Peril

\- Named-peril policy: Insured must prove loss caused by listed peril.

\- All-risks policy: Insured shows accidental/unforeseen loss; insurer must prove excluded peril to deny.



\### C. Compliance with Conditions/Warranties

\- Conditions precedent: Timely intimation, due diligence, info submission, preserve recovery rights.

\- Reasonable care vs recklessness: Negligence ≠ automatic denial; recklessness may void cover.

\- Warranties: Strict compliance (e.g., no hazardous goods, armed guards for cash-in-transit).



\### D. Rejection Protocol

\- Clear grounds in writing; no new grounds after rejection letter.

\- Fraud: Report to regulator and insurers.

\- Nondisclosure/misrepresentation: Policy cancellation possible.



---



\## 6. Special Operational Rules \& Exemptions

\- Surveyor report exemptions:  

&nbsp; - Motor third-party, General Average, short landing, certain marine cargo claims, Liability, Health, Crop, Burglary, Money-in-Transit, Credit.

\- Thresholds:  

&nbsp; - General > ₹100,000; Motor > ₹50,000.



---



\## 7. Timeframes \& Paperwork

\- Surveyor appointment: 72 hours.

\- Surveyor report: 30 days after info receipt.

\- Documents: Claim form, FIR, invoices, ownership proof, photos, repair estimates, medical records, court orders, transport docs.



---



\## 8. Post-Decision Actions

\- Settlement: Payment or cashless repair.

\- Salvage \& recovery: Insurer may take salvage; “pay \& recover” scenarios (e.g., motor TP).

\- Loss data analysis: Feed into underwriting, product design, fraud detection.

\- Agency appraisal: Evaluate surveyors, TPAs, advocates.



---



\## 9. Key Exam Clarifications

\- All-Risks vs Named-Peril: Burden of proof differs.

\- Occurrence vs Claims-Made: Timing of event vs timing of claim.

\- Surveyor’s report ≠ binding: Insurer decides but must justify deviations.



---



✅ Summary in One Line:  

Claims process = Intimation → Surveyor → Assessment → Admissibility checks → Decision → Settlement → Post-loss actions.



---





---



&nbsp;                                                                       **LO (c): How Quantum of Claims Payable is Determined**



---



\## 1. Meaning of Quantum

\- Quantum = final amount payable by insurer for a valid claim.

\- Not just arithmetic — depends on:

&nbsp; - Policy terms: sum insured, conditions, exclusions.

&nbsp; - Extent of actual loss.

&nbsp; - Deductions \& adjustments: depreciation, deductibles, salvage.

\- Objective: Apply Principle of Indemnity → restore insured to original financial position (no profit).



---



\## 2. Basis of Settlement

Insurer determines how to value the loss using these factors:



\### (i) Sum Insured vs Value at Risk

\- Value at Risk: Actual value of property at time of loss.

\- If Sum Insured < Value at Risk, underinsurance applies (Average Clause):

&nbsp; \\\[

&nbsp; \\text{Payout} = \\frac{\\text{Sum Insured}}{\\text{Value at Risk}} \\times \\text{Loss Amount}

&nbsp; \\]

\- Example:  

&nbsp; Property value = ₹10 lakh; Sum insured = ₹5 lakh; Loss = ₹2 lakh  

&nbsp; Payout = (5/10) × 2 lakh = ₹1 lakh.



---



\### (ii) Depreciation

\- Deduction for wear \& tear / usage.

\- Example: 5-year-old machine destroyed → insurer pays depreciated value, not cost of new machine.

\- Applies in fire, motor (without zero-dep add-on), property covers.



---



\### (iii) Deductibles / Excess

\- Fixed amount or % borne by insured per claim.

\- Example: Deductible ₹25,000 → insurer pays claim minus ₹25,000.

\- Purpose: Avoid small claims, reduce moral hazard.



---



\### (iv) Salvage

\- Value of damaged property that can be sold/used.

\- Insurer either takes salvage or deducts its value from claim.

\- Example: Car wreck resale value deducted from settlement.



---



\### (v) Other Adjustments

\- Additions: Firefighting expenses, debris removal costs.

\- Exclusions: Profit margins, improved performance of replacements, dead stock, uncovered items.



---



\## 3. Role of Documents \& Evidence

\- Required for loss assessment:  

&nbsp; - Photos/videos, fire brigade or weather reports.

&nbsp; - Invoices, books of accounts, excise records.

\- Purpose: Prevent fraud, substantiate claim.

\- Surveyor \& insurer cross-check before approval.



---



\## 4. Payment Considerations

\- If bank/financier has interest (mortgage, hypothecation), settlement must include their name or consent.

\- Protects lender’s rights.



---



\## 5. Key Principles for Exams

\- Formula:  

&nbsp; \\\[

&nbsp; \\text{Quantum} = \\text{Admissible Loss} - (\\text{Depreciation} + \\text{Deductible} + \\text{Underinsurance Adjustment} + \\text{Salvage} + \\text{Exclusions}) + \\text{Allowed Extra Costs}

&nbsp; \\]

\- Indemnity principle: No profit, no extra gain.

\- Evidence is critical.

\- Policy basis matters:  

&nbsp; - Reinstatement basis: Replacement cost without depreciation (if conditions met).  

&nbsp; - Market value basis: Deduct depreciation.



---



✅ In Short:  

Quantum = amount payable after applying policy terms, adjusting for underinsurance, depreciation, deductibles, salvage, exclusions, and adding genuine extra costs. Must be evidence-backed and respect financier’s interest.



---



