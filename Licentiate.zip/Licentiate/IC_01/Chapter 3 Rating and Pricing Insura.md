###                  Chapter 3: Rating and Pricing Insurance Products

                                                  Learning Outcome (a): Elements of Cost of Insurance Product:



---

\## ✅ Why Pricing is Difficult

\- For most products: Cost is known before sale.

\- For insurance:

  - Policy is sold first → Cost (claims) comes later.

  - Claims may arise years after sale (long-tail risk).

  - Insurer cannot ask for extra premium later → Pricing must be accurate.



---



\## ✅ Four Components of Price (Premium)



\### 1. Burning Cost (Pure Premium)

\- Definition: Expected cost of claims (net of recoveries).

\- Formula:

  Burning Cost = Frequency × Severity

\- Severity:

  Severity = Total Claim Amount ÷ Number of Claims

\- Adjustments:

  + Add: Survey costs, legal costs

  − Subtract: Salvage, subrogation, reinsurance recoveries



---



\### 2. Acquisition Costs

\- Cost of acquiring business:

  - Commissions

  - Brokerage

  - Aggregator fees

  - Medical tests (health insurance)



---



\### 3. Operating Expenses

\- Administrative costs:

  - Salaries

  - IT systems

  - Rent

  - Claims handling overheads

  - Regulatory costs



---



\### 4. Profit (Margin)

\- Provides:

  - Buffer for uncertainty

  - Return for shareholders



---



\## ✅ Correct Formula for Premium

\- Loadings (Acquisition + Operating + Profit) are % of Premium, not of Burning Cost.

  Premium = Burning Cost ÷ (1 − Total Loading%)



---



\### Example

\- Burning Cost = ₹1,000

\- Acquisition = 15%, Opex = 20%, Profit = 10%

\- Total Loading = 45%

  Premium = 1000 ÷ (1 − 0.45) = 1000 ÷ 0.55 ≈ ₹1,818



---



\## ✅ Exam-Ready Bullets

\- 4 elements: Burning Cost + Acquisition + Operating + Profit

\- Burning Cost = Frequency × Severity

\- Premium = BC ÷ (1 − Total Loading%)

\- Wrong way: Don’t just “add % to BC”

\- Pricing must balance:

  - Fairness

  - Competition

  - Solvency



---

                                                                                   Learning Outcome (b)

                                                                Frequency, Severity \& Their Relationship to Burning Cost



---



\## ✅ Paragraph 1 – What is Burning Cost?

\- Definition:

  Burning Cost (or Pure Premium) = Insurer’s ultimate claims cost for the risks underwritten.

\- Includes:

  + Gross claim payments

  + Claim-related costs (survey, legal)

  − Salvage, subrogation, reinsurance recoveries

\- Ultimate Claims Cost:

  Final net burden after all adjustments and late developments.

\- Why Important:

  Burning Cost is the first ingredient in pricing (before adding acquisition, operating, and profit loadings).



---



\### Technical Terms

\- Burning Cost / Pure Premium = Expected claim cost per exposure (net of recoveries + claim admin).

\- Salvage = Value recovered from damaged property.

\- Subrogation = Insurer’s right to recover from third party responsible for loss.

\- Reinsurance Recoveries = Amounts reimbursed by reinsurers.



---



\## ✅ Paragraph 2 – Two Elements of Burning Cost

\- Burning Cost is built from:

  - Frequency = How often losses occur.

  - Severity = How large each loss is on average.

\- Formula:

  Burning Cost = Frequency × Severity



---



\## ✅ Paragraph 3 – Frequency

\- Definition: Rate of losses per exposure unit.

\- Formula:

  Frequency = Number of losses ÷ Number of exposure units

\- Exposure Unit: The unit of risk (e.g., person, vehicle, consignment, life).

\- Example:

  150 accidents across 10,000 vehicles →

  Frequency = 150 ÷ 10,000 = 0.015 = 1.5%



---



\## ✅ Paragraph 4 – Severity

\- Definition: Average amount paid per loss.

\- Formula:

  Severity = Total amount of losses ÷ Number of losses

\- Notes:

  - Use net amounts (after deductibles, limits, salvage).

  - Life insurance: severity often fixed (sum assured).

  - Non-life: severity varies → must average.



---



\## ✅ Paragraph 5 – How Frequency × Severity = Burning Cost

Start with:

Frequency = # losses ÷ # exposures

Severity = Total losses ÷ # losses

Multiply:

Burning Cost = ( # losses ÷ # exposures ) × ( Total losses ÷ # losses )

Cancel # losses →

Burning Cost per exposure = Total losses ÷ Total exposure units



---



\## ✅ Paragraph 6 – Worked Example

\- Data:

  10,000 cars, theft cover only

  Each car = ₹5,00,000

  5 thefts in period

\- Step 1 – Frequency:

  5 ÷ 10,000 = 0.0005 = 0.05%

\- Step 2 – Severity:

  Total losses = 5 × ₹5,00,000 = ₹25,00,000

  Severity = ₹25,00,000 ÷ 5 = ₹5,00,000

\- Step 3 – Burning Cost:

  0.0005 × ₹5,00,000 = ₹250

\- Direct Method:

  ₹25,00,000 ÷ 10,000 = ₹250

Interpretation: ₹250 per car covers past-year losses (ignoring loadings).



---



\## ✅ Paragraph 7 – Real-World Adjustments

\- Add: Claim-handling costs (survey, legal).

\- Subtract: Salvage, subrogation, reinsurance recoveries.

\- Include: IBNR (Incurred But Not Reported) for long-tail lines.

\- Adjust for claim development and reserves.



---



\## ✅ Paragraph 8 – Loss Volatility \& Pricing

\- Two products can have same Burning Cost but different standard deviation (SD).

\- Higher SD → higher uncertainty → need extra margin.

\- Exam Tip: If asked “why charge more even if BC same?” → Answer: higher volatility.



---



\## ✅ Paragraph 9 – Data Selection \& Practical Cautions

\- Use representative periods (avoid outliers like catastrophes without adjustment).

\- Consistent exposure definition.

\- Adjust old data for inflation/trend.

\- Handle outliers (cap or model separately).



---



\## ✅ Paragraph 10 – Practice Examples

1\. Employee Example:

   Total claims = ₹30,00,000; Exposure = 5,000 employees

   Burning Cost = ₹30,00,000 ÷ 5,000 = ₹600

2\. Health Product Example:

   Burning Cost = ₹1,500; Medical = ₹300; Loadings = 25%

   Effective BC = ₹1,800

   Premium = ₹1,800 ÷ (1 − 0.25) = ₹2,400



---



\### ✅ Exam-Ready Summary

\- Burning Cost = Frequency × Severity

\- Frequency = Losses ÷ Exposure Units

\- Severity = Total Loss Amount ÷ Losses

\- BC per exposure = Total Loss Amount ÷ Exposure Units

\- Adjust for claim costs, recoveries, IBNR.

\- Higher volatility → higher margin.

\- Common pitfalls: inconsistent exposure, ignoring inflation, ignoring IBNR.



---



                                                           Learning Outcome (c): Pricing Computed from Burning Cost



---



\## 1. Burning Cost is the Base

\- Burning Cost (BC) = expected claims cost per exposure.

\- It is the starting point for premium calculation.

\- Insurers cannot stop at BC because they also have:

  - Acquisition costs

  - Operating expenses

  - Profit margin



---



\## 2. Loadings to Add

To convert Burning Cost into the Final Premium, insurers add:

1\. Acquisition Costs – commission, brokerage, marketing, medical exams

2\. Operating Expenses – salaries, IT, office, regulatory costs

3\. Profit Margin – to reward shareholders and cover uncertainty



---



\## 3. Correct Formula for Premium

Since expenses and profit are % of Premium (not % of BC):

Premium = (Burning Cost + Fixed Costs) ÷ (1 − Total Loading%)



Where:

\- Total Loading% = Acquisition% + Operating% + Profit%

\- Fixed costs (e.g., medical check-up fee per policy) are added to BC before applying the formula



---



\## 4. Example 1 – Simple Loading

\- Burning Cost = ₹1,000

\- Acquisition = 15%, Opex = 20%, Profit = 10%

\- Total Loading = 45%

Premium = 1,000 ÷ (1 − 0.45) = 1,000 ÷ 0.55 ≈ ₹1,818



---



\## 5. Example 2 – With Fixed Costs

\- BC = ₹1,500

\- Fixed medical test = ₹300

\- Adjusted BC = 1,500 + 300 = ₹1,800

\- Loadings: 7% + 15% + 3% = 25%

Premium = 1,800 ÷ (1 − 0.25) = 1,800 ÷ 0.75 = ₹2,400



---



\## 6. Common Mistake

\- ❌ Wrong way: simply add % of BC

  Example: 1,000 + 45% = 1,450 (Incorrect)

\- ✔ Correct way: divide BC by (1 − loading%)



---



\## 7. Key Technical Terms

\- Burning Cost = pure premium, expected claims cost

\- Loadings = % added to cover expenses and profit

\- Gross Premium = BC ÷ (1 − loadings)

\- Ultimate Claims Cost = BC adjusted for salvage, subrogation, reinsurance, and admin costs



---



\## ✅ Exam-Friendly Summary

\- Premium starts from Burning Cost

\- Add fixed per-policy costs to BC

\- Apply formula:

  Premium = Adjusted BC ÷ (1 − Total Loading%)

\- Remember worked examples:

  - ₹1,818 (simple)

  - ₹2,400 (with fixed cost)

