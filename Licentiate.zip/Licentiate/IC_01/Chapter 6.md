### &nbsp;                                  Chapter 6 — LO (a): SUBROGATION



-----------------------------------------------------------------------------------------------



Paragraph A — Opening: link to Indemnity



PDF idea (short): Subrogation (and Contribution) are corollaries of the Principle of Indemnity: insured must be compensated, but never more than the loss.



Line-by-line explanation



“Corollaries of Indemnity” — means these principles naturally follow from indemnity’s goal (no double recovery, fair sharing).



Why mention indemnity first? Because if indemnity says “no profit”, subrogation and contribution are legal tools that stop double-recovery (insured receiving insurer compensation and full recovery from the party who caused the loss).





Technical term: Corollary = a consequence that logically follows from something already established.



Exam tip: Always open your answer by linking Subrogation → Indemnity (short phrase: “Subrogation enforces indemnity by preventing double recovery”).





-----------------------------------------------------------------------------------------------



Paragraph B — Problem Statement (double recovery possibility)



PDF idea (short): There are occasions where an insured could (in theory) get paid by insurer and recover from the third party who caused the loss — Subrogation prevents this.



Line-by-line explanation



“In theory, yes … in practice, no” — legally an injured person may have multiple remedies (insurance and third-party suit), but allowing both without limits would let the insured profit.



The principle ensures the insured’s recovery does not exceed the actual loss.





Example to keep in head: If your car is damaged and you get ₹1,00,000 from insurer, you shouldn’t be able to get ₹1,00,000 again from the negligent driver. Subrogation transfers the right to recover from that negligent driver to the insurer.



Exam tip: Write the “in theory yes / in practice no” line and give a one-line example — saves marks.





-----------------------------------------------------------------------------------------------



Paragraph C — Definition of Subrogation (core)



PDF idea (short): Subrogation = transfer of the insured’s rights against the third party (who caused the loss) to the insurer who paid the claim.



Line-by-line explanation



“Transfer of rights” — after insurer indemnifies (pays) the insured, the insured’s legal claim (for compensation against the wrongdoer) is assigned to the insurer.



Purpose: insurer can pursue the third party to recover the amount it paid — this prevents the insured collecting twice.



Timing: subrogation normally follows payment (insurer gets the right when it pays), but there are exceptions (policy clauses — see later).





Technical term: Indemnify = pay/compensate the insured for a covered loss.



Exam tip: Memorise a crisp definition: “Subrogation = insurer steps into insured’s shoes to recover from the third party after indemnity.” Use that as your opening sentence in exams.





-----------------------------------------------------------------------------------------------



Paragraph D — Rekha example (concrete walk-through)



PDF text essence: Rekha insured her car with Murphy Insurance; Rocky hit her car. Murphy pays Rekha; before settling Murphy asks Rekha to transfer her rights against Rocky; Murphy then sues Rocky to recover.



Line-by-line explanation



1\. Rekha insured with Murphy — establishes insured-insurer contract.





2\. Rocky negligently hits Rekha’s car — third-party tort/ negligence created a separate right against Rocky.





3\. Murphy compensates Rekha — insurer fulfils indemnity.





4\. Murphy asks Rekha to transfer her rights — insurer requires assignment/authorization so insurer can pursue Rocky. This is the practical step that effects subrogation.





5\. Murphy sues Rocky (as powerholder) — insurer does not gain a new independent cause of action; it enforces Rekha’s existing rights (see rules below).







Important legal nuances (lines the book emphasises):



Insurer has no original right of action — only Rekha had that right; insurer enforces it as powerholder after Rekha transfers rights.



Recovery cap: insurer can keep only up to what it paid. If insurer recovers more than it paid, the excess must be returned to Rekha. If insurer recovers less, insured gets no further benefit (insurer’s recovery compensates insurer’s outflow).





Example with numbers (common exam style):



Insurer paid Rekha ₹1,50,000. Later insurer recovers ₹2,00,000 from Rocky → insurer keeps ₹1,50,000; gives ₹50,000 to Rekha. If insurer recovered ₹1,00,000 only, insurer keeps ₹1,00,000 (insured already had ₹1,50,000 from insurer).





Exam tip: Use Rekha’s story (who, what, when) — short, crisp: “Rekha → Murphy → Rocky; insurer sues as powerholder; honours excess rule.”





-----------------------------------------------------------------------------------------------



Paragraph E — How subrogation arises — (overview + 4 sources)



PDF structure: The chapter lists the ways a right of action (that can be subrogated) may arise — Tort, Contract, Statute, and Subject matter recovery. Each is a separate paragraph; I’ll treat each in order and explain every line.





-----------------------------------------------------------------------------------------------



E.1 — Right arising under TORT



PDF excerpt (short): Tort = civil wrong; duty of care; negligent breach → victim has right vs tortfeasor; that right is subrogated to insurer once insurer pays.



Line-by-line explanation



Tort = civil wrong — not criminal; civil remedy is compensation.



Duty of care — every person must act so as not to harm others; breach creates liability.



Victim’s right — the injured person has a cause of action for compensation against the negligent person (tortfeasor).



Subrogation: after insurer indemnifies the victim, insurer may step into victim’s shoes and pursue the tortfeasor.





Concrete example: road accidents — driver A negligently hits B’s car; B’s insurer pays B; insurer sues A for recovery.



Exam tip: When asked “Give examples where subrogation arises by tort”, say: motor third-party, carrier negligence, workplace accidents (if negligence by a third party), etc.





Thanks for sharing everything, Vijay! Here's a clean, structured version of Chapter 6 — Learning Outcome (a): Subrogation, formatted for clarity and exam-readiness. You can use this for notes, assignments, or even convert it into a PDF or presentation later.



-----------------------------------------------------------------------------------------------



\# Chapter 6 — LO (a): Subrogation



-----------------------------------------------------------------------------------------------



\## A. Introduction: Link to Indemnity



\- Subrogation is a corollary of the Principle of Indemnity.

\- Indemnity ensures the insured is compensated for loss but not allowed to profit.

\- Subrogation prevents double recovery — insured cannot recover from both insurer and third party.



> 🧠 Exam Tip: Start with — \*“Subrogation enforces indemnity by preventing double recovery.”\*



-----------------------------------------------------------------------------------------------



\## B. Problem Statement: Double Recovery Possibility



\- In theory, insured could claim from insurer and sue the third party.

\- In practice, Subrogation stops this — insurer steps into insured’s shoes after payment.



> 💡 Example: Car damage — insurer pays ₹1,00,000 → insured cannot also recover ₹1,00,000 from negligent driver.



> 🧠 Exam Tip: Use the phrase — \*“In theory yes, in practice no”\* + one-line example.



-----------------------------------------------------------------------------------------------



\## C. Definition of Subrogation



\- Subrogation = transfer of insured’s rights against third party to insurer after indemnity.

\- Insurer can recover from third party to offset payout.



> 📘 Definition: \*“Subrogation = insurer steps into insured’s shoes to recover from third party after indemnity.”\*



> 🧠 Exam Tip: Memorize this crisp definition.



-----------------------------------------------------------------------------------------------



\## D. Rekha Example (Concrete Walkthrough)



1\. Rekha insured with Murphy.

2\. Rocky hits Rekha’s car (negligence).

3\. Murphy pays Rekha.

4\. Rekha transfers rights to Murphy.

5\. Murphy sues Rocky.



> 📌 Legal Nuances:

\- Insurer sues as powerholder, not in own name.

\- Recovery cap: insurer keeps only what it paid; excess goes to insured.



> 💰 Example:

\- Paid ₹1,50,000 → recovered ₹2,00,000 → ₹50,000 returned to Rekha.



> 🧠 Exam Tip: Use short story — \*“Rekha → Murphy → Rocky; insurer sues as powerholder; honours excess rule.”\*



-----------------------------------------------------------------------------------------------



\## E. Sources of Subrogated Rights



\### E.1 — Tort



\- Civil wrong → duty of care breached → victim has right.

\- Insurer pays victim → steps into victim’s shoes.



> 🚗 Example: Road accident — insurer pays → sues negligent driver.



> 🧠 Exam Tip: Mention motor third-party, carrier negligence, workplace accidents.



-----------------------------------------------------------------------------------------------



\### E.2 — Contract



\- Contractual liability (e.g., tenancy clause).

\- Insurer pays → takes over contractual claim.



> 🧠 Exam Tip: Use tenancy example — \*“Tenant liable → insurer sues after indemnity.”\*



-----------------------------------------------------------------------------------------------



\### E.3 — Statute



\- Statutes impose liability (e.g., Carriage of Goods by Road Act).

\- Insurer pays → sues under statutory right.



> 🧠 Exam Tip: Memorize one statute — \*Carriage of Goods by Road Act\*.



-----------------------------------------------------------------------------------------------



\### E.4 — Subject Matter Recovery



\- Insured property recovered after claim → insurer owns proceeds.

\- Example: Neeta’s watch shop burglary → recovered watches sold by insurer.



> 🧠 Exam Tip: Use burglary + recovered loot example.



-----------------------------------------------------------------------------------------------



\## F. Timing of Subrogation



\- Default: arises after payment.

\- Exception: policy clauses allow pre-payment subrogation (e.g., sale of damaged goods).



> 🧠 Exam Tip: Use phrase — \*“Usually after payment, but policy clauses may allow pre-payment subrogation.”\*



-----------------------------------------------------------------------------------------------



\## G. Waiver of Subrogation Rights



\### 1. Knock-for-Knock Agreement

\- Insurers agree not to sue each other (motor fleet practice).



\### 2. Principal–Contractor Waiver

\- Contractor asks principal to get waiver clause in insurance policy.



> 🧠 Exam Tip: Mention both waivers + reason: \*“Avoid litigation; commercial risk allocation.”\*



-----------------------------------------------------------------------------------------------



\## H. Legal Limits on Subrogation



\- No greater rights than insured had.

\- Recovery capped at amount paid.

\- Insurer sues as powerholder, not in own name.



> 🧠 Exam Tip: Use bullet format for these three limits.



-----------------------------------------------------------------------------------------------



&nbsp;                                                                                          Learning Outcome (b): Contribution



---



\## 1. What is Contribution? — Definition + Simple Examples



Definition:  

Contribution is a principle that supplements Indemnity. It applies when more than one indemnity policy covers the same loss and ensures the insured does not recover more than the actual loss by forcing insurers to share the loss.



\### 🔍 Line-by-Line Explanation:

\- “Supplementary to Indemnity”: Contribution enforces the same idea — no over-compensation.

\- If multiple indemnity contracts cover the same loss, insurers divide the payout so the insured gets only the actual loss.



\### 📊 Examples:

\- Example 1 (Equal Sums):  

&nbsp; Vehicle insured ₹10,00,000 with Insurer U and ₹10,00,000 with Insurer V.  

&nbsp; Loss = ₹10,00,000 → Each insurer pays ₹5,00,000.



\- Example 2 (Pro Rata Sums):  

&nbsp; Stock value ₹5,00,000; Insurer K = ₹3,00,000; Insurer L = ₹2,00,000.  

&nbsp; Loss = ₹1,00,000 → K pays ₹60,000, L pays ₹40,000.



\### 📐 Formula (No Underinsurance):

If total Sums Insured = T, insurer i’s Sum Insured = Sᵢ, and loss = L:  

insurerᵢ pays = L × (Sᵢ / T)



---



\## 2. Requirements for Contribution — The Five Conditions



All five must be met for contribution to apply:



\### ✅ Conditions Explained:

1\. Two or more Policies of Indemnity exist  

&nbsp;  - Must be indemnity policies (e.g., fire, motor).  

&nbsp;  - No contribution for benefit policies (e.g., life, personal accident).



2\. Policies cover a common interest  

&nbsp;  - Must insure the same legal/financial interest.  

&nbsp;  - Different interests → no contribution.



3\. Policies cover a common subject-matter  

&nbsp;  - Must insure the same physical item (e.g., stock, building).  

&nbsp;  - Different subject matter → no contribution.



4\. Loss caused by a Peril covered by all Policies  

&nbsp;  - All policies must cover the same cause of loss.  

&nbsp;  - If one doesn’t cover the peril → no contribution.



5\. Policies are liable for the loss  

&nbsp;  - If a policy is excluded or repudiated → it doesn’t contribute.



> 🧠 Exam Tip: Use these five as a checklist in short answers.



---



\## 3. Contribution with Underinsurance — Step-by-Step + Examples



\### 🔢 Definitions:

\- V = Value at Risk  

\- Sᵢ = Sum Insured with insurer i  

\- T = Total Sums Insured  

\- L = Loss amount



---



\### 📘 Case A: No Underinsurance (T ≥ V)

Use formula:  

insurerᵢ pays = L × (Sᵢ / T)



Example:  

V = ₹4,00,000; Vishal = ₹3,00,000; Vaishali = ₹1,00,000; L = ₹2,00,000  

T = ₹4,00,000 → No underinsurance  

\- Vishal pays = ₹2,00,000 × (3/4) = ₹1,50,000  

\- Vaishali pays = ₹2,00,000 × (1/4) = ₹50,000



---



\### 📘 Case B: Underinsurance (T < V)

Use formula:  

insurerᵢ pays = L × (Sᵢ / V)



Example:  

V = ₹5,00,000; Vishal = ₹3,00,000; Vaishali = ₹1,00,000; T = ₹4,00,000; L = ₹2,00,000  

\- Vishal pays = ₹2,00,000 × (3/5) = ₹1,20,000  

\- Vaishali pays = ₹2,00,000 × (1/5) = ₹40,000  

\- Total paid = ₹1,60,000 (less than loss due to underinsurance)



---



\### 🧠 Equivalent Viewpoint:

\- Compute total payable: L × (T / V)  

\- Then split among insurers: (Sᵢ / T)  

\- Both methods give same result.



\### 📌 Compact Formulas:

\- If T ≥ V: insurerᵢ pays = L × (Sᵢ / T)  

\- If T < V: insurerᵢ pays = L × (Sᵢ / V)



---



\## 4. Exceptions to Contribution — Common Exam Traps



\### ❗ Exceptions:

1\. Marine Insurance  

&nbsp;  - Section 34(2)(a): insured can claim from any insurer in any order (total ≤ indemnity).



2\. Health Insurance (India)  

&nbsp;  - Standard clause allows insured to choose insurer.  

&nbsp;  - Example: Guru has two ₹10L policies → can claim full ₹2L from one insurer.



3\. Benefit Policies  

&nbsp;  - No contribution applies.  

&nbsp;  - Example: Anita has two ₹50L life policies → both pay full amount.



> 🧠 Exam Tip: Mention these three exceptions clearly.



---



\## 5. Quick Worked Sample (MCQ Style)



Scenario:  

Sanjay insured goods with Ratan ₹20,00,000 and Rashmi ₹30,00,000.  

Value at risk = ₹75,00,000; Loss = ₹45,00,000



Underinsurance: T = ₹50,00,000 < V → use:  

Rashmi pays = L × (Sᵢ / V)  

= ₹45,00,000 × (30,00,000 / 75,00,000)  

= ₹45,00,000 × 0.4 = ₹18,00,000



✅ Correct answer = ₹18,00,000



---

&nbsp;                                                                                                                                                                                     Learning Outcome (c): Understand the Principle of Proximate Cause



---



\## 1. Introduction – What is Proximate Cause?



\- Insurance claims often involve multiple perils (causes of loss).

\- The principle of proximate cause helps determine the real, effective cause of the loss.

\- Latin phrase:  

&nbsp; \_causa proxima non remota spectatur\_  

&nbsp; → \*“The immediate, and not the remote cause, is to be considered.”\*



\### 🔥 Example:

Lightning strikes a house → causes fire → house destroyed.  

Proximate cause = fire, not lightning.  

Why? Fire is the active, efficient cause of destruction.



---



\## 2. Definition of Proximate Cause



\- Proximate cause = dominant, effective, operative cause of a loss.

\- Not necessarily the nearest in time or place, but the most significant cause that sets the chain of events.



\### ⚖️ Technical Clarification:

\- “Proximate” ≠ “closest in time”

\- It means the cause that actually produced the result

\- Courts analyze the chain of events to decide



---



\## 3. Why is Proximate Cause Important in Insurance?



\- Insurance policies cover certain perils and exclude others.

\- When multiple perils combine, insurers must decide:

&nbsp; - Is the loss covered or excluded?

\- The principle ensures fairness and helps avoid disputes.



\### 🧨 Example:

Policy covers Fire but excludes Riot.  

If Riot leads to Fire → Fire destroys building →  

Insurer must decide:  

Proximate cause = Riot (excluded) or Fire (covered)?



---



\## 4. Application of Proximate Cause



\### ✅ Three Common Scenarios:



---



\### 1. Single Cause



\- Loss from one peril only

\- If peril is covered → claim payable  

\- If excluded → claim denied



Example:  

Factory burns due to fire (insured peril) → claim payable



---



\### 2. Concurrent Causes (acting together)



\- If both causes are insured → claim payable  

\- If one is insured and other is not → insurer decides which is proximate  

\- If excluded peril is dominant → claim rejected



Example:  

Ship sinks due to storm (insured) and enemy attack (excluded)  

→ If attack is proximate cause → no claim



---



\### 3. Chain of Events (successive causes)



\- If insured peril sets off excluded peril (or vice versa)  

→ Proximate cause decides the outcome  

\- Courts analyze which peril was operative at time of loss



---



\## 5. Case Law Reference



\### 🏛️ Pawsey v. Scottish Union \& National (1907)



\- Court defined proximate cause as:  

&nbsp; > \*“The active, efficient cause that sets in motion a chain of events which brings about a result, without intervention of any new independent force.”\*



✅ This is the textbook definition — often cited in exams.



---



\## 6. Practical Examples in Insurance



\- Fire Policy:  

&nbsp; Earthquake (excluded) causes fire (covered) →  

&nbsp; Fire destroys house → proximate cause = fire → claim payable



\- Marine Policy:  

&nbsp; Negligence (excluded) causes storm damage (covered) →  

&nbsp; Proximate cause = storm → claim payable



\- Health Policy:  

&nbsp; Illness (covered) leads to suicide (excluded) →  

&nbsp; Proximate cause = suicide → claim not payable



---



\## ✅ Revision Bullets (Exam-Ready)



\- Proximate cause = dominant, effective, operative cause of loss

\- Latin: \_causa proxima non remota spectatur\_

\- Not the nearest in time, but the real, efficient cause

\- 3 scenarios: Single cause, Concurrent causes, Chain of events

\- If insured peril = proximate → claim payable  

&nbsp; If excluded peril = proximate → claim rejected

\- Pawsey v. Scottish Union (1907): classic case defining proximate cause

\- Used to settle disputes when multiple perils combine



---







