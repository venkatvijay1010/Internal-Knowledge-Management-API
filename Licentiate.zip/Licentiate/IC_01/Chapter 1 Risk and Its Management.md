###                          📘 Chapter 1: Risk and Its Management

---

                                                                            🎯 Learning Outcome (a)
Understand what Risk is and how it is managed.

---

📌 1. Introduction: What is Insurance?

* Insurance is part of everyday life — we insure cars, lives, and health.
* Like cars, we use insurance without fully understanding its mechanism.
* Core Idea:
  Insurance is a loss-sharing mechanism:
  • Many contribute small amounts (premium)
  • Losses of the unfortunate few are paid from this pool

✅ Key Point:
Insurance = Sharing losses of few among many

---

📌 2. What is Risk?

* Risk = Possibility of deviation from an expected outcome
* Example:
  • Sun rising tomorrow → Certain → No Risk
  • It may rain tomorrow, a friend may fall ill, goods may remain unsold → Risk exists
* In insurance, we only consider adverse deviations (leading to financial loss)

✅ Insurance Risk =
Possibility of adverse deviation from expected outcome resulting in financial loss

---

📌 3. Pure Risk vs Speculative Risk

🔹 Pure Risk

* Only 2 outcomes → Loss or No Loss
* Examples: Fire destroying factory, illness, accident, burglary, machinery breakdown
* No chance of gain
* Beyond individual’s control

🔹 Speculative Risk

* 3 outcomes → Profit, Loss, or No Loss
* Examples: Buying shares, trading in forex, business ventures
* Undertaken voluntarily

✅ Comparison Table:

Feature        | Pure Risk                        | Speculative Risk
-------------- | --------------------------------- | -----------------------------
Outcome        | Loss / No Loss                   | Loss / No Loss / Profit
Control        | Outside individual’s control     | Within individual’s control
Coverage       | Can be insured                   | Not insured
Choice         | Involuntary                      | Voluntary
Examples       | Accident, Death, Illness, Natural Disasters | Stock market, Business, Adventure

---

📌 4. Why Speculative Risks are Not Insurable

* Voluntary → encourages reckless behavior if insured
* People share losses, not profits
* Hard to predict (no reliable data)
* Insurance for speculative risks would discourage enterprise

✅ Conclusion:
Only Pure Risks are insurable

---

📌 5. Risk Management

* Broader discipline that deals with all risks (pure + speculative)

🔸 Steps in Risk Management:

1. Risk Identification
   • List all possible risks using past data, industry info
   • Maintain a Risk Register
2. Risk Evaluation
   • Measure by:
   Frequency (how often) × Severity (how big)
3. Treating Risks
   • Avoidance:
   Don’t take risky actions (e.g., not building in earthquake zone)
   • Mitigation:

   * Prevention: Stop losses before they occur (helmets, fire alarms)
   * Reduction: Limit severity when loss happens (sprinklers, packaging)
     • Transfer:
     Shift risk to insurer (insurance) or financial market (hedging, underwriting IPOs)
     • Retention:
     Accept the risk and prepare to finance losses (capital, reserves, credit access)

✅ Key Point:
Insurance = Most important risk transfer mechanism

---

📌 Exam-Focused Bullet Points

✅ Insurance = Loss sharing mechanism  
Few suffer → Many contribute → Losses paid

✅ Risk = Adverse deviation from expected outcome causing financial loss

✅ Pure Risk vs Speculative Risk

* Pure Risk = Loss/No Loss (Insurable)
* Speculative Risk = Loss/No Loss/Profit (Not Insurable)

✅ Speculative Risks not insured because:  
Voluntary, unpredictable, encourages recklessness, no profit-sharing

✅ Risk Management Process:  
Identify → Evaluate (Frequency × Severity) → Treat (Avoidance, Mitigation, Transfer, Retention)

✅ Mitigation = Prevention (reduce frequency) + Reduction (reduce severity)

✅ Insurance covers only Pure Risks  
(fire, accident, death, illness, burglary, liability)

---



                                                                           📘 Learning Outcome (b)

                                                                       What Insurance is and How it Works



---



📌 1. Opening Sentence (Paraphrase \& Explanation)



Book Line:

“Insurance is a formal arrangement of sharing losses among the many people who are exposed to the same kind of risks.”



🔹 Breakdown:



\- “Formal arrangement”

  • Not an informal promise or charity

  • It’s a structured, legal arrangement:

    - Rules and regulations

    - A contract (legally enforceable)

    - An organisation (insurer) collects money and pays claims

  • Exam Tip: Emphasise “formal” → Insurance is a contract, not goodwill



\- “Sharing losses”

  • Core idea: Many contribute small sums (premiums)

  • When a few members suffer a loss, the pooled money compensates them

  • Financial burden is distributed

  • Exam Tip: Don’t confuse “sharing losses” with “preventing losses”

    - Insurance indemnifies after loss, it does not prevent loss



\- “People exposed to the same kind of risks”

  • Only those with similar exposures are pooled (homogeneous exposure units)

  • Homogeneity is important for:

    - Reliable pricing

    - Avoiding adverse selection



---



📌 2. Informal Examples (Contrast with Insurance)



Book Line:

Examples: Village pooling resources; nation helping flood victims.

“All such arrangements are voluntary, informal, unorganised, and sometimes unreliable.”



🔹 Explanation:

\- Informal social help works sometimes, but:

  • It’s not reliable

  • It’s not enforceable

\- Insurance replaced this with:

  • A stable, legally enforceable mechanism

  • People can rely on it during crises



✅ Key Contrast:

\- Informal = Ad-hoc, uncertain

\- Insurance = Contract, consistent obligations



---



📌 3. Formal Definition (Book Core Line)



Book Line:

“Insurance is a contract, whereby the Insurer, for a consideration called premium, agrees to make good the loss suffered by the Insured, arising out of an Insured Peril.”



🔹 Breakdown of Key Phrases:



a) “Insurance is a contract”

\- Creates legal obligations on both sides

\- Insurer promises to pay in certain situations; insured promises to pay premium and disclose material facts

\- Exam Tip: Policy terms = contract terms. Elements like offer, acceptance, consideration, capacity, lawful object apply



b) “Whereby the Insurer”

\- Insurer = company or underwriter who promises to pay as per policy

\- Duties: decide terms, accept/reject risks, set premium, pay claims



c) “For a consideration called premium”

\- Premium = money paid by insured in exchange for insurer’s promise

\- Premium calculation basics:

  • Expected loss (net premium) = frequency × severity

  • Gross premium = net premium + loadings (expenses, commission, profit, contingency)

\- Example:

  If expected loss = ₹1,500 and loadings = 25%, gross premium ≈ ₹1,875

\- Exam Tip:

  Net premium = actuarial expected claim; Gross premium = what customer pays



d) “Agrees to make good the loss” → Indemnity

\- Indemnity principle:

  • Insurer compensates to restore insured to pre-loss financial position (not better)

  • No profit from claim

\- Example:

  Factory worth ₹10 lakh, fire damage ₹6 lakh → insurer pays ₹6 lakh (subject to sum insured)

\- Exceptions:

  Life insurance and personal accident policies are not strict indemnity



e) “Suffered by the Insured” → Insurable Interest

\- Claimant must suffer actual financial loss

\- Definition: Legal relationship where you benefit from the thing’s existence and suffer from its loss

\- Exam Tip:

  Property → interest must exist at time of loss; Life → rules vary



f) “Arising out of an Insured Peril”

\- Peril: Cause of loss (fire, flood, theft)

\- Policy types:

  • Named Peril: Only listed perils covered; insured must prove cause

  • All-Risks: Covers all accidental losses except exclusions; insured proves accidental loss

\- Exam Tip:

  Burden of proof differs between named peril and all-risks policies



---



📌 4. How Does Insurance Work?



🔸 Pooling + Law of Large Numbers



\- Pooling:

  • Insurer collects premiums from many policyholders

  • Only a small proportion suffer losses → pooled funds pay claims

  • Insurer invests pooled money → earns investment income



\- Law of Large Numbers (LoLN):

  • “As the number of trials increases, actual results approach expected results.”

  • Larger pools → more predictable aggregate losses → reliable pricing

  • Example: Coin toss analogy (10 tosses vs 1,000,000 tosses)



\- Formula:

  • Expected loss per exposure = frequency × severity

  • Total expected claims = N × expected loss



✅ Limitations:

\- LoLN assumes independence and stability

\- Catastrophes, pandemics, systemic risks break assumptions

\- Small portfolios → high volatility



---



📌 5. How Insurers Protect Themselves



\- Reinsurance: Transfer part of risk to reinsurers

\- Actuarial models: Use large data sets, adjust for trends

\- Capital \& reserves: Maintain funds for unexpected deviations

\- Catastrophe planning: Secure reinsurance for large events



---



📌 Key Technical Terms



\- Premium: Money paid by insured for coverage

\- Indemnity: Restore insured to pre-loss position

\- Insurable Interest: Legal right to insure; must suffer loss

\- Peril: Cause of loss (fire, theft)

\- Named Peril vs All-Risks: Coverage scope difference

\- Law of Large Numbers: Basis for risk pooling and pricing

\- Expected Loss: frequency × severity



---



📌 Simple Formulas



1\. Expected claim per exposure:

   E\[L] = frequency × severity



2\. Aggregate expected claims:

   Total = N × E\[L]



3\. Gross premium:

   Net premium × (1 + loading %)



---



📌 High-Yield Exam Points



✅ Insurance = contract + indemnity + insurable interest + insured peril

✅ Premium = consideration; based on expected loss + loadings

✅ Indemnity = no profit from claim

✅ Named peril → insured proves cause; All-risks → insured proves accidental loss

✅ LoLN underpins premium calculation; larger pools = more predictable

✅ Limitations of LoLN: catastrophes, pandemics, small portfolios

✅ Risk management tools: reinsurance, reserves, actuarial models



---



                                                                                    📘 Learning Outcome (c):

                                                                  Understand why we need insurance and the benefits it provides.



---



\## WHY DO WE NEED INSURANCE?



---



📌 1. Protection



\- Book Idea:

  A person with some income can bear small losses (e.g., bicycle) but not big ones (e.g., automobile). Each person/enterprise has a capacity to bear loss depending on income, risk appetite, and affluence.



\- Explanation:

  • Capacity to bear loss = the amount of financial shock someone (or a firm) can absorb without catastrophic consequences

  • Higher income/wealth → higher capacity; risk appetite → some accept more retained risk

  • Example: Losing a ₹2,000 bicycle is affordable; losing a ₹6 lakh car may wipe out an ordinary household. Insurance makes the car loss manageable



\- Conclusion:

  Insurance transfers a potentially ruinous loss to an insurer in exchange for a predictable, small payment (premium).

  Protection = financial safety net



\- Examples:

  • Life insurance: On breadwinner’s death, family faces severe financial shock → life insurance pays sum insured to replace income

  • Enterprise: Firms need protection against fire, flood, burglary, liability claims, business interruption → insurance ensures continuity



✅ Exam Tip:

Protection ≠ Prevention. Insurance compensates after loss (indemnity), it does not guarantee prevention.



---



📌 2. Stability



\- Book Idea:

  Enterprises should record consistent results; insurance insulates them from volatilities caused by unforeseen losses.



\- Explanation:

  • Businesses report profits/losses to investors and lenders

  • Big unexpected losses (fire, liability award) create wild swings in profits → destroys confidence

  • Insurance pays for those losses → results more stable → easier planning, investor confidence, lower cost of capital



✅ Why stability matters:

Predictable financials help access credit, long-term contracts, and investor valuation.



✅ Exam Tip:

Lenders like insured borrowers because insurance ensures stability.



---



📌 3. Capital



\- Book Idea:

  Without insurance, enterprises need to maintain high capital to meet unforeseen losses. Insurance eases capital requirements.



\- Explanation:

  • Capital = funds set aside to absorb losses

  • Holding large capital is expensive (opportunity cost)

  • With insurance, business pays premium and shifts risk → less capital tied up → more funds for growth

  • Example: Without insurance, company might hold ₹10 crore as buffer; with insurance, much less



✅ Exam Tip:

Insurance reduces cost of carrying capital.



---



📌 4. Lending



\- Book Idea:

  Lenders lend against assets. If assets are imperiled, lender’s security is at risk → insurance secures lender’s position.



\- Explanation:

  • Banks require financed assets to be insured (e.g., mortgage lenders require fire insurance)

  • If asset is lost and uninsured, bank may not recover loan

  • Insurance protects collateral and reduces credit risk



✅ Practical Point:

Banks often insist on specific covers and may be named as “mortgagee” or “loss payee” in the policy.



---



📌 5. Legal Compliance



\- Book Idea:

  Insurance is mostly optional but some laws make it compulsory (e.g., Motor Vehicles Act, Environment Protection Act, RERA).



\- Explanation:

  • Legislatures mandate insurance when societal risk is significant and public interest must be protected

  • Example:

    - Motor third-party cover is mandatory → ensures injured third party gets compensation

    - Environmental liability → ensures remediation funds are available



✅ Exam Tip:

Know the Acts: Motor Vehicles Act, Environment Protection Act, RERA.



---



📌 6. Contract Requirements



\- Book Idea:

  Some contracts require the contracting party to have insurance to protect other parties and project resources.



\- Explanation:

  • In commercial contracts (construction, supply, services), one party may demand the other maintain specified insurance (public liability, professional indemnity, contractor all-risk)

  • This protects the client and ensures continuity of the project even if a loss occurs



---



\## BENEFITS OF INSURANCE



---



📌 1. Savings



\- Book Idea:

  Life Insurance has evolved as a saving-cum-risk instrument (Endowment, ULIPs).



\- Explanation:

  • Endowment policies: Premiums paid → maturity amount (sum assured + bonuses) on survival → disciplined savings + insurance

  • ULIP: Part premium for life cover; rest invested in funds (equity/debt). Returns depend on market performance

  • Insurers pool premiums and invest in long-term instruments → benefit policyholders and economy



✅ Exam Tip:

Product that protects + saves = Endowment or ULIP



---



📌 2. Loss Minimisation



\- Book Idea:

  Insurers learn from claims and incentivize loss-reducing behavior.



\- Explanation:

  • Learning effect: Insurers analyze claims → advise prevention (fire safety, cyber hygiene)

  • Rating mechanism: Safer customers pay lower premiums

  • Deductible/Excess: Fixed amount insured pays before insurer pays → reduces small claims and moral hazard

  • Co-pay: Insured pays % of claim (common in health)

  • Networks: Cashless hospitals/garages reduce costs



✅ Exam Tip:

To reduce moral hazard: deductibles, co-pay, underwriting, premium differentiation



---



📌 3. Investments



\- Book Idea:

  Insurance provides long-term funds for economy.



\- Explanation:

  • Insurers collect premiums for long-term liabilities → invest in infrastructure, bonds, mortgages

  • Supports economic growth

  • ALM: Assets match liabilities to ensure claims can be paid



✅ Exam Tip:

Life insurers = major source of long-term capital



---



📌 4. Security (Trade-off)



\- Book Idea:

  Insurance = trade-off: small known loss (premium) vs large unknown loss.



\- Explanation:

  • Premium = predictable small cost

  • Loss = uncertain, potentially catastrophic

  • People prefer certainty → insurance converts uncertainty into certainty



✅ Example:

Pay ₹10,000 premium vs risk ₹10 lakh loss



---



📌 5. Social Security



\- Book Idea:

  Insurers partner with governments for health schemes, disaster relief.



\- Explanation:

  • Insurers bring expertise in assessment, claims, beneficiary identification

  • Example: State-sponsored health insurance for low-income families



---



📌 6. Trade, Commerce and Industry



\- Book Idea:

  Insurance facilitates growth by reducing uncertainty.



\- Explanation:

  • Diversifies risk across geographies and sectors

  • Facilitates credit → insured assets attract lenders

  • Liability cover → enables large projects



✅ Exam Tip:

Insurance reduces cost of doing business and enables ambitious projects



---



📌 Key Technical Terms



\- Premium: Money paid by insured for coverage

\- Sum insured / Sum assured: Amount insurer agrees to pay

\- Deductible / Excess: Fixed amount insured pays before insurer pays

\- Co-pay: Insured’s share of claim (percentage)

\- Endowment policy: Insurance + guaranteed maturity benefit

\- ULIP: Life cover + market-linked investment

\- ALM: Matching assets to liabilities

