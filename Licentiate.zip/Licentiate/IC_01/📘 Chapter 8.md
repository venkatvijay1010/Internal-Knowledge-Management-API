### &nbsp;                                         📘 Chapter 8

&nbsp;                                                              LO (a): Understand the Significance of Underwriting



---



\## 1. What is Underwriting?



\- Definition:  

&nbsp; Underwriting is the process of evaluating, selecting, and assuming risks that an insurer will cover in return for a premium.



\- It determines:

&nbsp; - Which risks are acceptable

&nbsp; - On what terms (premium, coverage, exclusions)



---



\## 2. Why Underwriting is Important



\- Insurance = risk transfer mechanism

\- Many customers want to transfer risks (e.g., fire, flood, earthquake, burglary)

\- Insurers must evaluate risks before accepting them



> ⚠️ Without proper underwriting, insurers may take on excessive liability, risking financial collapse



\### 🔑 Key Point:

Underwriting protects the insurer’s solvency and ensures fairness in pricing



---



\## 3. Process of Risk Transfer



\- Asset owners want to shift risk

\- Insurers accept risk in exchange for premium

\- Risk transfer occurs via:

&nbsp; - Direct insurance

&nbsp; - Intermediaries (agents, brokers)



\- Customers seek best price \& terms  

→ Insurers evaluate if risk is acceptable



---



\## 4. What Underwriters Do



\- Assess whether risk has insurable characteristics:

&nbsp; - Measurable

&nbsp; - Definite

&nbsp; - Not catastrophic

&nbsp; - Accidental



\- Estimate probability of loss

\- Decide to accept or reject the risk

\- Fix suitable terms and conditions



---



\## 5. Why Poor Underwriting is Dangerous



\- Each accepted risk = potential liability

\- If losses exceed expectations → insurer suffers financial shocks

\- Such shocks can threaten insurer’s survival



> 🧠 Underwriting is a core function of insurance operations



---



\## ✅ Quick Exam Revision Bullets



\- Underwriting = evaluating, selecting, assuming risks

\- Ensures insurer only accepts risks with acceptable characteristics

\- Protects insurer’s solvency and avoids unexpected liabilities

\- Risk transfer = customers (seek protection) ↔ insurers (accept risk for premium)

\- Poor underwriting = financial shocks → can undermine insurer



---



&nbsp;                                                                                      LO (b): The Underwriting Process



\### Opening Concept

Text Essence:  

“Underwriting is performed in three phases — Evaluation, Selection and Assumption of risks.”



Explanation:  

\- Three Phases:  

&nbsp; 1. Evaluation – Gather facts and estimate loss probability.  

&nbsp; 2. Selection – Decide which risks meet company standards.  

&nbsp; 3. Assumption – Accept the risk and fix terms (write the policy).  



Memory Tip: Evaluate → Select → Assume (accept \& document).



---



\## 1. EVALUATION



\### Purpose of Evaluation

Text Essence:  

“The task the insurer should undertake before deciding whether to accept or decline a risk is to first evaluate the risk. Evaluation begins with collection of information on the risk and its features… these facts enable the insurer to ascertain the likelihood (probability) of a loss and estimate the severity.”



Explanation:  

\- First evaluate the risk: Cannot price or accept blind.  

\- Collection of information: Proposal form, documents, past loss data, photos, site details.  

\- Why? To estimate:  

&nbsp; - Frequency (likelihood of loss)  

&nbsp; - Severity (size of loss)  

Both are needed to compute expected loss and premium.



---



\### Small vs Large Risks; Proposal Form Design

Text Essence:  

“For smaller risks, minimum information is sufficient; for larger risks, detailed information and often an inspection are required. The Proposal Form should elicit minimum necessary info (don’t ask too many questions otherwise customer goes elsewhere).”



Explanation:  

\- Small risk = low value at risk: Quick, simple underwriting.  

\- Large risk = deliberate approach: Site inspection, engineering reports, financials, specialist surveys.  

\- Proposal Form Design: Balance simplicity with adequacy. Too many questions = lost business.  

Example: Home fire policy → ask essentials (construction, alarms, occupancy).



---



\### Risk Inspection \& Reinsurance

Text Essence:  

“For high value risks, a Risk Inspection may be carried out. For large risks reinsurance support may be required and reinsurers will need more granular detail. If urged to decide without adequate data, insurer should avoid or limit exposure.”



Explanation:  

\- Risk Inspection: Physical/technical survey for big risks.  

\- Reinsurance: Needed for large exposures; reinsurers demand detailed info.  

\- Principle: Never accept big unknowns → decline or limit exposure.



---



\## 2. SELECTION



\### Selection Includes Rejection; Automation

Text Essence:  

“Selection means choosing risks from those offered — selection by definition includes rejection. The selection process should be expeditious; much of it is automated using algorithms embedded in IT systems. Designing these algorithms is intricate (identify hazards + decide responses).”



Explanation:  

\- Selection = filtering: Includes rejection.  

\- Speed matters: Delays lose business.  

\- Automation: Rule engines for low-value, high-volume risks.  

\- Algorithm design: Encode hazard rules (e.g., cash-in-transit without armed guard → auto-decline above ₹X).



---



\### Two Rules for Risk Selection

Text Essence:  

“Two principles: (1) Insurer works on the Law of Large Numbers — write a large volume of homogeneous risks so predictions hold. (2) Need to generate profit — charge rates that cover burning cost and expenses; respond to market, but avoid unviable rates.”



Explanation:  

\- Law of Large Numbers: More similar risks → stable predictions.  

\- Profit principle: Premium must cover:  

&nbsp; - Expected claims (burning cost)  

&nbsp; - Expenses  

&nbsp; - Profit margin  

&nbsp; - Reinsurance cost  

\- Market pressure: Compete, but avoid underpricing.



---



\### Two Practical Rules (Condensed)

Text Essence:  

“Practice two rules: write large volume and avoid bad business; respond to market when possible without compromising profitability.”



Explanation:  

\- Rule 1: Volume + avoid high-probability losses.  

\- Rule 2: Price to cover costs, but stay market-aware.  

(Great for one-liner answers.)



---



\## 3. ACCEPTANCE



\### What Acceptance Involves

Text Essence:  

“Acceptance of risk includes drafting the terms for the policy. Drafting the terms of cover is part of the Acceptance process. Acceptance limits are based on capital and reinsurance support.”



Explanation:  

\- Acceptance = more than yes: Includes premium, sum insured, deductibles, warranties, exclusions, endorsements.  

\- Limits: Based on capital + reinsurance. Delegated authority applies.  

Example: Branch underwriter limit ₹5 lakh; regional head ₹5 crore.



---



\### Speed vs Prudence; Delegation

Text Essence:  

“Selection should be made expeditiously; not all risks within capacity are written at all operating units — acceptance based on underwriting skill and delegated powers.”



Explanation:  

\- Speed: Market expects quick decisions.  

\- Delegated authority: Documented limits by role. Complex risks → refer upward.





---

&nbsp;                                                                    LO (d): Understand the Underwriting Framework



---



\## Opening Concept: Definition \& Scope



Text Essence:  

“Underwriting Framework is the architecture for the Underwriting operations of the Company. When hundreds of thousands of risks must be evaluated, selected and assumed, the Insurer should have in place a sound framework that enables them to make sound decisions fast. The Underwriting Framework includes Hazard Study, Risk Classification, Risk Evaluation, Risk Inspection, Rating, Rating Tables, Underwriting Guides and Manuals.”



Explanation:  

\- Architecture = structured system → rules, documents, IT systems, people, authorities for consistent, auditable, repeatable underwriting.  

\- Scale problem → millions of risks (e.g., motor) need automation + rules for speed and quality.  

\- Goal → make sound decisions fast (balance accuracy vs speed).  

\- Building blocks → Hazard Study, Risk Classification, Risk Evaluation, Risk Inspection, Rating, Rating Tables, Guides, Manuals.



---



\## 4.1 Risk Classification and Rating



Text Essence:  

“Earlier we studied Risk, Peril and Hazard: (i) Exposure to the possibility of a loss is the Risk; (ii) Cause of loss is the Peril; (iii) Condition increasing the probability / aggravating the loss is the Hazard. Underwriting groups risks by characteristics and hazards. For Fire peril a hotel > residence; manufacturing plant > hotel. Classifications and relevant rates are embedded in Underwriting \& Technology Framework. Underwriting system analyses risks in relation to perils and hazards. A good risk for Fire could be a bad risk for Flood. The study \& classification is essentially an actuarial function but underwriters must work closely with actuaries to make it market friendly. The foundation of the framework is insurer’s risk appetite, capital availability, past loss experience and market considerations.”



Explanation:  

\- Risk = exposure, Peril = cause, Hazard = aggravating condition.  

\- Classification → group similar risks for rating efficiency.  

\- Example: Fire peril → hotel risk > residence; factory > hotel.  

\- Embedded in systems → rating engines, quote platforms.  

\- Peril-specific → good for Fire ≠ good for Flood.  

\- Actuarial + Underwriting collaboration → actuaries compute rates; underwriters ensure market usability.  

\- Foundation factors: risk appetite, capital, past loss data, market conditions.



---



\## 4.2 Acceptance Limits



Text Essence:  

“Underwriting framework should include stipulating acceptance limits for each operating unit. Acceptance Limit = amount up to which a risk could be accepted. This depends on capacity of the company (capital + committed reinsurance). Not all risks up to capacity are written at all units—limits reflect underwriting skill at various tiers.”



Explanation:  

\- Acceptance Limit = max risk per authority → e.g., branch ₹5 lakh, regional ₹5 crore.  

\- Depends on capacity → capital + reinsurance treaties.  

\- Skill-based delegation → complex risks escalated even if within monetary limit.



---



\## 4.3 Underwriting Guides



Text Essence:  

“These guides are used by frontline marketing: Agents and Sales. The Guide tells the field force what info is required, which risks are declined, which are standard and which need exceptions; it shows how risks are rated. Guides are embedded in mobile apps so agents can quote quickly and write simple risks and renewals online.”



Explanation:  

\- Purpose: simplify rules for agents/brokers.  

\- Contents: info required, auto-decline conditions, standard vs exception risks, rating logic.  

\- Modernization: embedded in apps for instant quotes and policy issuance.



---



\## 4.4 Underwriting Manuals



Text Essence:  

“Underwriting Manuals assist underwriters at various levels and channel partners authorised to write business. Manuals should be simple: they should illustrate information needed on the risk and the underwriting process; clearly define respective acceptance powers at each layer; document scenarios and SOPs for selection and acceptance of risks. Clear documentation and role clarity are important parts of the framework.”



Explanation:  

\- Audience: underwriters + delegated partners.  

\- Features:  

&nbsp; - Simple language, templates, checklists.  

&nbsp; - Delegation matrix (powers by role).  

&nbsp; - SOPs for exceptions (e.g., hazardous occupations).  

\- Governance: ensures consistency, auditability, training.



---



\## 4.5 Updating Underwriting



Text Essence:  

“The Underwriting Framework should be dynamic and constantly updated to respond to internal \& external changes — new technology, judicial approach to liability, new legislations, tax laws, regulatory changes. Smart underwriter watches undercurrents and acts: sometimes stop accepting certain risks, sometimes change product design. Underwriter should identify required changes and effect them quickly.”



Explanation:  

\- Dynamic framework → avoid obsolescence.  

\- Triggers: tech, legal rulings, regulations, climate trends.  

\- Actions:  

&nbsp; - Suspend risky classes.  

&nbsp; - Modify product design (exclusions, deductibles).  

\- Speed: governance must allow quick implementation.



---



\## 4.6 Underwriting Audit



Text Essence:  

“The Underwriting Framework includes an Audit mechanism to check whether underwriting functions at operating levels are as per respective authorities. Efficacy should be periodically evaluated — how closely the accepted pool matches the expected pool (measured by loss ratios). Affinity partners who have special powers should be monitored so that their liberty is not used irresponsibly.”



Explanation:  

\- Audit mechanism: sample checks for compliance with manuals and authority.  

\- Efficacy metric: loss ratio = (claims / premium).  

\- Monitor partners: delegated authority channels need strict oversight.



---



\## Regulatory Compliance



Text Essence:  

“Regulators are keen to protect policyholders. Relevant regulations for underwriting include: Board-approved underwriting policy (philosophy + delegation), File \& Use and Use \& File rules, Reinsurance Regulations, Policyholders’ Protection Regulations. Products must adhere to stipulations: prospectus must state scope, extent, exclusions; policy must spell out terms and renewal conditions. File \& Use principles: Products should be fair, non-discriminatory; adhere to basic insurance principles; be genuine insurance; address reasonable expectations; be based on sound/prudent underwriting \& actuarial basis. Regulations also stipulate when a policy may be cancelled or renewal refused; reinsurance procurement rules apply.”



Explanation:  

\- Board-approved policy: sets philosophy, risk appetite, delegation.  

\- File \& Use / Use \& File: product filing norms.  

\- Reinsurance regulations: solvency and treaty compliance.  

\- Policyholder protection: fairness, disclosure, non-discrimination.  

\- Checklist for products: fair, genuine, actuarially sound, meets expectations.  

\- Cancellation/renewal rules: statutory grounds only.



---



\### Key Exam Takeaways

\- Underwriting Framework = architecture (hazard study, classification, rating, guides, manuals).  

\- Risk vs Peril vs Hazard → classification is peril-specific.  

\- Foundation: risk appetite + capital + past loss + market.  

\- Acceptance Limit: based on capacity (capital + reinsurance).  

\- Guides \& Manuals: operationalize rules; app-driven.  

\- Update promptly: tech, legal, regulatory changes.  

\- Audit: monitor compliance and loss ratios.  

\- Regulations: board policy, File \& Use, fairness principles.



---





