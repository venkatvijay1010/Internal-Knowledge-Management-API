### &nbsp;                           ✅ Chapter 4 — Principles of Insurance-One

&nbsp;                                                                        Learning Outcome (a)  

&nbsp;                                                            Principle of Utmost Good Faith (Uberrimae Fidei)  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 1 — Heading + Opening Statement  

Paraphrase / PDF line:  

“Understand the Principle of Utmost Good Faith and understand how it is important to Insurance Contracts.”  



Explanation (line-by-line):  

✅ This is the learning-outcome statement. It tells you the subject: utmost good faith and its importance in insurance.  

✅ The chapter will explain what the doctrine means, why insurance needs it, and how it operates in law and practice.  



📌 Exam tip:  

When a question asks \*“state LO (a) of Chapter 4”\*, quote the phrase Utmost Good Faith (uberrimae fidei) and briefly add “duty to disclose material facts”.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 2 — Definition and the Contrast with Ordinary Contracts  

Paraphrase / PDF lines:  

“All contracts are contracts of good faith. The parties have a duty to answer questions truthfully and not actively conceal facts. However, in ordinary contracts parties are not expected to disclose facts which are not asked. Example: seller of land need not volunteer a government acquisition proposal unless asked. Insurance contracts are different: they are contracts of utmost good faith — the parties must disclose all material facts even if the insurer did not ask. This is called the Duty of Disclosure (doctrine of uberrimae fidei).”  



Explanation (line-by-line):  

✅ “All contracts are contracts of good faith” — baseline duty in contract law: don’t lie when asked.  

✅ Ordinary sale example: seller needn’t volunteer every hidden fact; only answer asked questions truthfully.  

✅ Insurance exception: Because insurers price and accept risk based on information they receive, the proposer must disclose all material facts even if not specifically asked. This is a higher standard than ordinary contracts — hence utmost good faith.  

✅ Duty of Disclosure = insured must tell insurer anything that would influence underwriting—whether asked or not.  



🔍 Technical term:  

Material fact — any fact that would influence insurer’s decision to accept the risk or the price/terms on which it would be accepted.  



📝 Example:  

In life insurance, prior serious illness is a material fact — it must be disclosed even if the proposal form doesn’t explicitly ask about that specific illness.  



📌 Exam tip:  

Define utmost good faith and contrast it with ordinary contract duty (voluntary disclosure vs duty to disclose material facts).  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 3 — “Need for Utmost Good Faith” + Carter v Boehm Quote  

Paraphrase / PDF lines (includes quote):  

“Need for Utmost Good Faith is explained in Lord Mansfield’s judgement in Carter v Boehm (1766): insurance is a contract upon speculation; the special facts are usually within the insured’s knowledge; the underwriter relies on the insured’s representation; suppression of such facts — even by honest mistake — deceives the underwriter and makes the policy void.”  



Explanation (line-by-line):  

✅ The Carter v Boehm quote is the classical authority for uberrimae fidei: insurers cannot discover all facts themselves; they rely on proposer’s honesty.  

✅ Key point: if insured suppresses material facts, insurer is misled about the risk actually being undertaken → policy may be void.  

✅ Notice the strictness: even an innocent non-disclosure (no fraud) historically could render the policy void because the underwriter was deceived.  



🔍 Technical term:  

Void — contract treated as if never existed; no enforceable rights under it.  



📝 Example:  

If a proposer fails to tell the insurer about a previous serious fire at the same premises, insurer’s acceptance was based on incomplete facts—insurer may avoid the policy.  



📌 Exam tip:  

Quote a short line from Carter v Boehm in an exam answer (e.g., \*“Insurance is a contract upon speculation… special facts lie in the knowledge of insured”\* — then explain its implication).  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 4 — Practical Reason: Insurers Receive Many Proposals  

Paraphrase / PDF lines:  

“An insurer receives hundreds of proposals. The insurer cannot investigate every detail for every proposal; hence insurer must rely on proposer’s truthful disclosure — the Duty of Disclosure is therefore essential.”  



Explanation:  

✅ This is a practical reinforcement: underwriting scale means insurers cannot physically discover every hidden fact — they depend on accurate proposals.  

✅ The duty balances the asymmetry of information: insured usually knows more about the subject matter than insurer.  



📌 Exam tip:  

Use this pragmatic point to justify why the legal rule exists (information asymmetry + practical constraints).  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 5 — “Evolution of the Doctrine” (Start)  

Paraphrase / PDF lines:  

“The insured historically faced onerous responsibilities: (i) disclose all material facts even if not asked; (ii) know material facts; (iii) an innocent mistake could render the contract void. These strict obligations sometimes gave insurers unfair grounds to deny claims; so over time the doctrine has been relaxed to be less consumer-hostile.”  



Explanation (line-by-line):  

✅ Early law was strict — non-disclosure (even innocent) could void a policy.  

✅ Over centuries, courts and legislatures have softened the rule to protect consumers from unfair denials when insurers failed to ask or framed ambiguous questions.  

✅ This paragraph signals the following sub-rules and exceptions that reduce the burden on the proposer.  



📌 Exam tip:  

If asked about modern trend, say \*“Doctrine remains but has been relaxed: courts prefer fairness — insurer must ask clear questions; blank answers or failure to ask may amount to waiver.”\*  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 6 — Specific Relaxations / Insurer’s Duty to Ask + Waiver  

Paraphrase / PDF lines:  

If an insurer did not ask a question, non-disclosure might not be a breach.  

If the proposer left an answer blank, that alone is not proof of suppression — ignoring unanswered questions may amount to waiver of the insurer’s right to that information.  

Insurer should frame proposal questions so material particulars are obtained; failure to ask can be inferred by courts as the insurer having waived the right to that info.  



Explanation (line-by-line):  

✅ Non-asked fact: If the insurer chooses not to ask, it weakens the insurer’s later contention that the fact was material.  

✅ Blank answers: If proposer leaves a question blank, insurer’s failure to follow up may mean insurer waived strict disclosure rights.  

✅ Insurer’s responsibility: Practical fairness demands insurers draft clear proposal forms and follow up on incomplete replies.  



🔍 Technical term:  

Waiver — giving up a legal right (here: the insurer effectively waives the right to rely on non-disclosure when it fails to ask / follow up).  



📝 Example:  

Proposal form asks “Any prior heart disease?” If left blank and insurer does not clarify, insurer may not later avoid claim on that ground.  



📌 Exam tip:  

Always mention waiver and insurer’s duty to frame questions when discussing modern limits to uberrimae fidei.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 7 — International \& Indian Legal Changes (Section 18 / Section 45)  

Paraphrase / PDF lines:  

In the UK, the strict Duty of Disclosure under Section 18 (Marine Insurance Act) has been removed in modern law.  

Indian courts similarly are reluctant to burden consumers with duty where insurers did not ask or ignored blanks.  

Importantly: applicability of the Duty has been restricted.  



Explanation:  

✅ Laws have evolved internationally: reform (UK) removed some pre-contract duty for the proposer in marine law; courts favor protecting insureds who were not asked clear questions.  

✅ Indian courts have taken a consumer-friendly approach — they ask whether insurer asked clear questions and whether the insurer could have discovered the fact.  

✅ The upshot: duty exists but courts interpret it with fairness; insurer’s conduct matters.  



📌 Exam tip:  

Mention Section 18 (UK) and Section 20 (Indian Marine Insurance Act) in context and then Section 45 of Insurance Act (India) for life insurance (next paragraphs). Use citations.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 8 — “Facts which need not be disclosed” — Categories (a–e)  

Paraphrase / PDF lines (list):  

The book lists five categories of facts that the insured need not disclose:  

a) Facts of law (public legal facts) — insured need not disclose matters of law.  

b) Facts which insurer is deemed to know — matters of common/industry knowledge (unsafe constructions, hazardous goods, typical weather patterns).  

c) Facts which lessen the risk — if disclosed they might reduce premium; but non-disclosure of such facts does not harm insurer’s underwriting decision.  

d) Facts the insurer’s survey could have noted — if insurer arranged a survey, insured need not disclose facts the survey would uncover.  

e) Circumstances waived by insurer — blank answers the insurer ignores can be treated as waiver; insurer has to seek missing info.  



Explanation (line-by-line):  

✅ (a) Facts of law: the insured isn’t expected to advise insurer about legal matters that are publicly knowable.  

✅ (b) Insurer’s knowledge: insurers are presumed to know general technical facts about risks in the ordinary course of business.  

✅ (c) Facts lessening risk: e.g., a garage with sprinkler system — failing to disclose this doesn’t prejudice insurer because it reduces risk.  

✅ (d) Survey observations: if insurer commissions a pre-inspection, the insured need not reveal items that the survey would have disclosed.  

✅ (e) Waiver/inference: insurer’s failure to seek missing info may lead to inference against them.  



🔍 Technical terms: Waiver, deemed to know, survey/pre-inspection.  



📝 Example:  

If the insured operates in a well-known cyclone zone (public knowledge) the insurer is expected to be aware — the insured need not volunteer that fact as “new” information.  



📌 Exam tip:  

Be ready to list and briefly explain these 5 categories — examiners like a neat list. Cite the PDF.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 9 — “Life Insurance: statutory limit (Section 45)”  

Paraphrase / PDF lines:  

“In Life Insurance, Duty of Disclosure is limited by statute: Section 45 (Insurance Act) was amended in 2015 — no life insurance policy can be called in question after three years from commencement. Within three years, a policy can be questioned for fraud; and for misstatement/suppression of material fact the insurer must prove that they would have not issued the policy had they known the fact.”  



Explanation (line-by-line):  

✅ Statutory protection: In India, life policies enjoy a three-year incontestability period — after 3 years the insurer cannot avoid the policy on the ground of misstatement (except under limited circumstances like fraud).  

✅ Within 3 years: insurer can challenge on grounds of fraud or misrepresentation, but burden lies on insurer to show that the non-disclosed fact would have affected underwriting (i.e., they would have declined or charged different terms).  

✅ This softens the earlier draconian rule that innocent mistakes automatically voided policies.  



🔍 Technical term:  

Incontestability period — period after which insurer cannot contest the policy for pre-contract misstatements.  



📝 Example:  

If proposer failed to disclose a prior hospitalization but it was an honest mistake, after 3 years the insurer generally cannot repudiate the life policy on that ground.  



📌 Exam tip:  

Memorise the three-year rule and that the insurer bears burden of proof for misstatement within that period. Cite Section 45 (Insurance Act, amended 2015).  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 10 — “Health Insurance: 8-year rule” (short)  

Paraphrase / PDF lines:  

“Health Insurance: no health policy can be called in question after eight years of continuous coverage.” (PDF has this note — read in context.)  



Explanation:  

✅ Health policies often have longer contestability/investigation windows (the book mentions eight years in your PDF). This is an area where product features, policy wording and statute (or judicial interpretation) matter.  

✅ The key point: different lines may have different statutory/contractual limitations.  



📌 Exam tip:  

If asked about contestability periods, state life = 3 years (India), health may have specified longer periods (book mentions 8 years — cite). Confirm in statutory context if needed.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 11 — “Insurer’s knowledge \& duties (further clarifications)”  

Paraphrase / PDF lines:  

“Facts which an insurer is deemed to know: matters of common knowledge, matters an insurer ought to know in ordinary course of business (e.g., unsafe constructions, hazardous goods, local weather). Facts which lessen the risk do not have to be disclosed (they would only reduce premium). If insurer arranges pre-inspection, the insured need not disclose items survey would note. If insurer ignores blank answers, they may have waived their right to rely on non-disclosure.”  



Explanation:  

✅ This repeats the categories but emphasizes insurer’s role: insurer should draft good forms and follow up on blanks. Where insurer fails, courts look at insurer’s conduct.  

✅ The doctrine has thus evolved into a balanced test: Is the fact material? Did insurer ask? Could insurer have discovered it? Courts look at these factors.  



📌 Exam tip:  

When writing an answer use the 3-part test: materiality + insurer’s inquiry + insurer’s opportunity to discover — then conclude whether nondisclosure is actionable. Cite the PDF.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 12 — Remedies \& Consequences (void/voidable/fraud)  

Paraphrase / PDF lines:  

“If insured fails duty, earlier law treated contract as void. Modern law tempers this: insurer’s remedy depends on nature of non-disclosure: if fraudulent → insurer can avoid and sue; if innocent misstatement → insurer must show materiality and causation (that they would not have issued policy/terms had they known). Courts favour consumer protection when insurers failed to ask or waived info.”  



Explanation:  

✅ Fraudulent non-disclosure = deliberate concealment or false statement → insurer can avoid policy and seek damages.  

✅ Innocent misstatement/non-disclosure = modern approach tends to require insurer to show materiality / would have declined or changed terms.  

✅ Void vs voidable: Older position: void ab initio (treated as never existed). Modern nuance: often voidable at insurer’s option depending on circumstances.  



🔍 Technical terms: Fraudulent misrepresentation, innocent misrepresentation, voidable contract.  



📝 Example:  

Intentional false answer on smoking habit = fraud → insurer can repudiate; forgetting an old minor illness genuinely not remembered may lead to different treatment if insurer failed to ask.  



📌 Exam tip:  

Distinguish fraud vs innocent misrepresentation and mention burden of proof rests on insurer for innocent cases.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 13 — Practical drafting \& underwriting implications  

Paraphrase / PDF lines:  

“Insurers must frame proposal forms comprehensively; follow up on blanks; arrange surveys where needed; and document all communications. Failure to do so can stop them from relying on nondisclosure later.”  



Explanation:  

✅ The operational lesson: good underwriting practice reduces insurer’s legal risk. Clear questions + follow-up = more secure positions.  

✅ From insured’s side: answer truthfully and ask if unsure.  



📌 Exam tip:  

If asked for “practical advice insurers should follow to rely on uberrimae fidei”, list: clear proposal forms, follow up blanks, timely surveys, documented communications.  



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 14 — Short summary paragraph (book wrap-up)  

Paraphrase / PDF lines:  

“While the doctrine still underpins insurance law, courts and lawmakers have restricted its harshest consequences. Life insurance now has statutory time limits; insurers must ask, follow up and cannot later rely on undeclared facts they could or should have sought. The duty remains important but moderated.”  



Explanation:  

✅ The chapter closes LO(a) by balancing historical strictness with modern consumer protection.  



📌 Exam tip (compact model answer):  

1\. Define: Utmost Good Faith (uberrimae fidei) — duty to disclose all material facts.  

2\. Explain why (information asymmetry; Carter v Boehm).  

3\. List exceptions/relaxations (facts of law, insurer’s knowledge, facts lessening risk, survey, waiver).  

4\. Statutory limits: life insurance 3 years (Section 45, 2015 amendment).  

5\. Consequences: fraud → avoid; innocent misstatement → insurer must prove materiality.  



-----------------------------------------------------------------------------------------------



\### ✅ Quick Glossary (one-line definitions — memorise these)  

🔍 Uberrimae Fidei — Utmost Good Faith; proposer must disclose all material facts.  

🔍 Material fact — fact that would influence underwriter’s acceptance or terms.  

🔍 Waiver — insurer’s failure to insist on a right (e.g., ignoring blank proposal answers).  

🔍 Incontestability / Section 45 — life policies cannot be called in question after 3 years (India).  

🔍 Innocent vs Fraudulent misstatement — affects remedy (modern law requires materiality proof for innocent mistakes).  



-----------------------------------------------------------------------------------------------

&nbsp;                                                                Learning Outcome (b): Principle of Insurable Interest  



-----------------------------------------------------------------------------------------------



\### ✅ 1. Meaning of Insurable Interest  

An insurance contract is valid only if the insured has insurable interest in the subject matter.  



✅ Insurable Interest = a legal right to insure, based on a relationship such that the insured would suffer a financial/economic loss if the insured event occurs.  



❌ Without insurable interest → contract is a wagering contract (mere bet) → void.  



🔍 Technical terms:  

\- Insurable interest = legal, financial stake.  

\- Wagering contract = void under the Indian Contract Act.  



-----------------------------------------------------------------------------------------------



\### ✅ 2. Why Required  

✅ Ensures insurance is used for protection, not gambling.  

✅ Only those who stand to lose can insure.  



📝 Example:  

You can insure your own house (loss affects you), but not your neighbor’s house (loss doesn’t affect you).  



-----------------------------------------------------------------------------------------------



\### ✅ 3. Legal Recognition  

✅ Insurable interest is recognized under common law and statutes:  

\- Marine Insurance Act, 1963 (India) – Section 7 requires insurable interest.  

\- Courts treat policies without insurable interest as void.  



-----------------------------------------------------------------------------------------------



\### ✅ 4. Who Has Insurable Interest?  

✅ Self in one’s own life – unlimited.  

✅ Spouse – husband and wife have interest in each other’s lives.  

✅ Parents \& Children – parents in child’s life; child in dependent parent’s life.  

✅ Creditor in debtor’s life – up to loan amount.  

✅ Debtor in creditor’s life – generally not recognized.  

✅ Business partners – in each other’s lives.  

✅ Employer \& Employee – employer has interest in employee’s life (limited to economic value).  



📌 Note: Courts decide based on whether there is a “pecuniary (financial) relationship.”  



-----------------------------------------------------------------------------------------------



\### ✅ 5. Time of Existence  

✅ Life Insurance – insurable interest must exist at inception of policy, not necessarily at time of death.  



📝 Example:  

Husband takes life cover on wife → valid even if they later divorce.  



✅ General Insurance (Fire, Marine, Motor, etc.) – insurable interest must exist both at inception and at time of loss.  



📝 Example:  

You insure your house, then sell it. If fire occurs after sale, you can’t claim (no longer have insurable interest).  



-----------------------------------------------------------------------------------------------



\### ✅ 6. Consequences of Absence  

❌ Without insurable interest → contract is void ab initio (invalid from the beginning).  

❌ No claim is payable; courts won’t enforce it.  



📝 Example:  

A person insuring a stranger’s life → policy invalid.  



-----------------------------------------------------------------------------------------------



\### ✅ 7. Case Law Reference  

Lucena v. Craufurd (1806):  

Defined insurable interest as a “right in the property, or a right derivable out of some contract about the property, which may be lost upon some contingency.”  



✅ This case is the classic authority explaining insurable interest in common law.  



-----------------------------------------------------------------------------------------------



\### ✅ Revision Bullets (Exam-Ready)  

📌 Definition: legal right to insure → must have financial stake in subject matter.  

📌 Purpose: prevents insurance from becoming gambling.  

📌 Examples:  

\- Self (own life) – unlimited.  

\- Spouse, parents/children, creditor/debtor (up to loan), partners, employer/employee.  



📌 Time rules:  

\- Life = inception only.  

\- General = inception + at time of loss.  



📌 Case law: Lucena v Craufurd (1806).  

📌 No insurable interest = void contract, no claim payable.  



-----------------------------------------------------------------------------------------------



