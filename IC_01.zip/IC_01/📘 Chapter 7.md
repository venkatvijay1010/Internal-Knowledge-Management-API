### &nbsp;                                             # 📘 Chapter 7 

&nbsp;                                                                    LO (a): Understand What Constitutes a Contract, and the Elements of a Contract



---



\## Opening Paragraph — Insurance is a Contract



\- Insurance is a contract — a legally binding agreement.

\- It involves two parties:

&nbsp; - Insurer: promises cover

&nbsp; - Insured: pays premium

\- A contract must be enforceable at law — not every promise qualifies.



\### 🧠 Exam Tip:

Start with: “Insurance is a legally enforceable contract between insurer and insured.”



---



\## Insurance as Formal Loss-Sharing Arrangement



\- Insurance = formal pooling of risk.

\- Not every agreement is a contract — e.g., a dinner promise is not enforceable.

\- The chapter introduces seven elements that make an agreement a valid contract.



\### 🧠 Exam Tip:

Use the dinner example to show difference between casual promises and contracts.



---



\## ✅ Seven Elements of a Valid Contract



---



\### 1. Offer and Acceptance



\- One party makes an offer (e.g., proposal form).

\- Other party accepts → contract is formed.

\- In insurance:

&nbsp; - Customer usually makes the offer.

&nbsp; - Insurer accepts after underwriting.



Technical Terms:

\- Proposal form: details of risk, sum insured, disclosures.

\- Counter-offer: insurer modifies terms (e.g., higher premium); proposer must accept.



Example:

Customer submits motor proposal → insurer demands higher premium → customer accepts → contract formed.



\### 🧠 Exam Tip:

Sequence: Proposal → Underwriting → Acceptance → Contract exists.



---



\### 2. Consensus ad idem (Identity of Minds)



\- Both parties must agree on the same subject matter.

\- If minds differ → no valid contract.



Example:

Customer wants to insure “warehouse A” → insurer thinks “warehouse B” → mismatch = no valid contract.



\### 🧠 Exam Tip:

Use the “market house vs outskirts house” example.



---



\### 3. Consideration



\- Each party must receive a benefit:

&nbsp; - Insured: promise of indemnity

&nbsp; - Insurer: premium



Technical Term:

\- Consideration = legal exchange that makes promise enforceable.



\### 🧠 Exam Tip:

State: “Insured’s benefit = indemnity; Insurer’s benefit = premium.”



---



\### 4. Capacity (Competency of Parties)



\- Parties must be legally capable:

&nbsp; - Age 18+

&nbsp; - Sound mind

&nbsp; - Not disqualified by law



Example:

A 16-year-old cannot enter a valid insurance contract without guardian consent.



\### 🧠 Exam Tip:

Mention minor and unsound mind as examples of incapacity.



---



\### 5. Free Consent



\- Consent must be voluntary — not induced by:

&nbsp; - Coercion

&nbsp; - Undue influence

&nbsp; - Fraud

&nbsp; - Misrepresentation

&nbsp; - Mistake



Example:

Employer forces employee to buy a policy → consent not free → contract voidable.



\### 🧠 Exam Tip:

Link to utmost good faith — misrepresentation voids consent.



---



\### 6. Lawful Object



\- Purpose of contract must be legal.

\- Cannot insure illegal activities.



Example:

Policy insuring profits from drug trade = invalid.



\### 🧠 Exam Tip:

Contrast: House insurance (lawful) vs smuggling profits (unlawful).



---



\### 7. Possibility of Performance



\- Promises must be physically and legally possible.

\- Impossible acts = invalid contract.



Example:

Insuring a building that’s already demolished = impossible performance.



\### 🧠 Exam Tip:

Use the “iron into gold” example — memorable and in the book.



---



Would you like this combined with Chapters 6 LO (a), (b), and (c) into a single PDF or Word document for easy revision or submission? I can generate that instantly.







---



6\) Common exam-ready points / pitfalls (bullet list — memorize these)



Contribution applies only to indemnity policies. (No contribution for benefit policies.)



All contribution conditions must be satisfied: indemnity policies, same interest, same subject matter, same peril covered, both policies liable.



Formula (no underinsurance): insurer\_i = L × (S\_i / T).



Formula (underinsurance): insurer\_i = L × (S\_i / V). (Equivalently: payable = L × (T / V); then split pro rata.)



Marine \& Health are exceptions — insured can choose insurer(s); check policy wordings and statutory provisions (Marine Insurance Act quoted in the book).



If one policy is not liable (excluded/void), it need not contribute — verify liability first.



Contribution is a right of the insurer (to limit its payout to its proportion). The insured cannot recover double from multiple indemnity insurers.







---



&nbsp;                                                                 LO (b): Learn the Legal Requirements of an Insurance Contract



---



\## 1. Opening: Insurance as a Contract



\- Insurance is a special contract governed by:

&nbsp; - Indian Contract Act, 1872

&nbsp; - Insurance Act, 1938

\- It includes the 7 essentials of a general contract:

&nbsp; - Offer

&nbsp; - Acceptance

&nbsp; - Consideration

&nbsp; - Capacity

&nbsp; - Free Consent

&nbsp; - Lawful Object

&nbsp; - Possibility of Performance

\- But also includes special legal principles unique to insurance.



> 🧠 Exam Note: Always distinguish between general contract essentials and insurance-specific principles.



---



\## 2. Special Legal Principles in Insurance Contracts



---



\### (i) Insurable Interest



\- Definition: Legal right to insure based on financial relationship with the subject matter.

\- Must exist:

&nbsp; - At contract time in life insurance

&nbsp; - At loss time in property insurance

\- Prevents gambling.



Example:  

You can insure your own house, not a stranger’s.



---



\### (ii) Utmost Good Faith (Uberrimae fidei)



\- Both parties must disclose all material facts truthfully.

\- Material fact = fact that influences insurer’s decision.

\- Failure = policy voidable.



Example:  

Non-disclosure of heart disease when buying life policy → breach of utmost good faith.



---



\### (iii) Indemnity



\- Restores insured to same financial position as before loss.

\- Applies to property/general insurance (fire, motor, marine).

\- Prevents profit from insurance.



Formula:  

Claim = Actual Loss (limited to Sum Insured)



---



\### (iv) Subrogation



\- After indemnifying, insurer acquires rights of insured against third party.

\- Prevents double recovery.



Example:  

Car hit by negligent driver → insurer pays insured → insurer sues driver.



---



\### (v) Contribution



\- When multiple indemnity policies cover same risk, insurers share loss proportionately.



Formula (no underinsurance):  

Each insurer’s share = Loss × (Sum insured with that insurer ÷ Total sum insured)



---



\### (vi) Proximate Cause



\- Only the dominant, effective cause of loss is considered.

\- If insured peril = proximate cause → claim payable  

\- If excluded peril = proximate cause → claim rejected



Latin Maxim:  

\_Causa proxima non remota spectatur\_



---



\## 3. Why These Are “Legal Requirements”



\- Without these principles, insurance contracts could become wagers.

\- They ensure legal enforceability and protect both parties.

\- Courts use these principles to resolve disputes.



---



\## ✅ Exam Revision Bullets



\- Insurance contracts = special contracts under:

&nbsp; - Contract Act, 1872

&nbsp; - Insurance Act, 1938



\### General Essentials:

\- Offer  

\- Acceptance  

\- Consideration  

\- Capacity  

\- Free Consent  

\- Lawful Object  

\- Possibility of Performance



\### Insurance-Specific Legal Principles:

\- Insurable Interest → prevents wagering  

\- Utmost Good Faith → full disclosure  

\- Indemnity → no profit  

\- Subrogation → insurer steps into insured’s shoes  

\- Contribution → sharing among insurers  

\- Proximate Cause → dominant cause considered



> ✅ These requirements make insurance a valid, enforceable, and fair contract.



---

&nbsp;                                                                        LO (c): Different Laws Relevant to Insurance



---



\## 1. Main Regulatory Laws



\### 🏛️ Insurance Act, 1938

\- Governs:

&nbsp; - Registration of insurers

&nbsp; - Capital requirements

&nbsp; - Solvency margins

&nbsp; - Accounts and investments

&nbsp; - Control of management



\### 🏢 IRDAI Act, 1999

\- Establishes the Insurance Regulatory and Development Authority of India (IRDAI)

\- Functions:

&nbsp; - Licenses insurers and agents

&nbsp; - Protects policyholders

&nbsp; - Promotes insurance sector growth



---



\## 2. General \& Specific Laws



\### 📜 Indian Contract Act, 1872

\- Governs basic contract principles:

&nbsp; - Offer

&nbsp; - Acceptance

&nbsp; - Consideration

&nbsp; - Capacity

&nbsp; - Consent



\### ⚓ Marine Insurance Act, 1963

\- Codifies marine insurance:

&nbsp; - Insurable interest

&nbsp; - Warranties

&nbsp; - Voyage policies



\### ⚖️ Common Law Principles

\- Apply to non-marine insurance:

&nbsp; - Indemnity

&nbsp; - Subrogation

&nbsp; - Proximate cause



---



\## 3. Statutes Affecting Particular Covers



\### 🚗 Motor Vehicles Act

\- Mandates compulsory third-party motor insurance



\### 👷 Employees’ Compensation Act

\- Covers employer liability for worker injury or death



\### 🚚 Carriage Acts (Road, Sea, Air, Rail, Multimodal)

\- Define carrier liability during transit



\### ☣️ Public Liability Insurance Act, 1991

\- Requires mandatory insurance for hazardous goods

\- Product liability also arises via tort law



\### 🧑‍⚖️ Consumer Protection Act, 2019

\- Insurance classified as a service

\- Complaint limits:

&nbsp; - District: ≤ ₹1 crore

&nbsp; - State: ≤ ₹10 crore

&nbsp; - National: > ₹10 crore



\### 🏗️ Real Estate (RERA) Act, 2015

\- Certain project insurances mandated



\### 🧑‍💼 Companies Act, 2013

\- Governs Directors \& Officers (D\&O) liability exposure



\### 🧠 Mental Healthcare Act, 2017

\- Requires mental illness to be covered like physical illness



---



\## 4. Dispute Resolution



\### ⚖️ Arbitration \& Conciliation Act, 1996

\- Governs arbitration clauses in insurance policies

\- Arbitral awards are binding



---



\## ✅ Quick Revision Bullets



\- Insurance Act + IRDAI Act = core regulatory framework

\- Contract Act = basis of enforceability  

\- Marine Act = specific to marine insurance

\- Other key statutes:

&nbsp; - Motor Vehicles Act

&nbsp; - Employees’ Compensation Act

&nbsp; - Carriage Acts

&nbsp; - Public Liability Insurance Act

&nbsp; - Consumer Protection Act

&nbsp; - RERA Act

&nbsp; - Companies Act

&nbsp; - Mental Healthcare Act

\- Arbitration Act = governs dispute settlement in policies



---



&nbsp;                                                                  LO (d): Understand Burden of Proof and Interpretation of Contracts



---



\## 1. Burden of Proof



In insurance, someone must prove that a loss has occurred.



\### ⚖️ General Rule:

\- Insured (customer) has the duty to prove the loss.



---



\### 🧾 Case 1: Named Perils Policy



\- Covers specific perils (e.g., fire, flood, theft).

\- Insured must prove that the loss was caused by a covered peril.

\- No need to prove the “cause of the cause.”



Example:  

In fire insurance, insured proves fire damaged property.  

They don’t need to prove what caused the fire (e.g., short circuit, negligence).



---



\### 🌐 Case 2: All Risks Policy



\- Covers all perils except exclusions.

\- Insured proves that a loss occurred.

\- If insurer wants to deny claim, insurer must prove that the loss came from an excluded peril.



Example:  

In an “All Risks” policy, if insurer claims damage was due to war (excluded), insurer must prove it.



---



\### 👉 Summary:

\- Insured → prove covered loss  

\- Insurer → prove exclusion applies



---



\## 2. Interpretation of Insurance Contracts



Insurance policies are drafted by insurers.  

Customers often lack bargaining power, so courts apply protective rules.



---



\### 📘 (i) Contra Proferentem Rule



\- Latin: Against the one who puts forward

\- If wording is ambiguous, interpretation is in favour of insured.



Example:  

If an exclusion clause can mean two things, court interprets it in a way favourable to customer.



---



\### 📘 (ii) Reasonable Expectations Rule



\- Courts may uphold the reasonable expectations of the insured, even if not explicitly stated.



Example:  

If policy wording is technical but insured reasonably expects flood damage to be covered under “water damage,”  

→ court may decide in favour of insured.



---



\## 3. Why These Are Important



\- Burden of proof ensures fairness:

&nbsp; - Insured proves basic loss

&nbsp; - Insurer proves exclusion



\- Interpretation rules protect consumers from:

&nbsp; - Complex

&nbsp; - Insurer-drafted wordings



---



\## ✅ Exam Revision Bullets



\### 🔍 Burden of Proof:

\- Named peril → insured proves loss by peril  

\- All risks → insured proves loss; insurer must prove exclusion



\### 📜 Interpretation:

\- Contra Proferentem → ambiguity = in favour of insured  

\- Reasonable Expectations → courts may protect insured’s expectations



---





