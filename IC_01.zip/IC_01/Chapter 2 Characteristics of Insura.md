###                        Chapter 2: Characteristics of Insurable Risks

                                                                    ### Learning Outcome (a)

                                                             Understand what makes a risk insurable.



---



\## ✅ 1. Large Number of Homogeneous Exposure Units



\- Meaning:

  - Large number → Insurers need many similar policies so actual outcomes ≈ expected outcomes (Law of Large Numbers).

  - Homogeneous → Risks in the pool should have similar loss probabilities.

\- Why important:

  - Mixing very different exposures → mispricing \& adverse selection.

\- Example:

  - Grouping private cars with taxis → underpricing taxis or overpricing private cars.

\- Exam Tip:

  Homogeneity + Volume → Reliable pricing.



---



\## ✅ 2. Independence Among Exposure Units



\- Meaning:

  - Losses should occur randomly and not be correlated.

\- Why important:

  - If one event triggers many losses → accumulation risk.

\- Example:

  - Fire in a multi-unit complex → many claims at once.

\- Exam Tip:

  Independence ensures pooling works; correlated risks need reinsurance or limits.



---



\## ✅ 3. Expected Losses Should Be Calculable in Monetary Terms



\- Meaning:

  - Insurer must estimate probable loss amount in money terms.

\- How:

  - Use past data to estimate frequency × severity.

\- Example:

  - A painting can be insured only if market value is agreed; emotional value cannot be insured.

\- Exam Tip:

  Remember Expected Loss ≈ Frequency × Severity.



---



\## ✅ 4. Loss Should Be Definite (Time, Place, Amount, Cause)



\- Meaning:

  - Event must be identifiable: When, Where, How much, Why.

\- Why important:

  - Ambiguity → disputes or repudiation.

\- Example:

  - Mysterious disappearance of goods often not covered.

\- Exam Tip:

  If any of T/P/A/C uncertain → claim may be denied.



---



\## ✅ 5. Fortuitous Events



\- Meaning:

  - Loss must be accidental, unforeseen, not certain.

\- Why important:

  - If loss is certain or deliberate → moral hazard, premium meaningless.

\- Example:

  - Wear \& tear (certain) not covered; sudden accident is.

\- Exam Tip:

  “Fortuitous” = accidental/unexpected.



---



\## ✅ 6. Economic Feasibility



\- Meaning:

  - Insurance must make business sense: affordable premium, sufficient demand, manageable admin cost.

\- Why important:

  - Very high probability risks → premium too high → no market.

\- Example:

  - Covering ₹50 gadgets uneconomical (admin cost > claim value).

\- Exam Tip:

  Ask: “Can insurer design \& sell profitably?” If no → not insurable.



---



\## ✅ 7. Losses Should Not Be Catastrophic



\- Meaning:

  - Perils causing massive simultaneous losses (war, nuclear) often excluded.

\- Why important:

  - Catastrophes break independence assumption \& exceed insurer capacity.

\- Example:

  - Major earthquake → losses beyond insurer \& reinsurer capacity.

\- Exam Tip:

  Catastrophic = systemic accumulation risk → excluded or reinsured.



---



\### Quick Summary (One-Liners for Revision)

✅ Homogeneous + large pool → reliable estimates.

✅ Independence avoids accumulation; else reinsure.

✅ Loss measurable in money (frequency × severity).

✅ Loss definite (time/place/amount/cause).

✅ Event fortuitous (accidental, not certain).

✅ Must be economically feasible.

✅ Catastrophic losses → usually excluded or reinsured.



---

                                                                   Learning Outcome (b)

                                                   Understand what is a Peril, what is a Hazard, and their relationship.



---



\## ✅ 1. Peril



\- Definition:

  A peril is the cause of a loss.



\- Examples:

  Fire, flood, earthquake, theft, accident, riot, storm.



\- Illustration:

  - If a house burns down → Fire is the peril.

  - If crops are destroyed by flood → Flood is the peril.



---



\## ✅ 2. Hazard



\- Definition:

  A hazard is a condition that increases the chance of a peril occurring or increases the severity of loss caused by the peril.



\### Types of Hazards:



1\. Physical Hazard

   - Related to physical/tangible characteristics.

   - Example: Storing petrol in a godown → increases chance of fire.



2\. Moral Hazard

   - Dishonesty or intentional action by insured.

   - Example: Insured sets fire to own property to claim insurance.



3\. Morale Hazard

   - Carelessness due to presence of insurance.

   - Example: Not locking a car carefully because it’s insured.



---



\## ✅ 3. Relationship Between Peril and Hazard



\- Peril = Direct cause of loss.

\- Hazard = Condition that increases frequency or severity of a peril.

\- Hazards do not directly cause loss — they make the peril more dangerous.



\### Example:

\- Peril: Fire.

\- Hazards: Poor wiring, inflammable goods, negligence.



 (**Occupancy**:the purpose for which the building is used, e.g., residential houses, shops, restaurants, factories, utilities, storage facilities, offices)

---

| RISK                     | PERIL     | HAZARD        | REMARK                                                                                          |

|--------------------------|-----------|---------------|-------------------------------------------------------------------------------------------------|

| Fire and Allied Perils   | Fire      | Occupancy     | Similar buildings with different occupancies could have different loss probabilities..          |

| Fire and Allied Perils   | Fire      | Storage       | Warehouses storing inflammable goods have more hazard than those storing non-inflammable goods. |

| Fire and Allied Perils   | Fire      | Construction  | Wooden buildings are more hazardous than concrete buildings.                                    |

| Fire and Allied Perils   | Fire      | Location      | Goods stored in open could catch fire faster than those in enclosed buildings.                  |

| Fire and Allied Perils   | Flood     | Location      | Proximity to water bodies or storage in basement could be more hazardous.                       |

| Fire and Allied Perils   | Earthquake| Seismic Zone  | Some seismic zones have higher probability of earthquake occurrences.                           |

| Life Insurance           | Illness   | Age           | The higher the age, the higher the probability of death.                                        |

| Health Insurance         | Illness   | Age           | The higher the age, the higher the probability of illness.                                      |

| Employee Compensation    | Injury    | Trade         | Certain occupations such as construction work are more hazardous.                               |

| Money in Transit         | Robbery   | Mode of Transport | Money being carried in public transport is more hazardous.                                  |





---

                                                                      Learning Outcome (c): Risk Classification

                                             Understand what Risk Classification is, why it is needed, how it is done, and its importance.



---



\## ✅ 1. Need for Risk Classification



\- Purpose:

  To facilitate rating of risks according to their loss probabilities.



\- Supports Underwriting:

  - Underwriting = process of evaluating a risk, deciding whether to accept it, and on what terms/premium.

  - A classification system makes underwriting quicker and consistent, avoiding case-by-case analysis for every small risk.



\- Dynamic Nature of Risks:

  - Risks change with environment (climate, technology, human behavior).

  - Classification allows insurers to track changes and update rating factors accordingly.



✅ Why important:

Without classification → pricing becomes unfair (good risks subsidize bad ones) → leads to adverse selection (only high-risk customers buy insurance).



---



\## ✅ 2. What is Risk Classification?



\- Definition:

  Grouping of risks with the same coverage, based on common characteristics (hazards).



\- Basis:

  Hazard is the main factor for classification.



\- Example:

  Identical buildings insured against fire:

  - Residences → lowest rate

  - Offices → slightly higher

  - Shops → higher

  - Warehouses → highest



✅ Rule:

Greater the hazard → Higher the premium.



---



\## ✅ 3. Process of Risk Classification



1\. Identify hazards:

   - Study past loss experience.

   - Note perils and associated hazards.



2\. Select relevant hazards:

   - Avoid too many factors → system becomes complex.

   - Choose only those strongly influencing probability/severity of loss.



3\. Group risks based on these hazards.



4\. Apply rating accordingly.



---



\## ✅ 4. Factors Considered in Classification



\### (A) Actuarial Factors

\- Factor must have statistical relationship with probability of loss.

\- Example:

  - Life Insurance:

    - Age → directly linked to death rates → used.

    - Education level → no relation → not used.



\- Homogeneity:

  - Risks in a class must be similar.

  - If heterogeneous → bad risks underpriced, good risks overpriced → adverse selection → threatens solvency.



\- Predictive Stability:

  - Classification should accurately predict losses over time.

  - Must be based on sound actuarial analysis.



---



\### (B) Operational Factors

\- Classification should be easy to apply.

\- Complex systems → higher cost, slower underwriting.

\- Balance accuracy with practical usability.



---



\### (C) Social and Legal Factors

\- Government/regulator may require socially desirable rating practices.

\- Examples:

  - Health insurance pools → cannot charge excessively for old age.

  - Motor Third Party Liability → community rating.

\- Classification cannot be discriminatory beyond acceptable norms.



---



\## ✅ 5. Example in Practice



Motor Insurance:

\- Risk: Accident.

\- Hazards: Usage (private car vs taxi), Area (metro vs rural).

\- Classification:

  - Private car in small town → low risk → low premium.

  - Taxi in metro city → high risk → high premium.



---



\## ✅ 6. Importance for Insurance Companies

\- Correct premium based on nature of risk.

\- Efficient underwriting → faster decisions.

\- Financial stability → avoids underpricing bad risks.

\- Adaptability → helps track changing environment.



---



\## ✅ Key Technical Terms

\- Risk Classification: Grouping risks into categories with similar hazard characteristics for fair pricing.

\- Hazard: Factor that increases chance or severity of loss.

\- Homogeneity: Similarity of risks within a class.

\- Adverse Selection: Bad risks enter system more than good ones due to poor classification.

\- Predictive Stability: Accuracy of classification in forecasting losses.

\- Actuarial Basis: Statistical analysis of loss data for classification.



---



\## ✅ Exam-Ready Bullets

\- Purpose: Rating, underwriting, long-term risk study.

\- Basis: Hazards (occupancy, construction, usage, location, etc.).

\- Must ensure:

  - Actuarial relevance

  - Homogeneity

  - Predictive stability

\- Operational simplicity needed.

\- Social/legal considerations apply.

\- Poor classification → adverse selection.



---

