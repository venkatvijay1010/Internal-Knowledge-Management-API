# &nbsp;           📘 Chapter 5 — Principle of Insurance - TWO 



&nbsp;                                                                        Learning Outcome (a)  

&nbsp;                             Learn what Indemnity is and understand the need for Indemnity, how Indemnity works in different lines of business  



-----------------------------------------------------------------------------------------------



\### 🧩 Paragraph 1 — Chapter Introduction



Book essence:  

This chapter builds on previous chapters and will explain what Indemnity is, why Indemnity is required, and how Indemnity operates in different insurance lines.



Line-by-line explanation:

\- “Builds on previous chapters” → assumes you know Utmost Good Faith and Insurable Interest (these three principles work together).

\- Goals: define indemnity, justify it (policy/social reasons), and show practical application (how claims are measured/paid across fire, motor, marine, life, health, etc.).



Technical terms: None new here; sets the scope.



Exam tip:  

If asked “what will Chapter 5 cover?”, give three bullets:

\- Definition  

\- Purpose  

\- Practice across lines



-----------------------------------------------------------------------------------------------



\### 🧠 Paragraph 2 — What is Indemnity? (Direct Definition)



Book essence:  

“Indemnity is the most important principle of insurance. Simply stated, indemnity means placing the insured in the same financial position as he was prior to the insured loss. In simple terms, indemnity means compensating a person for the financial loss he suffered due to an insured peril.”



Line-by-line explanation:

\- “Most important principle” — indemnity underpins how compensation is calculated and limits insurer liability.

\- “Placing the insured in the same financial position” — the insured should be neither better off nor worse off after the claim; the objective is restoration, not gain.

\- “Compensating for financial loss due to an insured peril” — indemnity applies only when loss is caused by a peril covered by the policy (fire, theft, accident, etc.).



Technical terms:

\- Insured peril — the event/peril covered by the policy wording (e.g., fire, flood).

\- Financial position — economic state measured in money (market value, replacement cost, etc.).



Example:  

Car worth ₹5,00,000 destroyed in accident → indemnity aims to put the owner back to position equivalent to owning a ₹5,00,000 car (subject to policy limits/deductions).



Exam tip:  

Always start your answer with the textbook line “restore to same financial position as before the loss” and mention “not to profit.”



-----------------------------------------------------------------------------------------------



\### ⚖️ Paragraph 3 — Landmark Authority (Castellain v Preston Quote)



Book essence:  

Lord Justice Brett (Castellain v Preston, 1883): the contract in a marine or fire policy is a contract of indemnity only — the assured shall be fully indemnified but never more than fully indemnified.



Line-by-line explanation:

\- Classic legal authority establishing the indemnity principle.

\- “Fully indemnified but never more than fully indemnified” = no over-compensation; insurer’s liability is limited to actual loss.



Technical terms:

\- Fully indemnified = compensated for actual financial loss.

\- More than fully indemnified = situation where insured would profit from a loss (disallowed).



Exam tip:  

Quote the “fully indemnified but never more than fully indemnified” line and name Castellain v Preston (1883) — examiners like the case reference.



-----------------------------------------------------------------------------------------------



\### 🔒 Paragraph 4 — Why Indemnity? (Moral \& Social Reasons)



Book essence:  

If people received more than their actual loss, they might be tempted to create losses (arson, fraud). This would destroy the insurance mechanism and harm society. Therefore indemnity prevents moral hazard and fraud.



Line-by-line explanation:

\- “People could get more compensation than actual loss” → that would be profit-making from misfortune.

\- “Tempted to create losses” → moral hazard: if insured can profit from a loss, incentives to cause or exaggerate loss increase.

\- “Breakdown of insurance mechanism” → pooling of risk relies on honest transfers; profit from loss breaks pooling and causes unsustainable losses and social harm.



Technical terms:

\- Moral hazard — increased likelihood of risky or dishonest behaviour because someone else bears the cost (insurer).

\- Insurance mechanism — pooling premiums to pay for losses of the few.



Example:  

If someone can insure a neighbour’s house for profit, they could burn it to collect — indemnity prevents such perverse incentives.



Exam tip:  

When explaining “why indemnity?”, list moral hazard, fraud, and systemic instability as three short reasons.



-----------------------------------------------------------------------------------------------



\### 📝 Paragraph 5 — Indemnity in Insurance Contracts (Intro to Practice)



Book essence:  

We will now see how indemnity functions in practice. But first note: not all insurance contracts are contracts of indemnity — many are benefit (sum-insured) contracts (life, personal accident). We will later see which are not indemnity based.



Line-by-line explanation:

\- Transition from theory to practice.

\- Important distinction: indemnity contracts (where payment = actual loss) vs benefit contracts (fixed payment irrespective of actual loss).



Technical terms:

\- Indemnity contract — insurer indemnifies actual loss (e.g., fire, motor).

\- Benefit contract (non-indemnity) — insurer pays pre-agreed benefit (e.g., life insurance, personal accident).



Example:  

Fire policy → indemnity; Life policy → benefit (sum assured).



Exam tip:  

In answers contrast one indemnity example (fire/motor) with one benefit example (life/PA) — short and clear.



-----------------------------------------------------------------------------------------------



\### 💰 Paragraph 6 — “Financial Position” — Cost vs Value



Book essence:  

To apply indemnity we must understand what “financial position” means — is it cost or market value? The book introduces Scenario A (Vishal \& flood loss) to illustrate this.



Line-by-line explanation:

\- “Financial position” needs quantification: should compensation be based on what the insured originally paid (cost) or what the item was worth at the time/place of loss (value)?

\- Insurance law usually uses value at time/place of loss (market value) — because that reflects what the insured actually lost economically.



Technical terms:

\- Cost = historical purchase price paid by insured.

\- Value (market value) = prevailing price in market at date/place of loss.



Exam tip:  

Use the phrase:  

\_“Indemnity measures loss by value at date \& place of loss (market value), not historical cost.”\_



-----------------------------------------------------------------------------------------------



\### 📦 Paragraph 7 — Scenario A (Vishal: 100 Cement Bags)



Book scenario:  

Vishal bought 100 cement bags at ₹360 each on 1 July. On 1 Oct all 100 bags were lost in flood. Market price on 1 Oct = ₹400 per bag.



Line-by-line explanation:

\- Cost = 100 × ₹360 = ₹36,000  

\- Market value = 100 × ₹400 = ₹40,000  

\- Indemnity = ₹40,000 (market value) — because indemnity aims to restore market position at loss date.



Explanation of consequences:

\- If insurer paid only ₹36,000, Vishal would be under-compensated by ₹4,000 → worse off than before the loss → violates indemnity principle.



Technical term:

\- Replacement / market value — the price to replace the lost item at the time/place of loss.



Exam tip:  

Memorise the short rule:  

\_Indemnity = market value at date \& place of loss (unless policy specifies otherwise).\_  

Use the cement bags example to illustrate.



-----------------------------------------------------------------------------------------------



\### 🛠️ Paragraph 8 — Indemnity Modes (How Insurers Make Good Losses)



Book essence:  

Indemnity is usually made by paying money; but insurers may also: pay repairers directly (automobile), pay hospitals directly under cashless, arrange replacement, or reinstate machinery if policy has a reinstatement clause (no depreciation then).



Line-by-line explanation:

\- “Paying money” — the commonest mode is cash payment equal to assessed loss.

\- “Pay repairer” — insurer may contractually pay garages/hospitals directly (cashless or direct billing).

\- “Arrange replacement/reinstatement” — insurer may replace the lost item with a new equivalent machine/building (especially where policies specify reinstatement).



Technical terms:

\- Cashless arrangement — insurer settles hospital bill directly with provider; insured doesn’t pay up front.

\- Reinstatement clause — policy clause that allows insurer to replace/recreate the asset without applying depreciation (subject to conditions).



Example:  

Windscreen damage: insurer arranges manufacturer to replace glass — insured gets replacement, not cash.



Exam tip:  

List 3 modes:  

\- Cash payment  

\- Direct repair/replacement  

\- Reinstatement  

Tie each to a line (motor, health, industrial machinery).



-----------------------------------------------------------------------------------------------



\### 📐 Paragraph 9 — Detailed Measurement Rules by Line



Book essence:

\- Machines partially damaged → repair costs paid in full; replaced parts attract depreciation.

\- Building → cost of constructing similar new building less appropriate depreciation.

\- Motor → total loss = market value at date of loss; repairs = repair costs paid, but depreciation on new parts applied (unless zero depreciation clause).

\- Health → cashless or reimbursement of medical costs.

\- Liability → insurer reimburses insured for court–ordered compensation.



Line-by-line explanation:

\- Machines: labour = full; parts = depreciated.

\- Buildings: new cost − depreciation (straight-line).

\- Motor: market value for total loss; depreciation on parts unless zero dep clause.

\- Health: depends on hospitalization clause.

\- Liability: insurer pays legal award.



Technical terms:

\- Depreciation — allowance for wear \& tear/age; reduces claim amount.

\- Zero Depreciation Clause — rider removing depreciation on replaced parts.



Worked mini-calculation (Building Example D):

\- Life = 50 years; Age = 20 years; New cost = ₹50,00,000  

\- Remaining life = 30 years  

\- Indemnity = ₹50,00,000 × (30/50) = ₹30,00,000



Exam tip:  

Memorise per-line rule and D’s house calculation.



-----------------------------------------------------------------------------------------------



\### 📜 Paragraph 10 — Policy Clauses That Modify Indemnity



Book essence:  

Policies may carry special clauses: Reinstatement Clause, Zero Depreciation, and other terms which alter normal indemnity measurement. Always check policy wording.



Line-by-line explanation:

\- Reinstatement clause → no depreciation on replacement (subject to limits).

\- Zero Depreciation → removes deduction on parts (motor insurance).

\- Always check wording → policy terms override textbook rules.



Technical terms:

\- Rider — optional addition to base policy for extra cover.

\- Policy wording — contract terms that determine cover and measure of indemnity.



Exam tip:  

If a question gives a clause (reinstatement/zero dep), always state how it changes normal depreciation rules.



-----------------------------------------------------------------------------------------------



\### ⚠️ Paragraph 11 — Practical Caveats \& Summary



Book essence:  

Indemnity aims to restore economic position, but in practice there are many adjustments (depreciation, deductibles, policy limits, underinsurance clauses). The exact method is laid down by the policy terms.



Line-by-line explanation:

\- “Many adjustments” — check for deductibles/excess, limits, co-pay, underinsurance formulae.

\- “Method laid down by policy” — policy is the primary source of how indemnity is measured.



Technical terms:

\- Deductible/Excess — amount insured must bear before insurer pays.

\- Underinsurance — when sum insured < value at risk; leads to proportionate reduction.



Exam tip:  

Always state:  

\_“Apply policy wording — check for reinstatement, zero dep, deductibles \& sum insured”\_ when answering claim valuation questions.



-----------------------------------------------------------------------------------------------



\### 📚 Short Consolidated Glossary



| Term                  | Definition |

|-----------------------|------------|

| Indemnity         | Restore insured to pre-loss financial position; no profit. |

| Insured peril     | Event covered under policy (fire, theft). |

| Market value      | Value at date/place of loss; used for indemnity. |

| Depreciation      | Deduction for age/wear on replaced parts/buildings. |

| Reinstatement clause | Allows replacement without depreciation (subject to terms). |

| Zero Depreciation | Rider removing depreciation on new parts (motor). |



-----------------------------------------------------------------------------------------------



\### ✅ Final Exam-Ready Checklist



\- Indemnity = restore to same financial position as before loss (not cost).

\- Use market value at date/place of loss unless policy says otherwise (cement example: pay ₹40,000 not ₹36,000).

\- Distinguish indemnity contracts (fire/motor/marine/health reimbursement) from benefit contracts (life/PA/critical illness).

\- Modes of indemnity: cash payment, direct repair/payment to provider, replacement/reinstatement.

\- Per-line rules (machines/buildings/motor/health/liability) — memorise the short rule for each and the sample building depreciation formula:  

&nbsp; \_payment = new cost × (remaining life / total life)\_ → D’s house = ₹30,00,000.

\- Watch for policy clauses (reinstatement, zero dep), deductibles/excess, limits and underinsurance rules (next LO).



-----------------------------------------------------------------------------------------------





-----------------------------------------------------------------------------------------------



&nbsp;                                                                                Learning Outcome (b)



> ✅ “Learn the different modes of Indemnity, the Limits of Indemnity and also study Insurance Contracts which are not Contracts of Indemnity.”



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 1 — Heading / opening (what this LO covers)



PDF idea: LO (b) explains (A) how indemnity is actually delivered (modes), (B) what limits reduce the indemnity (deductible, underinsurance, salvage, policy limits, depreciation, etc.), and (C) which insurance contracts do NOT follow indemnity (benefit contracts).



Explanation (line by line):



\- “Modes of Indemnity” = how insurers make good a loss (cash payment, direct payment to providers, replacement, reinstatement).

\- “Limits of Indemnity” = situations/clauses that reduce what insurer pays (deductibles/co-pay, underinsurance or condition of average, salvage, sum insured caps, depreciation).

\- “Insurance contracts not of indemnity” = life, personal accident, critical illness — these pay pre-agreed sums (benefit policies) rather than compensating actual loss.



📌 Exam tip:  

> When exam asks “LO b”, answer in three parts:  

> ✅ modes → ✅ limits → ✅ non-indemnity contracts.



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 2 — Modes of Indemnity (full paragraph from PDF)



PDF text (essence): Indemnity is usually given by paying money to the insured. In some cases the insurer pays the repairer (automobile), or hospital (cashless), or reimburses the insured after they pay. Insurer may arrange replacement (e.g., windscreen) or reinstate machinery (if Reinstatement Clause exists — then no depreciation).



Line-by-line explanation



1\. “Usually by paying money” — standard mode: insurer assesses loss and pays cash equal to admissible loss (subject to policy terms).



2\. “Pay repairer” — insurer may settle the repair bill directly with garage/contractor (common in motor own-damage repairs). This avoids insured having to pay and claim later.



3\. “Cashless hospitalisation” — insurer settles hospital bill directly through network hospitals; insured needn’t pay (subject to limits).



4\. “Reimbursement” — insured pays out of pocket first, then submits bills to insurer for refund.



5\. “Replacement” — insurer arranges supplier/manufacturer to supply replacement part (e.g., windscreen), rather than paying cash.



6\. “Reinstatement Clause” — if present, insurer may pay cost to replace or reinstate the lost asset with a new item of same capacity; in such cases no depreciation is applied on the new item. This makes the insured whole in replacement terms.



📌 Illustration:  

Car damage — insurer either pays garage directly (repair) or reimburses you after you pay; if total loss, insurer may buy/replace the vehicle (if policy allows).



📌 Exam tip:  

> List 4 modes:  

> ✅ cash payment,  

> ✅ direct repair/replacement,  

> ✅ reimbursement,  

> ✅ reinstatement — and tie each to a line (motor, health, industrial machinery).



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 3 — Limits to Indemnity (intro)



PDF text (essence): Although indemnity aims to restore pre-loss position, in practice the amount paid can be less than full loss — for several reasons that follow.



Explanation: This paragraph just introduces the idea that policy clauses and rules often reduce payable amount (so indemnity is subject to limits). The following paragraphs list those reasons.



📌 Exam tip:  

> Start answers with “indemnity subject to limits — main ones: deductibles, underinsurance, salvage, policy limits, depreciation”.



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 4 — Deductibles / Excess (full paragraph)



PDF text (essence): Many policies require the insured to bear a specified amount or percentage of loss — that amount is deducted from payable claim. Called Deductible or Excess. Reasons: (a) avoid small/administrative claims, (b) encourage insured to minimise losses. In health this is called Co-pay (e.g., insured bears 20% of hospital bill).



Line-by-line explanation



\- Definition: Deductible/Excess = fixed rupee amount or % of admissible loss the insured must pay first; insurer pays balance. Example: ₹25,000 deductible or 5% of claim.

\- Why imposed — (a) avoid small claims: small claims cost admin effort; a deductible discourages trivial claims.

\- Why imposed — (b) encourage loss control: when insured bears part of loss, they are incentivised to prevent or reduce loss.

\- Health insurance term: Co-pay = insured pays specified % of each claim (e.g., 20% co-pay on ₹60,000 hospital bill means insured pays ₹12,000, insurer pays ₹48,000). (This exact example appears in the PDF Q\&A).



📌 Worked numeric mini-example (from PDF):  

Hospital bill = 60,000; Co-pay = 20% → insured pays 0.20 × 60,000 = 12,000 → insurer pays 60,000 − 12,000 = 48,000.



📌 Exam tip:  

> If question gives deductible or co-pay, compute insurer’s payable =  

> ✅ Admissible loss − Deductible  

> ✅ or = Admissible loss × (1 − co-pay%).



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 5 — Underinsurance (Condition of Average) — definition and logic



PDF text (essence): Underinsurance (Condition of Average) is applied when Sum Insured < Value at Risk. If underinsured, amount payable is reduced proportionately. It's a penalty motivating insured to insure for full exposure; the formula and numeric example follow.



Line-by-line explanation



\- Value at Risk = true value of property/exposure (e.g., stock value).

\- Sum Insured = amount for which insured actually insured the property.

\- If Sum Insured < Value at Risk (i.e., underinsurance), insurer pays only a proportion of the loss = Loss × (Sum Insured / Value at Risk). This proportion is ≤ 1, so insured bears the shortfall.

\- Why: To prevent people from insuring for less than full exposure (and paying less premium) yet expecting full indemnity. Underinsurance enforces fairness and correct premium charging.



📌 Key formula (plain math):  

✅ Amount payable after underinsurance = Loss × (Sum Insured / Value at Risk)



📌 Exam tip:  

> Always check whether an underinsurance clause applies (property/stock policies generally yes; motor/health often no).



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 6 — RST Chemicals worked example (step-by-step)



PDF example (paraphrase \& compute):



\- Value at Risk = ₹15 crores  

\- Sum Insured = ₹10 crores  

\- Loss = ₹3 crores



Underinsurance = Value at Risk − Sum Insured = 15 − 10 = ₹5 crores → percentage underinsurance = 5/15 = 33.33%.



Amount payable after underinsurance = Loss × (Sum Insured / Value at Risk) = 3 × (10/15) = 3 × 0.666666... = ₹2 crores.  

✅ So insurer pays ₹2 crores, insured bears ₹1 crore.



📌 Step-by-step arithmetic shown clearly:



1\. Sum Insured / Value at Risk = 10 / 15 = 0.666666...  

2\. Loss × 0.666666... = 3,00,00,000 × 0.6666... = 2,00,00,000  

3\. ✅ So payable = ₹2 Crore



📌 Exam tip:  

> When a question gives Value at Risk, Sum Insured and Loss, plug into the formula exactly (show fraction or decimal) — examiners expect the formula and a correct numeric simplification.



-----------------------------------------------------------------------------------------------



\### ✅ Paragraph 7 — Which policies DO/DO NOT have underinsurance clause



PDF text (essence): Property/fire policies generally have the underinsurance (average) clause. But many indemnity policies do not have it — e.g., motor insurance, health insurance, liability policies (these often have limits like Any One Accident but not average clause).



Explanation



\- Property / stock policies: underinsurance commonly applies because value fluctuates with inventory.

\- Motor / Health: typically do not apply average clause — motor market practice and statutory frameworks differ; health uses co-pay/deductible instead.

\- Liability: indemnity is limited by policy limits (Any One Accident) rather than average proportion.



📌 Exam tip:  

> Memorise exceptions: motor and health generally do not have underinsurance clause.



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 8 — Salvage (definition \& effect)



PDF text (essence):  

Salvage = residual value recoverable from damaged property (scrap, partially usable goods). Salvage value is deducted from claim payable; insurer often arranges sale and offsets salvage realisation before payment.



Line-by-line explanation:



\- ✅ Definition: Salvage = money realised by selling the damaged remains (scrap, salvageable parts).

\- ✅ Why deducted: because insurer is indemnifying net economic loss; any recoverable value reduces net loss.

\- ✅ Practical: insurer may take possession of damaged goods, sell them and deduct proceeds from payout.



📌 Example:  

Damaged machine has residual scrap value ₹50,000; admissible loss = ₹5,00,000 → insurer deducts ₹50,000 → net payable = ₹4,50,000.



📌 Exam tip:  

> When computing payable amount, always subtract salvage (unless policy wording says otherwise).



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 9 — Policy Limits / Sum Insured / Any One Accident Limit



PDF text (essence):  

Policies specify a maximum payable amount called Sum Insured. If loss > Sum Insured, insurer pays only up to Sum Insured. In liability policies payment is limited by Any One Accident limit; even court awards above that are capped. Example: JKL Traders lost ₹5 Cr but insured for ₹4 Cr → insurer pays ₹4 Cr.



Explanation:



\- ✅ Sum Insured = maximum contractual cap on insurer liability for that policy/period.

\- ✅ Effect: insurer’s liability cannot exceed Sum Insured even if actual loss higher.

\- ✅ Liability policies: usually have an "Any One Accident" or aggregate limit; insurer pays only up to that limit per accident.



📌 Exam tip:  

> Always compare actual loss vs Sum Insured.  

> If loss > SI → payable is at most SI (subject to other deductions).



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 10 — Depreciation, Reinstatement, Zero Depreciation (quantum adjustments)



PDF text (essence):  

When computing quantum, surveyors and claims teams apply depreciation on replaced parts (age/wear). Policies with Reinstatement Clause may avoid depreciation for full reinstatement. Motor zero-depreciation rider removes depreciation on spare parts. The PDF gives D’s house example (life 50 years, age 20, new build cost 50,00,000 → payable 50,00,000 × (30/50) = 30,00,000).



Line-by-line explanation:



\- ✅ Depreciation = allowance to reflect wear \& tear / age; reduces replacement value to reflect actual economic loss of old asset.

\- ✅ Reinstatement clause = insurer funds replacement/reconstruction to same standard and may not apply depreciation, subject to terms.

\- ✅ Zero Depreciation rider = common in motor: insurer will not deduct depreciation on new spare parts (insurer charges extra premium for this rider).



📌 D’s house worked example (step-by-step):



\- Total life = 50 years; current age = 20 years → remaining life = 30 years.

\- New cost to build similar = 50,00,000.  

\- Using straight-line method:  

&nbsp; ✅ value = new cost × (remaining life / total life) = 50,00,000 × (30/50) = 50,00,000 × 0.6 = ₹30,00,000  

&nbsp; ✅ So payable = ₹30,00,000.



📌 Formula (building depreciation method used in PDF):  

✅ Payment = New Cost × (Remaining Life / Total Life)



📌 Exam tip:  

> If they give building life/age/new cost, use the formula exactly as above; show the fraction (remaining / total).



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 11 — Deductibles (types) and how they are applied (more detail)



PDF text (essence):  

Deductibles may be absolute (fixed Rs amount) or percentage of claim. Example: absolute deductible Rs 25,000; percentage deductible 5% of each claim. Deductibles are subtracted from admissible amount.



Explanation:



\- ✅ Absolute deductible: payable = Admissible loss − fixed deductible.  

&nbsp; Example: loss 1,00,000; deductible 25,000 → insurer pays 75,000.

\- ✅ Percentage deductible: payable = Admissible loss × (1 − deductible%).  

&nbsp; Example: loss 1,00,000; deductible 5% → insurer pays 95,000.

\- ✅ Co-pay (health) functions like a percentage deductible.



📌 Exam tip:  

> Watch whether deductible is before or after other adjustments — usually after admissible loss calculated, then apply deductible.



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 12 — Quantum (complete loss assessment) and supporting evidence



PDF text (essence):  

Once admissibility decided, the Claims team assesses the quantum — many adjustments (depreciation, underinsurance, deductibles, salvage). Loss assessment must be supported by evidence: invoices, photographs, fire brigade reports, cost workings, excise records, etc. No element of profit should be included; it’s a cost basis exercise.



Line-by-line explanation:



\- ✅ Assessment is not arithmetic only — claims team must verify documents, corroborate costs and ensure only actual cost is included (no profit margin).

\- ✅ Typical supporting docs: purchase invoices, sales invoices, inventory records, photos, meteorological reports (for flood), fire brigade report (for fire), repair bills, hospital bills.

\- ✅ Adjustments to check: dead stock, improved performance of new asset, uncovered items.



📌 Exam tip:  

> Mention evidence list if asked “how is quantum assessed?” — examiners expect both the arithmetic adjustments and the documentary corroboration.



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 13 — Insurance Contracts which are NOT Indemnity based (short section)



PDF text (essence):  

Some contracts pay a pre-agreed sum irrespective of actual loss — these are benefit policies (Life Insurance, Personal Accident, Critical Illness). They do not follow indemnity rules (e.g., no underinsurance, no subrogation).



Line-by-line explanation:



\- ✅ Life insurance = benefit (sum assured) policy — pays fixed sum on death or specified event; insurer does not attempt to measure the deceased’s exact financial loss.

\- ✅ Personal Accident / Critical Illness = fixed benefit per event (e.g., lump sum for disability) — not indemnity.

\- ✅ Implication: do not apply underinsurance formula, depreciation rules, salvage, or subrogation in the same way; different legal treatment.



📌 Exam tip:  

> If question asks “is life insurance indemnity?” answer:  

> ❌ No — life = benefit contract; give reason (human life not valued monetarily).  

> ✅ Cite Castellain logic contrast if useful.



-----------------------------------------------------------------------------------------------



\## ✅ Paragraph 14 — Short examples / self-test references in the PDF (useful to practice)



PDF includes practice Qs / answers:



\- ✅ Underinsurance calculation example (100 bags etc. giving payable ₹75,000).

\- ✅ Question on co-pay (Raju) — shows co-pay arithmetic (paid = 48,000).

\- ✅ D’s house exam MCQ showing depreciation method (payable ₹30,00,000).



📌 Use these practice items to rehearse:



\- ✅ The formulas  

\- ✅ The order of adjustments



📌 Common safe sequence for a property claim:



1\. ✅ Determine Gross Loss (market/replacement value at place/date)  

2\. ✅ Subtract Salvage (if any) → Net loss  

3\. ✅ If Underinsurance applies → multiply by (Sum Insured / Value at Risk)  

4\. ✅ Subtract Deductible / apply Co-pay  

5\. ✅ Cap at Sum Insured (policy limit)  

6\. ✅ Result = Amount payable  

7\. ✅ If Reinstatement or special clause exist, follow wording instead



-----------------------------------------------------------------------------------------------



\## ✅ Final concise formula sheet (one-line definitions — memorise these)



| Concept | Formula |

|--------|---------|

| ✅ Underinsurance formula | Amount payable = Loss × (Sum\_Insured / Value\_at\_Risk) |

| ✅ Building depreciation (straight-line method used in PDF) | Payment = New\_Cost × (Remaining\_Life / Total\_Life) |

| ✅ Co-pay | Insurer\_pays = Loss × (1 − co\_pay%) |

| ✅ Deductible (absolute) | Insurer\_pays = Max(0, Loss − Deductible\_Rs) |

x

-----------------------------------------------------------------------------------------------



