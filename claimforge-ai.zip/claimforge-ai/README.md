# ClaimForge AI

AI-native insurance claims intelligence platform. Full architecture, ER
diagrams, and the original 16-section design doc are in
`ClaimForge-AI-Design.md` (delivered separately). This repo implements
**all 8 weeks** of that plan.

## What's implemented

**Foundation & Auth**
- Clean-architecture layout: `domain/` (framework-free) -> `services/` -> `repositories/` -> `infrastructure/`
- Full auth lifecycle: register, login, **refresh (with rotation)**, **logout**, **email verification**, **password reset request/confirm**
- Refresh tokens are stateless JWTs whose SHA-256 hash is also stored server-side, so logout/reset can actually revoke a session — a bare JWT can't be revoked otherwise
- Password reset and email-verification "request" endpoints never reveal whether an email exists (anti-enumeration)
- RBAC via `require_role()`; admin endpoints for listing/managing users and roles

**Claims Core & Async Pipeline**
- Claim submission with real multipart document upload, validated against size/type/count rules
- Storage adapter (`Protocol`): `LocalDiskStorageClient` for dev, `S3StorageClient` for prod — swap is one function (`build_storage_client()`)
- Document listing + presigned download URLs (`GET /claims/{id}/documents`, `GET /claims/{id}/documents/{doc_id}/download-url`)
- Celery + Redis, separate `extraction`/`scoring` queues, retry with backoff
- **Dead-letter queue is fully wired**: on final task failure, a `FailedTask` row is persisted via a dedicated sync DB session (Celery's `on_failure` hook runs outside any event loop), visible via `GET /admin/failed-tasks`
- **Celery Beat has real scheduled jobs**: hourly re-scoring of stale `REVIEW` claims, daily expired-refresh-token cleanup

**AI Extraction & Risk Scoring**
- OCR (Tesseract, with a no-op fallback if the binary isn't installed) feeding LLM extraction (OpenAI or Ollama, via `LLM_PROVIDER`)
- LLM output validated against a Pydantic schema before it's ever written to the DB
- Redis-backed extraction cache keyed by document content hash
- Rule-based risk scorer — five explainable signals combined into a 0-100 score / LOW-MEDIUM-HIGH tier
- Every automated transition and manual override writes an **append-only** audit log entry (`GET /claims/{id}/audit-log`)

**Observability & Deployment**
- Structured JSON logging, request-ID middleware, Prometheus `/metrics`, Grafana dashboard JSON
- Dev stack: `docker/docker-compose.yml`. Prod-shaped stack: `docker/docker-compose.prod.yml` (Nginx, replicas, Gunicorn+Uvicorn, monitoring)
- GitHub Actions: `ci.yml` (lint -> test with real Postgres+Redis service containers -> Docker build), `deploy.yml` (tag-triggered, pushes to GHCR)
- Pre-commit hooks (Ruff, Black, hygiene checks)
- Hand-written initial Alembic migration (`alembic/versions/0001_initial_schema.py`) matching every table/constraint/index in `models.py`

## A bug this review caught and fixed
`ClaimService._store_file` was persisting the storage adapter's **display URI**
(`s3://bucket/key`) as `Document.storage_path`, but `download()` and
`get_presigned_url()` both expect a **bare key**. That would have silently
broken every document download and every extraction-pipeline read in
production. Fixed, and locked in with a regression test
(`tests/unit/test_claim_service_storage.py`).

## What I could not verify — read this before you trust it
I don't have network access in the sandbox that built this, so I could not
`pip install` the dependencies or actually run the app, migrations, or test
suite. Everything below was verified **statically**, not by execution:
- All 53 Python files parse cleanly (`ast.parse`)
- Every internal `from app.X import Y` resolves to a symbol that actually
  exists in module X (custom cross-reference checker, not a real import)
- The Alembic migration's table creation order is FK-dependency-safe (checked programmatically)

What that does **not** catch: runtime type errors, SQLAlchemy relationship
misconfigurations that only surface on first query, Pydantic version-specific
validation behavior, and anything that only fails when real Postgres/Redis/an
LLM are involved. **Before you rely on this — for an interview, a demo, or
real use — you need to actually run it:**

```bash
cp .env.example .env
docker compose -f docker/docker-compose.yml up --build
docker compose -f docker/docker-compose.yml exec api alembic upgrade head
docker compose -f docker/docker-compose.yml exec api python -m scripts.seed_dev_data
pytest tests/unit -v
```
If `alembic upgrade head` fails, or `pytest` fails, that's real signal I
couldn't get here — fix forward from actual error output, which will be far
more reliable than anything I can predict without running it. Claude Code is
a better environment for that iteration loop than continuing in chat.

## What's still a deliberate placeholder (not silently missing)
- `deploy.yml`'s final deploy step is a placeholder `curl` to a deploy-hook URL — point it at your actual platform (Render/Railway deploy hook, or an AWS ECS CLI call) once you pick one. I cannot deploy this for you; I have no cloud credentials.
- `SesEmailClient` needs a verified SES sending domain and AWS credentials in production — `ConsoleEmailClient` (dev default) logs the verification/reset link instead of sending it, which is how you'll grab tokens for local testing.
- Full end-to-end integration tests are scaffolded with the intended flow documented in `tests/integration/test_claims_api.py`, but the DB-dependent one is marked `skip` — wire it into a CI job once you point it at the `postgres`/`redis` service containers already defined in `ci.yml`.
- No rate-limiting beyond Nginx's `limit_req` at the edge — no per-user API rate limits.
- `audit_logs`' append-only guarantee is enforced by *not exposing* an update/delete method on the repository — it is **not yet enforced at the DB permission level** (a dedicated low-privilege Postgres role with UPDATE/DELETE revoked). That's a deploy-time provisioning step, noted in the migration file's docstring, not something a portable migration should do.

## Production hardening checklist (before this touches real claims data)
- [ ] Run `alembic revision --autogenerate` against a real DB and confirm it generates an *empty* migration (proves `0001_initial_schema.py` matches `models.py` with zero drift)
- [ ] Create a low-privilege Postgres role for the app; `REVOKE UPDATE, DELETE ON audit_logs FROM app_role`
- [ ] Replace `JWT_SECRET_KEY` default (the app already refuses to boot in `ENV=production` with the placeholder — see `core/config.py`)
- [ ] Point `SesEmailClient` at a verified sending domain, or swap in SendGrid/Postmark behind the same `EmailClient` protocol
- [ ] Add real request-rate limiting per user/API key, not just per-IP at Nginx
- [ ] Load-test the Celery extraction pipeline before assuming the queue depth/worker-count numbers in `docker-compose.prod.yml` are right for your volume

## Run it locally
```bash
cp .env.example .env
docker compose -f docker/docker-compose.yml up --build
docker compose -f docker/docker-compose.yml exec api alembic upgrade head
docker compose -f docker/docker-compose.yml exec api python -m scripts.seed_dev_data
```
- API: http://localhost:8000/docs
- Health: http://localhost:8000/healthz, /readyz
- Metrics: http://localhost:8000/metrics

## Run the production-shaped stack
```bash
export DATABASE_URL=... JWT_SECRET_KEY=... AWS_ACCESS_KEY_ID=... # etc — see .env.example
docker compose -f docker/docker-compose.prod.yml up --build
```
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (default admin password: `admin`, override with `GRAFANA_ADMIN_PASSWORD`)

## Run tests
```bash
pip install -e ".[dev]"
pytest tests/unit -v          # no DB/Docker needed — domain logic + mocked services
pytest tests/integration -v   # one live test (health check), one documented+skipped
```

## Try the API end to end
```bash
# 1. Register (creates an unverified user)
curl -X POST localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"adjuster@claimforge.ai","password":"supersecret1","full_name":"Jane Adjuster"}'

# 2. Verify email — in dev, ConsoleEmailClient logs the link. Check container
#    logs for the token, then:
curl -X POST localhost:8000/api/v1/auth/verify-email -H "Content-Type: application/json" \
  -d '{"token":"<token from the log>"}'

# 3. Login
curl -X POST localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"adjuster@claimforge.ai","password":"supersecret1"}'

# 4. Submit a claim (POL-001 exists after running the seed script)
curl -X POST localhost:8000/api/v1/claims \
  -H "Authorization: Bearer <access_token>" \
  -F "policy_number=POL-001" -F "claimed_amount=2500" -F "documents=@bill.pdf"

# 5. Check status + risk score, once the pipeline runs
curl localhost:8000/api/v1/claims/<claim_id> -H "Authorization: Bearer <access_token>"

# 6. Audit trail — login as the seeded dev admin instead (manager/admin only):
curl -X POST localhost:8000/api/v1/auth/login -H "Content-Type: application/json" \
  -d '{"email":"admin@claimforge.dev","password":"devpassword123"}'
curl localhost:8000/api/v1/claims/<claim_id>/audit-log -H "Authorization: Bearer <admin_access_token>"

# 7. Refresh / logout
curl -X POST localhost:8000/api/v1/auth/refresh -H "Content-Type: application/json" \
  -d '{"refresh_token":"<refresh_token>"}'
curl -X POST localhost:8000/api/v1/auth/logout -H "Content-Type: application/json" \
  -d '{"refresh_token":"<refresh_token>"}'
```

## Interview prep, resume bullets, weekly milestones
See `ClaimForge-AI-Design.md` sections 14-16 for the resume entry, 30 interview
questions, and the original week-by-week plan this repo followed.
