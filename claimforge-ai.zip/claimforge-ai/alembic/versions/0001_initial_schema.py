"""initial schema

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-07-19

NOTE ON PROVENANCE: this migration was hand-written to match
app/infrastructure/db/models.py exactly, rather than generated via
`alembic revision --autogenerate`, because that command needs a live
Postgres connection that wasn't available in the environment this was
built in. Before your first real deploy, run:

    alembic upgrade head          # apply this migration
    alembic revision --autogenerate -m "check drift"   # should generate an EMPTY migration

If that second command generates anything other than an empty upgrade/
downgrade, it means this file has drifted from models.py somewhere —
compare the two and fix whichever is wrong before proceeding.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("full_name", sa.String(255), nullable=False),
        sa.Column("role", sa.String(20), nullable=False, server_default="adjuster"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("is_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.CheckConstraint("role IN ('adjuster','manager','admin')", name="ck_users_role"),
        sa.UniqueConstraint("email", name="uq_users_email"),
    )
    op.create_index("ix_users_email", "users", ["email"])

    op.create_table(
        "refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.UniqueConstraint("token_hash", name="uq_refresh_tokens_token_hash"),
    )
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])

    op.create_table(
        "policies",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("policy_number", sa.String(50), nullable=False),
        sa.Column("policyholder_name", sa.String(255), nullable=False),
        sa.Column("coverage_limit", sa.Numeric(12, 2), nullable=False),
        sa.Column("effective_date", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expiry_date", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("policy_number", name="uq_policies_policy_number"),
    )
    op.create_index("ix_policies_policy_number", "policies", ["policy_number"])

    op.create_table(
        "claims",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("policy_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("policies.id"), nullable=False),
        sa.Column("assigned_adjuster_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="SUBMITTED"),
        sa.Column("claimed_amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("submitted_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.CheckConstraint(
            "status IN ('SUBMITTED','PROCESSING','REVIEW','FLAGGED','APPROVED','REJECTED')",
            name="ck_claims_status",
        ),
        sa.CheckConstraint("claimed_amount > 0", name="ck_claims_amount_positive"),
    )
    op.create_index("idx_claims_status_submitted", "claims", ["status", "submitted_at"])

    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("claim_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("claims.id", ondelete="CASCADE"), nullable=False),
        sa.Column("document_type", sa.String(50), nullable=False),
        sa.Column("storage_path", sa.String(500), nullable=False),
        sa.Column("ocr_status", sa.String(20), server_default="PENDING"),
        sa.Column("uploaded_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_documents_claim_id", "documents", ["claim_id"])

    op.create_table(
        "extracted_data",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("claim_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("claims.id", ondelete="CASCADE"), nullable=False),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("documents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("structured_fields", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("extraction_confidence", sa.Numeric(4, 3), nullable=False),
        sa.Column("extracted_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_extracted_data_claim_id", "extracted_data", ["claim_id"])
    op.create_index("gin_extracted_fields", "extracted_data", ["structured_fields"], postgresql_using="gin")

    op.create_table(
        "risk_scores",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("claim_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("claims.id", ondelete="CASCADE"), nullable=False),
        sa.Column("score", sa.Numeric(5, 2), nullable=False),
        sa.Column("risk_tier", sa.String(10), nullable=False),
        sa.Column("signals", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("scored_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.CheckConstraint("score BETWEEN 0 AND 100", name="ck_risk_score_range"),
        sa.CheckConstraint("risk_tier IN ('LOW','MEDIUM','HIGH')", name="ck_risk_tier"),
        sa.UniqueConstraint("claim_id", name="uq_risk_scores_claim_id"),
    )
    op.create_index("idx_risk_claim_id", "risk_scores", ["claim_id"])
    op.create_index("idx_risk_tier", "risk_scores", ["risk_tier"])

    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("claim_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("claims.id", ondelete="CASCADE"), nullable=False),
        sa.Column("actor_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("log_metadata", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_audit_claim_created", "audit_logs", ["claim_id", "created_at"])

    op.create_table(
        "failed_tasks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("task_name", sa.String(255), nullable=False),
        sa.Column("task_id", sa.String(255), nullable=False),
        sa.Column("args", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("error_message", sa.Text(), nullable=False),
        sa.Column("replayed", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_failed_tasks_created", "failed_tasks", ["created_at"])

    # Append-only enforcement for audit_logs at the DB permission level (see
    # ClaimForge-AI-Design.md, section 4): a dedicated low-privilege app role
    # would be REVOKEd UPDATE/DELETE on this table. Not created here because
    # role/grant management belongs in deploy-time provisioning, not a
    # portable migration — see README's "Production hardening" section.


def downgrade() -> None:
    op.drop_table("failed_tasks")
    op.drop_table("audit_logs")
    op.drop_table("risk_scores")
    op.drop_table("extracted_data")
    op.drop_table("documents")
    op.drop_table("claims")
    op.drop_table("policies")
    op.drop_table("refresh_tokens")
    op.drop_table("users")
