from fastapi import FastAPI, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from sqlalchemy import text

from app.api.middleware.error_handler import unhandled_exception_handler
from app.api.middleware.request_id import RequestIDMiddleware
from app.api.v1.routes import admin, auth, claims, documents
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.metrics import PrometheusMiddleware
from app.infrastructure.db.session import engine


def create_app() -> FastAPI:
    configure_logging()
    settings = get_settings()
    app = FastAPI(title=settings.APP_NAME, version="0.1.0")

    # Middleware order matters: request ID first so it's available to every
    # downstream layer (including the metrics/logging that follow it).
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(PrometheusMiddleware)
    app.add_exception_handler(Exception, unhandled_exception_handler)

    app.include_router(auth.router, prefix="/api/v1")
    app.include_router(claims.router, prefix="/api/v1")
    app.include_router(documents.router, prefix="/api/v1")
    app.include_router(admin.router, prefix="/api/v1")

    @app.get("/healthz", tags=["ops"])
    async def liveness():
        return {"status": "ok"}

    @app.get("/readyz", tags=["ops"])
    async def readiness():
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return {"status": "ready"}

    @app.get("/metrics", tags=["ops"])
    async def metrics():
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    return app


app = create_app()
