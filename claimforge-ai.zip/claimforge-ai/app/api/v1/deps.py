"""
Shared FastAPI dependencies.

This is the composition root: it's the ONE place where repositories get
built from a session and handed to services. Routers only ever ask for
`ClaimService = Depends(get_claim_service)` etc. -- they never construct a
repository, session, or infrastructure adapter themselves.
"""
from collections.abc import AsyncGenerator
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.security import TokenError, safe_decode_token
from app.infrastructure.db.models import User
from app.infrastructure.db.session import get_db_session  # re-exported: routers import this from deps, not infra
from app.repositories.claim_repository import ClaimRepository
from app.repositories.refresh_token_repository import RefreshTokenRepository
from app.repositories.user_repository import UserRepository
from app.services.auth_service import AuthService
from app.services.claim_service import ClaimService

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


async def get_user_repo(session: AsyncSession = Depends(get_db_session)) -> UserRepository:
    return UserRepository(session)


async def get_claim_repo(session: AsyncSession = Depends(get_db_session)) -> ClaimRepository:
    return ClaimRepository(session)


async def get_refresh_token_repo(session: AsyncSession = Depends(get_db_session)) -> RefreshTokenRepository:
    return RefreshTokenRepository(session)


async def get_auth_service(
    user_repo: UserRepository = Depends(get_user_repo),
    refresh_token_repo: RefreshTokenRepository = Depends(get_refresh_token_repo),
) -> AuthService:
    from app.infrastructure.email.email_client import build_email_client

    settings = get_settings()
    return AuthService(
        user_repo,
        refresh_token_repo,
        email_client=build_email_client(),
        frontend_base_url=settings.FRONTEND_BASE_URL,
    )


async def get_claim_service(
    session: AsyncSession = Depends(get_db_session),
    claim_repo: ClaimRepository = Depends(get_claim_repo),
) -> ClaimService:
    from app.infrastructure.storage.s3_client import build_storage_client
    from app.workers.extraction_tasks import enqueue_claim_extraction

    return ClaimService(
        session,
        claim_repo,
        storage_client=build_storage_client(),
        enqueue_extraction=enqueue_claim_extraction,
    )


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    user_repo: UserRepository = Depends(get_user_repo),
) -> User:
    try:
        payload = safe_decode_token(token, expected_type="access")
    except TokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")

    user = await user_repo.get_by_id(UUID(payload["sub"]))
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")
    return user


def require_role(*allowed_roles: str):
    """
    Usage: Depends(require_role("manager", "admin"))
    Declarative RBAC -- the allowed roles are visible right in the route signature.
    """

    async def _check(user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed_roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient permissions")
        return user

    return _check
