from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.deps import get_db_session, require_role
from app.infrastructure.db.models import User
from app.repositories.document_repository import DocumentRepository
from app.schemas.document import DocumentDownloadUrlResponse, DocumentResponse

router = APIRouter(prefix="/claims/{claim_id}/documents", tags=["documents"])


@router.get("", response_model=list[DocumentResponse])
async def list_claim_documents(
    claim_id: UUID,
    session: AsyncSession = Depends(get_db_session),
    _user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    repo = DocumentRepository(session)
    docs = await repo.list_for_claim(claim_id)
    return [DocumentResponse.model_validate(d) for d in docs]


@router.get("/{document_id}/download-url", response_model=DocumentDownloadUrlResponse)
async def get_document_download_url(
    claim_id: UUID,
    document_id: UUID,
    session: AsyncSession = Depends(get_db_session),
    _user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    """
    Returns a time-limited presigned URL rather than streaming the file
    through the API process -- keeps large document downloads off the
    application server and lets S3/the storage backend handle bandwidth.
    """
    from app.infrastructure.storage.s3_client import build_storage_client

    repo = DocumentRepository(session)
    doc = await repo.get_for_claim(claim_id, document_id)
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found for this claim")

    storage = build_storage_client()
    url = storage.get_presigned_url(doc.storage_path, expires_in=3600)
    return DocumentDownloadUrlResponse(url=url, expires_in_seconds=3600)
