from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.deps import get_claim_service, get_db_session, require_role
from app.domain.entities.claim import ClaimEntity, ClaimStatus, InvalidClaimTransition
from app.domain.exceptions import ClaimNotFoundError, PolicyNotFoundError
from app.domain.value_objects.upload_rules import (
    FileTooLargeError,
    TooManyFilesError,
    UnsupportedFileTypeError,
)
from app.infrastructure.db.models import AuditLog, User
from app.repositories.audit_log_repository import AuditLogRepository
from app.schemas.claim import (
    ClaimCreateRequest,
    ClaimStatusUpdateRequest,
    ClaimSubmittedResponse,
    ClaimSummaryResponse,
)
from app.schemas.common import Page
from app.services.claim_service import ClaimService, IncomingFile

router = APIRouter(prefix="/claims", tags=["claims"])


@router.post("", response_model=ClaimSubmittedResponse, status_code=status.HTTP_202_ACCEPTED)
async def submit_claim(
    policy_number: str = Form(...),
    claimed_amount: Decimal = Form(...),
    documents: list[UploadFile] = File(default=[]),
    claim_service: ClaimService = Depends(get_claim_service),
    _user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    payload = ClaimCreateRequest(policy_number=policy_number, claimed_amount=claimed_amount)
    incoming_files = [
        IncomingFile(
            filename=doc.filename or "unnamed",
            content_type=doc.content_type or "application/octet-stream",
            size=doc.size or 0,
            stream=doc.file,
        )
        for doc in documents
    ]
    try:
        return await claim_service.submit_claim(payload, files=incoming_files)
    except PolicyNotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc))
    except TooManyFilesError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))
    except FileTooLargeError as exc:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, str(exc))
    except UnsupportedFileTypeError as exc:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, str(exc))


@router.get("", response_model=Page[ClaimSummaryResponse])
async def list_claims(
    status_filter: str | None = Query(default=None, alias="status"),
    page: int = Query(default=1, ge=1),
    size: int = Query(default=20, ge=1, le=100),
    claim_service: ClaimService = Depends(get_claim_service),
    _user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    items, total = await claim_service.list_claims(status=status_filter, page=page, size=size)
    return Page.build(
        items=[ClaimSummaryResponse.model_validate(c) for c in items],
        total=total,
        page=page,
        size=size,
    )


@router.get("/{claim_id}")
async def get_claim(
    claim_id: UUID,
    claim_service: ClaimService = Depends(get_claim_service),
    _user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    try:
        claim = await claim_service.get_claim(claim_id)
    except ClaimNotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc))
    return {
        "id": str(claim.id),
        "status": claim.status,
        "claimed_amount": str(claim.claimed_amount),
        "submitted_at": claim.submitted_at.isoformat(),
        "documents": [{"id": str(d.id), "type": d.document_type, "ocr_status": d.ocr_status} for d in claim.documents],
        "risk_score": (
            {"score": str(claim.risk_score.score), "tier": claim.risk_score.risk_tier}
            if claim.risk_score
            else None
        ),
    }


@router.patch("/{claim_id}/status")
async def update_claim_status(
    claim_id: UUID,
    payload: ClaimStatusUpdateRequest,
    session: AsyncSession = Depends(get_db_session),
    claim_service: ClaimService = Depends(get_claim_service),
    user: User = Depends(require_role("adjuster", "manager", "admin")),
):
    """Manual adjuster override of claim status. Validated against the same
    state machine the automated pipeline uses, and always writes an audit entry."""
    try:
        claim = await claim_service.get_claim(claim_id)
    except ClaimNotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc))

    try:
        target = ClaimStatus(payload.status)
    except ValueError:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"Unknown status '{payload.status}'")

    entity = ClaimEntity(
        id=claim.id,
        policy_id=claim.policy_id,
        claimed_amount=claim.claimed_amount,
        status=ClaimStatus(claim.status),
    )
    try:
        entity.transition_to(target)
    except InvalidClaimTransition as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc))

    claim.status = entity.status.value
    audit_repo = AuditLogRepository(session)
    await audit_repo.record(
        claim_id=claim.id,
        actor_id=user.id,
        action="MANUAL_STATUS_OVERRIDE",
        metadata={"new_status": claim.status, "reason": payload.reason, "by": str(user.id)},
    )
    await session.commit()
    return {"claim_id": str(claim.id), "status": claim.status}


@router.get("/{claim_id}/audit-log")
async def get_claim_audit_log(
    claim_id: UUID,
    session: AsyncSession = Depends(get_db_session),
    _user: User = Depends(require_role("manager", "admin")),
):
    stmt = select(AuditLog).where(AuditLog.claim_id == claim_id).order_by(AuditLog.created_at.asc())
    rows = (await session.execute(stmt)).scalars().all()
    return [
        {
            "id": str(r.id),
            "action": r.action,
            "actor_id": str(r.actor_id) if r.actor_id else None,
            "metadata": r.log_metadata,
            "created_at": r.created_at.isoformat(),
        }
        for r in rows
    ]
