from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.deps import get_db_session, require_role
from app.infrastructure.db.models import FailedTask, User
from app.schemas.admin import UserActiveStatusUpdateRequest, UserRoleUpdateRequest
from app.schemas.auth import UserResponse

router = APIRouter(prefix="/admin", tags=["admin"])

_VALID_ROLES = {"adjuster", "manager", "admin"}


@router.get("/users", response_model=list[UserResponse])
async def list_users(
    session: AsyncSession = Depends(get_db_session),
    _admin: User = Depends(require_role("admin")),
):
    rows = (await session.execute(select(User).order_by(User.created_at.desc()))).scalars().all()
    return [UserResponse.model_validate(u) for u in rows]


@router.patch("/users/{user_id}/role", response_model=UserResponse)
async def update_user_role(
    user_id: UUID,
    payload: UserRoleUpdateRequest,
    session: AsyncSession = Depends(get_db_session),
    _admin: User = Depends(require_role("admin")),
):
    if payload.role not in _VALID_ROLES:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"role must be one of {_VALID_ROLES}")

    user = await session.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")

    user.role = payload.role
    await session.commit()
    return UserResponse.model_validate(user)


@router.patch("/users/{user_id}/status", response_model=UserResponse)
async def update_user_active_status(
    user_id: UUID,
    payload: UserActiveStatusUpdateRequest,
    session: AsyncSession = Depends(get_db_session),
    admin: User = Depends(require_role("admin")),
):
    if user_id == admin.id and not payload.is_active:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Cannot deactivate your own account")

    user = await session.get(User, user_id)
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")

    user.is_active = payload.is_active
    await session.commit()
    return UserResponse.model_validate(user)


@router.get("/failed-tasks")
async def list_failed_tasks(
    session: AsyncSession = Depends(get_db_session),
    _admin: User = Depends(require_role("admin")),
):
    """Surface the dead-letter queue for manual inspection/replay decisions."""
    rows = (
        (await session.execute(select(FailedTask).order_by(FailedTask.created_at.desc()).limit(100)))
        .scalars()
        .all()
    )
    return [
        {
            "id": str(r.id),
            "task_name": r.task_name,
            "task_id": r.task_id,
            "args": r.args,
            "error_message": r.error_message,
            "replayed": r.replayed,
            "created_at": r.created_at.isoformat(),
        }
        for r in rows
    ]
