"""
Email adapter. Same pattern as storage/OCR/LLM: a Protocol, a real
implementation, and a dev-safe fallback, chosen by ENV so nothing needs a
real mail provider to run locally.
"""
from __future__ import annotations

from typing import Protocol

import structlog

from app.core.config import get_settings

logger = structlog.get_logger()


class EmailClient(Protocol):
    def send(self, to: str, subject: str, body: str) -> None: ...


class SesEmailClient:
    """
    boto3 SES-backed implementation. Requires AWS credentials/IAM role and a
    verified sending domain in production. Swap for SendGrid/Postmark/etc by
    implementing the same `send()` signature — nothing else changes.
    """

    def __init__(self):
        import boto3

        settings = get_settings()
        self._client = boto3.client("ses", region_name=settings.AWS_REGION)
        self._from_address = settings.EMAIL_FROM_ADDRESS

    def send(self, to: str, subject: str, body: str) -> None:
        self._client.send_email(
            Source=self._from_address,
            Destination={"ToAddresses": [to]},
            Message={"Subject": {"Data": subject}, "Body": {"Text": {"Data": body}}},
        )


class ConsoleEmailClient:
    """
    Dev/test implementation: logs the email instead of sending it. This is
    what makes the verify/reset flows testable end-to-end without a real
    mail provider — the token is right there in the log line.
    """

    def send(self, to: str, subject: str, body: str) -> None:
        logger.info("email_dispatched_dev_mode", to=to, subject=subject, body=body)


def build_email_client() -> EmailClient:
    settings = get_settings()
    if settings.ENV == "production":
        return SesEmailClient()
    return ConsoleEmailClient()
