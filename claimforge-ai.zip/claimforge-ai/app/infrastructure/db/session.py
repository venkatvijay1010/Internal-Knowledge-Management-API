"""
Database engine and session factory.

Two engines are exposed on purpose:
  - the async engine (AsyncSessionLocal) is what the FastAPI app and all
    async services use.
  - the sync engine (SyncSessionLocal) exists ONLY for Celery's on_failure
    hook, which Celery calls synchronously and outside any event loop --
    wrapping that single write in asyncio.run() would be fragile, so it gets
    a plain sync session instead. Nothing else should use the sync engine.
"""
from collections.abc import AsyncGenerator

from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import get_settings

settings = get_settings()

engine = create_async_engine(settings.DATABASE_URL, echo=settings.DEBUG, pool_pre_ping=True)

AsyncSessionLocal = async_sessionmaker(
    bind=engine, class_=AsyncSession, expire_on_commit=False, autoflush=False
)

sync_engine = create_engine(settings.SYNC_DATABASE_URL, pool_pre_ping=True)
SyncSessionLocal = sessionmaker(bind=sync_engine, class_=Session, expire_on_commit=False)


class Base(DeclarativeBase):
    """Base class for all ORM models (app/infrastructure/db/models.py)."""


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: one session per request, always closed."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()
