"""
LLM client adapter for structured document extraction.

The key design decision: the LLM's raw text output is NEVER trusted directly.
It's parsed as JSON and validated against `ExtractedFields` (a Pydantic
model) before anything downstream sees it. If validation fails, the caller
gets an `ExtractionValidationError` and can retry with a stricter prompt or
fall back to NEEDS_MANUAL_REVIEW — never a silent bad write to the DB.
"""
from __future__ import annotations

import json
from typing import Protocol

import structlog
from pydantic import BaseModel, ValidationError

from app.core.config import get_settings
from app.infrastructure.ai.prompts.extraction_prompt import CLAIM_DOCUMENT_EXTRACTION_PROMPT

logger = structlog.get_logger()


class ExtractedFields(BaseModel):
    """The contract the LLM's output must satisfy. Any deviation is a validation failure."""

    document_type: str | None = None
    provider_name: str | None = None
    patient_or_claimant_name: str | None = None
    amount: float | None = None
    currency: str | None = None
    date_of_service: str | None = None
    diagnosis_or_reason: str | None = None
    policy_number_mentioned: str | None = None


class ExtractionValidationError(Exception):
    def __init__(self, raw_output: str, reason: str):
        super().__init__(f"LLM output failed schema validation: {reason}")
        self.raw_output = raw_output


class LlmClient(Protocol):
    def extract_structured_fields(self, ocr_text: str) -> ExtractedFields: ...


class OpenAiLlmClient:
    def __init__(self):
        from openai import OpenAI

        settings = get_settings()
        self._client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self._model = "gpt-4o-mini"

    def extract_structured_fields(self, ocr_text: str) -> ExtractedFields:
        prompt = CLAIM_DOCUMENT_EXTRACTION_PROMPT.format(ocr_text=ocr_text[:8000])  # cap tokens
        response = self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,  # deterministic extraction, not creative generation
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content
        return _parse_and_validate(raw)


class OllamaLlmClient:
    def __init__(self):
        import httpx

        settings = get_settings()
        self._base_url = settings.OLLAMA_BASE_URL
        self._model = "llama3.1:8b"
        self._http = httpx.Client(timeout=60.0)

    def extract_structured_fields(self, ocr_text: str) -> ExtractedFields:
        prompt = CLAIM_DOCUMENT_EXTRACTION_PROMPT.format(ocr_text=ocr_text[:8000])
        resp = self._http.post(
            f"{self._base_url}/api/generate",
            json={"model": self._model, "prompt": prompt, "stream": False, "format": "json"},
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "")
        return _parse_and_validate(raw)


def _parse_and_validate(raw: str) -> ExtractedFields:
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        # Some models wrap JSON in markdown fences despite instructions — one defensive strip.
        cleaned = raw.strip()
        for fence in ("```json", "```"):
            if cleaned.startswith(fence):
                cleaned = cleaned[len(fence):]
            if cleaned.endswith("```"):
                cleaned = cleaned[: -len("```")]
        cleaned = cleaned.strip()
        try:
            parsed = json.loads(cleaned)
        except json.JSONDecodeError as exc2:
            raise ExtractionValidationError(raw, f"not valid JSON: {exc2}") from exc2

    try:
        return ExtractedFields.model_validate(parsed)
    except ValidationError as exc:
        raise ExtractionValidationError(raw, str(exc)) from exc


def build_llm_client() -> LlmClient:
    settings = get_settings()
    if settings.LLM_PROVIDER == "openai" and settings.OPENAI_API_KEY:
        return OpenAiLlmClient()
    return OllamaLlmClient()
