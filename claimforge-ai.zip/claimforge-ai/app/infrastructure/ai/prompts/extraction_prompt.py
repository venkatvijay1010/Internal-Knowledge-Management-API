"""
Extraction prompt template.

Kept as data (a plain string template) separate from llm_client.py so the
prompt can be iterated on, versioned, and eval'd independently of the code
that calls it. In a larger system this would live in a prompt registry with
version numbers logged alongside each extraction result.
"""

CLAIM_DOCUMENT_EXTRACTION_PROMPT = """You are extracting structured data from an insurance claim document.

Below is the raw OCR text of the document. Extract ONLY the fields that are
explicitly present in the text. Do not guess or infer values that are not there.

Return a JSON object with EXACTLY this shape (use null for any field not found):
{{
  "document_type": "medical_bill" | "invoice" | "id_proof" | "policy_form" | "other",
  "provider_name": string | null,
  "patient_or_claimant_name": string | null,
  "amount": number | null,
  "currency": string | null,
  "date_of_service": "YYYY-MM-DD" | null,
  "diagnosis_or_reason": string | null,
  "policy_number_mentioned": string | null
}}

Respond with ONLY the JSON object. No markdown, no explanation, no code fences.

--- OCR TEXT START ---
{ocr_text}
--- OCR TEXT END ---
"""
