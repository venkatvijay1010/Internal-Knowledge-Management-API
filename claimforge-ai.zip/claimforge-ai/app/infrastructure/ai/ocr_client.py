"""
OCR adapter. Converts a raw document (bytes) into plain text + basic layout
info BEFORE it's handed to the LLM — this is deliberately a separate step
from LLM extraction (see llm_client.py) because OCR is cheap and
deterministic, while LLM calls are the expensive, rate-limited part of the
pipeline. Doing OCR first also means the LLM only ever sees text, never a
raw image, which keeps token costs and prompt-injection surface smaller.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import structlog

logger = structlog.get_logger()


@dataclass
class OcrResult:
    text: str
    confidence: float  # 0.0 - 1.0, average OCR engine confidence across the page(s)
    page_count: int


class OcrEngine(Protocol):
    def extract_text(self, file_bytes: bytes, content_type: str) -> OcrResult: ...


class TesseractOcrEngine:
    """
    Wraps pytesseract. For PDFs, pages are rasterized first (via pdf2image)
    before OCR — pytesseract only operates on images.
    """

    def extract_text(self, file_bytes: bytes, content_type: str) -> OcrResult:
        import io

        import pytesseract
        from PIL import Image

        if content_type == "application/pdf":
            from pdf2image import convert_from_bytes

            pages = convert_from_bytes(file_bytes)
        else:
            pages = [Image.open(io.BytesIO(file_bytes))]

        texts: list[str] = []
        confidences: list[float] = []
        for page in pages:
            data = pytesseract.image_to_data(page, output_type=pytesseract.Output.DICT)
            page_text = " ".join(w for w in data["text"] if w.strip())
            texts.append(page_text)
            word_confidences = [int(c) for c in data["conf"] if c != "-1"]
            if word_confidences:
                confidences.append(sum(word_confidences) / len(word_confidences) / 100.0)

        return OcrResult(
            text="\n\n".join(texts),
            confidence=sum(confidences) / len(confidences) if confidences else 0.0,
            page_count=len(pages),
        )


class NullOcrEngine:
    """
    No-op engine used in dev/tests when Tesseract isn't installed locally.
    Lets the pipeline run end-to-end without a real OCR binary — extraction
    downstream will just get an empty-text warning rather than crashing.
    """

    def extract_text(self, file_bytes: bytes, content_type: str) -> OcrResult:
        logger.warning("ocr_engine_not_configured", content_type=content_type)
        return OcrResult(text="", confidence=0.0, page_count=0)


def build_ocr_engine() -> OcrEngine:
    try:
        import pytesseract  # noqa: F401

        return TesseractOcrEngine()
    except ImportError:
        return NullOcrEngine()
