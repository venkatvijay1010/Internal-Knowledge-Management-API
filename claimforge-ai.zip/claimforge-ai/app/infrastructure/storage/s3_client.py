"""
S3-compatible object storage adapter.

Isolated behind this interface so a swap from AWS S3 to MinIO/R2/GCS only
touches this file. Services and workers call `StorageClient`, never boto3
directly.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import BinaryIO, Protocol

import structlog

from app.core.config import get_settings

logger = structlog.get_logger()


class StorageClient(Protocol):
    def upload(self, file_obj: BinaryIO, key: str, content_type: str) -> str: ...
    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str: ...
    def download(self, key: str) -> bytes: ...


@dataclass
class UploadResult:
    storage_path: str
    size_bytes: int


class S3StorageClient:
    """boto3-backed implementation. Requires AWS_* env vars / IAM role in production."""

    def __init__(self):
        import boto3  # imported lazily so the app can boot without boto3 installed in dev

        settings = get_settings()
        self._bucket = settings.STORAGE_BUCKET
        self._client = boto3.client("s3")

    def upload(self, file_obj: BinaryIO, key: str, content_type: str) -> str:
        self._client.upload_fileobj(file_obj, self._bucket, key, ExtraArgs={"ContentType": content_type})
        return f"s3://{self._bucket}/{key}"

    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        return self._client.generate_presigned_url(
            "get_object", Params={"Bucket": self._bucket, "Key": key}, ExpiresIn=expires_in
        )

    def download(self, key: str) -> bytes:
        obj = self._client.get_object(Bucket=self._bucket, Key=key)
        return obj["Body"].read()


class LocalDiskStorageClient:
    """
    Filesystem-backed implementation for local dev/tests — no AWS credentials needed.
    Same interface as S3StorageClient so services never know which one is active.
    """

    def __init__(self, base_path: str = "/tmp/claimforge-storage"):
        import os

        self._base_path = base_path
        os.makedirs(base_path, exist_ok=True)

    def upload(self, file_obj: BinaryIO, key: str, content_type: str) -> str:
        import os

        full_path = os.path.join(self._base_path, key)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "wb") as f:
            f.write(file_obj.read())
        return full_path

    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        return f"file://{self._base_path}/{key}"

    def download(self, key: str) -> bytes:
        import os

        with open(os.path.join(self._base_path, key), "rb") as f:
            return f.read()


def build_storage_client() -> StorageClient:
    settings = get_settings()
    if settings.ENV == "production":
        return S3StorageClient()
    return LocalDiskStorageClient()


def generate_document_key(claim_id: str, filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "bin"
    return f"claims/{claim_id}/{uuid.uuid4()}.{ext}"
