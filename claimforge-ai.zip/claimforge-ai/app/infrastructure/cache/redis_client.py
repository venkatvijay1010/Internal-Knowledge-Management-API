"""
Thin Redis cache wrapper. Kept minimal on purpose — this is a cache, not a
data store, so no complex serialization logic lives here.
"""
from __future__ import annotations

from typing import Protocol

from app.core.config import get_settings


class CacheClient(Protocol):
    def get(self, key: str) -> str | None: ...
    def set(self, key: str, value: str, ttl_seconds: int = 3600) -> None: ...


class RedisCacheClient:
    def __init__(self):
        import redis

        settings = get_settings()
        self._client = redis.from_url(settings.REDIS_URL, decode_responses=True)

    def get(self, key: str) -> str | None:
        return self._client.get(key)

    def set(self, key: str, value: str, ttl_seconds: int = 3600) -> None:
        self._client.set(key, value, ex=ttl_seconds)


def build_cache_client() -> CacheClient:
    return RedisCacheClient()
