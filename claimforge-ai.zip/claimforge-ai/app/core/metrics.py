"""
Prometheus metrics. Kept as module-level singletons (Prometheus client
convention) so any part of the app can `from app.core.metrics import
http_requests_total` and increment it without passing a registry around.
"""
import time

from prometheus_client import Counter, Histogram
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

http_requests_total = Counter(
    "http_requests_total", "Total HTTP requests", ["method", "path", "status_code"]
)
http_request_duration_seconds = Histogram(
    "http_request_duration_seconds", "HTTP request latency", ["method", "path"]
)
claims_submitted_total = Counter("claims_submitted_total", "Total claims submitted")
claims_by_status = Counter("claims_status_transitions_total", "Claim status transitions", ["status"])
celery_task_duration_seconds = Histogram(
    "celery_task_duration_seconds", "Celery task execution time", ["task_name"]
)


class PrometheusMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        duration = time.perf_counter() - start

        # Use route path template (e.g. /claims/{claim_id}), not the raw URL,
        # so metric cardinality doesn't explode with one label per UUID.
        path = request.scope.get("route").path if request.scope.get("route") else request.url.path

        http_requests_total.labels(method=request.method, path=path, status_code=response.status_code).inc()
        http_request_duration_seconds.labels(method=request.method, path=path).observe(duration)
        return response
