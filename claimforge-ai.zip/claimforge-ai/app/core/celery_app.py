from celery import Celery
from celery.schedules import crontab

from app.core.config import get_settings

settings = get_settings()

celery_app = Celery(
    "claimforge",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.workers.extraction_tasks", "app.workers.scheduled_tasks"],
)

celery_app.conf.update(
    task_routes={
        "app.workers.extraction_tasks.extract_claim_documents": {"queue": "extraction"},
        "app.workers.extraction_tasks.score_claim_risk": {"queue": "scoring"},
    },
    task_acks_late=True,          # re-queue if a worker dies mid-task
    worker_prefetch_multiplier=1,  # avoid one worker hoarding tasks under a slow LLM call
    task_default_retry_delay=10,
    beat_schedule={
        "cleanup-expired-tokens-daily": {
            "task": "app.workers.scheduled_tasks.cleanup_expired_tokens",
            "schedule": crontab(hour=3, minute=0),  # 03:00 UTC daily, off-peak
        },
        "rescore-stale-review-claims-hourly": {
            "task": "app.workers.scheduled_tasks.rescore_stale_claims",
            "schedule": crontab(minute=0),  # top of every hour
        },
    },
)
