"""
Centralized application configuration.

Every environment-dependent value (DB URL, secrets, model choice) is read here
and ONLY here. No other module should call os.getenv() directly — that keeps
config swaps (dev -> staging -> prod) to a single file.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "ClaimForge AI"
    ENV: str = "development"
    DEBUG: bool = True

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://claimforge:claimforge@db:5432/claimforge"
    SYNC_DATABASE_URL: str = "postgresql+psycopg2://claimforge:claimforge@db:5432/claimforge"

    # Redis / Celery
    REDIS_URL: str = "redis://redis:6379/0"
    CELERY_BROKER_URL: str = "redis://redis:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://redis:6379/2"

    # Auth
    JWT_SECRET_KEY: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # AI
    LLM_PROVIDER: str = "ollama"  # "ollama" | "openai"
    OPENAI_API_KEY: str | None = None
    OLLAMA_BASE_URL: str = "http://ollama:11434"

    # Storage
    STORAGE_BUCKET: str = "claimforge-documents"
    AWS_REGION: str = "us-east-1"

    # Email
    EMAIL_FROM_ADDRESS: str = "no-reply@claimforge.ai"
    FRONTEND_BASE_URL: str = "http://localhost:3000"  # used to build verify/reset links


@lru_cache
def get_settings() -> Settings:
    """Cached so Settings() is only parsed once per process."""
    settings = Settings()
    if settings.ENV == "production" and settings.JWT_SECRET_KEY == "change-me-in-production":
        raise RuntimeError(
            "JWT_SECRET_KEY is still the default placeholder in a production environment. "
            "Set a real secret via the JWT_SECRET_KEY environment variable before starting the app."
        )
    return settings
