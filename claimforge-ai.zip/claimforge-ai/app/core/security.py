"""
Security primitives: password hashing, JWT encode/decode, and token hashing.

Kept isolated so that if you ever swap bcrypt for argon2, or HS256 for RS256,
it's a one-file change -- nothing in services/ or api/ needs to know how
tokens are actually signed.

Token types issued by this module:
  - "access"            short-lived, sent on every request, never stored server-side
  - "refresh"            longer-lived; the JWT itself is stateless, but its SHA-256
                          hash is stored in refresh_tokens so it can be revoked on
                          logout -- possessing a valid-looking JWT isn't enough if
                          its hash has been marked revoked in the DB
  - "email_verification" single-use, checked against User.is_verified as a side effect
  - "password_reset"     single-use, short TTL, checked against a stored hash so a
                          token can't be replayed twice
"""
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Literal

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import get_settings

settings = get_settings()
_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

TokenType = Literal["access", "refresh", "email_verification", "password_reset"]


def hash_password(plain_password: str) -> str:
    return _pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return _pwd_context.verify(plain_password, hashed_password)


def hash_token(raw_token: str) -> str:
    """
    SHA-256 of a token string, for storing refresh/reset tokens at rest.
    Never store the raw token -- if the DB leaks, hashed tokens are useless
    to an attacker without also forging a valid JWT signature.
    """
    return hashlib.sha256(raw_token.encode()).hexdigest()


def _create_token(subject: str, token_type: TokenType, expires_delta: timedelta, extra: dict | None = None) -> str:
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "type": token_type,
        "iat": now,
        "exp": now + expires_delta,
        "jti": secrets.token_urlsafe(16),  # unique per token, even for same subject/type issued twice
        **(extra or {}),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_access_token(user_id: str, role: str) -> str:
    return _create_token(
        user_id, "access", timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES), {"role": role}
    )


def create_refresh_token(user_id: str, role: str) -> str:
    return _create_token(
        user_id, "refresh", timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS), {"role": role}
    )


def create_email_verification_token(user_id: str) -> str:
    return _create_token(user_id, "email_verification", timedelta(hours=24))


def create_password_reset_token(user_id: str) -> str:
    return _create_token(user_id, "password_reset", timedelta(minutes=30))


def decode_token(token: str) -> dict[str, Any]:
    """Raises JWTError on invalid signature or expired token -- callers catch this."""
    return jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])


class TokenError(Exception):
    """Raised by api/deps.py and auth_service.py when a token fails validation."""


def safe_decode_token(token: str, expected_type: TokenType | None = None) -> dict[str, Any]:
    try:
        payload = decode_token(token)
    except JWTError as exc:
        raise TokenError(str(exc)) from exc
    if expected_type and payload.get("type") != expected_type:
        raise TokenError(f"Expected a '{expected_type}' token, got '{payload.get('type')}'")
    return payload
