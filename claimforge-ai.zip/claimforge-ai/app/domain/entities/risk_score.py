"""
Rule-based risk scoring — pure functions operating on plain values, no ORM
or session imports. This is what test_risk_scoring.py exercises directly,
and it's what a future ML model would sit alongside (not replace outright —
see risk_scoring_service.py for how rule signals and a model score combine).
"""
from dataclasses import dataclass
from decimal import Decimal


@dataclass
class RiskSignal:
    name: str
    weight: float  # points added to the 0-100 score if triggered
    triggered: bool
    detail: str = ""


@dataclass
class RiskAssessment:
    score: float
    tier: str
    signals: list[RiskSignal]

    def to_signals_dict(self) -> dict:
        return {s.name: {"triggered": s.triggered, "detail": s.detail} for s in self.signals}


def _tier_for_score(score: float) -> str:
    if score >= 70:
        return "HIGH"
    if score >= 35:
        return "MEDIUM"
    return "LOW"


def assess_claim_risk(
    *,
    claimed_amount: Decimal,
    policy_coverage_limit: Decimal,
    avg_extraction_confidence: float,
    documents_missing_required_fields: int,
    duplicate_claim_count: int,
) -> RiskAssessment:
    """
    Combines independent rule-based signals into a single 0-100 score.
    Each signal is intentionally simple and explainable — an adjuster or
    auditor should be able to look at `signals` and understand exactly why
    a claim was flagged, which a black-box model score alone wouldn't give you.
    """
    signals: list[RiskSignal] = []

    over_limit = claimed_amount > policy_coverage_limit
    signals.append(
        RiskSignal(
            "claim_exceeds_coverage_limit",
            weight=35.0,
            triggered=over_limit,
            detail=f"claimed={claimed_amount}, limit={policy_coverage_limit}",
        )
    )

    high_value = claimed_amount >= Decimal("10000") and not over_limit
    signals.append(
        RiskSignal("high_value_claim", weight=15.0, triggered=high_value, detail=str(claimed_amount))
    )

    low_confidence = avg_extraction_confidence < 0.6
    signals.append(
        RiskSignal(
            "low_extraction_confidence",
            weight=20.0,
            triggered=low_confidence,
            detail=f"avg_confidence={avg_extraction_confidence:.2f}",
        )
    )

    missing_fields = documents_missing_required_fields > 0
    signals.append(
        RiskSignal(
            "missing_required_fields",
            weight=15.0,
            triggered=missing_fields,
            detail=f"{documents_missing_required_fields} document(s)",
        )
    )

    duplicates = duplicate_claim_count > 0
    signals.append(
        RiskSignal(
            "possible_duplicate_claim",
            weight=25.0,
            triggered=duplicates,
            detail=f"{duplicate_claim_count} similar claim(s) found",
        )
    )

    score = min(100.0, sum(s.weight for s in signals if s.triggered))
    return RiskAssessment(score=score, tier=_tier_for_score(score), signals=signals)
