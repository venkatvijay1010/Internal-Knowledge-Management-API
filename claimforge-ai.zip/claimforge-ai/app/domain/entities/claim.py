"""
Pure domain entity for a Claim.

This class has ZERO imports from SQLAlchemy, FastAPI, or Pydantic. It exists
so that business rules (e.g. "a claim can only move from REVIEW to APPROVED,
never straight from SUBMITTED") can be unit-tested with no database, no HTTP
framework, nothing but plain Python. Repositories are responsible for
converting between this and the ORM model in infrastructure/db/models.py.
"""
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from uuid import UUID


class ClaimStatus(str, Enum):
    SUBMITTED = "SUBMITTED"
    PROCESSING = "PROCESSING"
    REVIEW = "REVIEW"
    FLAGGED = "FLAGGED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


# Explicit allowed transitions — the actual business rule this entity protects.
_ALLOWED_TRANSITIONS: dict[ClaimStatus, set[ClaimStatus]] = {
    ClaimStatus.SUBMITTED: {ClaimStatus.PROCESSING},
    ClaimStatus.PROCESSING: {ClaimStatus.REVIEW, ClaimStatus.FLAGGED},
    ClaimStatus.REVIEW: {ClaimStatus.APPROVED, ClaimStatus.REJECTED, ClaimStatus.FLAGGED},
    ClaimStatus.FLAGGED: {ClaimStatus.APPROVED, ClaimStatus.REJECTED},
    ClaimStatus.APPROVED: set(),
    ClaimStatus.REJECTED: set(),
}


class InvalidClaimTransition(Exception):
    def __init__(self, current: ClaimStatus, target: ClaimStatus):
        super().__init__(f"Cannot transition claim from {current} to {target}")
        self.current = current
        self.target = target


@dataclass
class ClaimEntity:
    id: UUID
    policy_id: UUID
    claimed_amount: Decimal
    status: ClaimStatus = ClaimStatus.SUBMITTED
    assigned_adjuster_id: UUID | None = None
    submitted_at: datetime | None = None

    def transition_to(self, target: ClaimStatus) -> None:
        """Enforces the claim status state machine. Raises if the move is illegal."""
        if target not in _ALLOWED_TRANSITIONS[self.status]:
            raise InvalidClaimTransition(self.status, target)
        self.status = target

    def is_high_value(self, threshold: Decimal = Decimal("10000")) -> bool:
        return self.claimed_amount >= threshold
