"""Shared validation rules for claim document uploads."""
MAX_DOCUMENTS_PER_CLAIM = 10
MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024  # 15 MB
ALLOWED_CONTENT_TYPES = {"application/pdf", "image/jpeg", "image/png"}


class FileTooLargeError(Exception):
    def __init__(self, filename: str, size: int):
        super().__init__(f"'{filename}' is {size} bytes, exceeds {MAX_FILE_SIZE_BYTES} byte limit")


class UnsupportedFileTypeError(Exception):
    def __init__(self, filename: str, content_type: str):
        super().__init__(f"'{filename}' has unsupported type '{content_type}'")


class TooManyFilesError(Exception):
    def __init__(self, count: int):
        super().__init__(f"{count} files exceeds max of {MAX_DOCUMENTS_PER_CLAIM} per claim")


def validate_upload(filename: str, content_type: str, size: int) -> None:
    if size > MAX_FILE_SIZE_BYTES:
        raise FileTooLargeError(filename, size)
    if content_type not in ALLOWED_CONTENT_TYPES:
        raise UnsupportedFileTypeError(filename, content_type)
