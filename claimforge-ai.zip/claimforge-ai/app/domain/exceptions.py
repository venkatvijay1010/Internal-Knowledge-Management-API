"""
Domain exceptions. These carry no knowledge of HTTP — the API layer's
error_handler middleware maps each one to a status code. This keeps services
testable without needing to know what a "404" is.
"""


class DomainError(Exception):
    """Base class for all business-rule violations."""


class UserAlreadyExistsError(DomainError):
    def __init__(self, email: str):
        super().__init__(f"A user with email '{email}' already exists")


class InvalidCredentialsError(DomainError):
    def __init__(self):
        super().__init__("Invalid email or password")


class EmailNotVerifiedError(DomainError):
    def __init__(self):
        super().__init__("Email address not verified — check your inbox for a verification link")


class InvalidTokenError(DomainError):
    def __init__(self, reason: str = "Invalid or expired token"):
        super().__init__(reason)


class UserNotFoundError(DomainError):
    def __init__(self):
        super().__init__("User not found")


class PolicyNotFoundError(DomainError):
    def __init__(self, policy_number: str):
        super().__init__(f"Policy '{policy_number}' not found")


class ClaimNotFoundError(DomainError):
    def __init__(self, claim_id: str):
        super().__init__(f"Claim '{claim_id}' not found")
