"""
Celery tasks for document extraction and risk scoring.

Tasks stay thin -- real logic belongs in services/. A task's job is: pull the
claim_id off the queue, open a fresh async DB session, call the service, and
handle retries. Celery workers run tasks synchronously, so each task wraps
its async work in asyncio.run() with its own session -- sessions are never
shared across tasks or reused across retries.
"""
import asyncio
from uuid import UUID

import structlog
from celery import Task
from celery.exceptions import MaxRetriesExceededError

from app.core.celery_app import celery_app
from app.infrastructure.ai.llm_client import build_llm_client
from app.infrastructure.ai.ocr_client import build_ocr_engine
from app.infrastructure.cache.redis_client import build_cache_client
from app.infrastructure.db.models import FailedTask
from app.infrastructure.db.session import AsyncSessionLocal, SyncSessionLocal
from app.infrastructure.storage.s3_client import build_storage_client
from app.repositories.audit_log_repository import AuditLogRepository
from app.services.extraction_service import ExtractionService
from app.services.risk_scoring_service import RiskScoringService

logger = structlog.get_logger()


class BaseTaskWithDLQ(Task):
    """On final failure, persist the task payload to failed_tasks instead of losing it silently.
    Uses the SYNC session deliberately -- this hook runs outside any event loop."""

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.error("task_failed_permanently", task_id=task_id, args=args, error=str(exc))
        with SyncSessionLocal() as session:
            session.add(
                FailedTask(
                    task_name=self.name,
                    task_id=task_id,
                    args={"args": list(args), "kwargs": kwargs},
                    error_message=str(exc),
                )
            )
            session.commit()


async def _run_extraction(claim_id: str) -> None:
    async with AsyncSessionLocal() as session:
        service = ExtractionService(
            session=session,
            storage=build_storage_client(),
            ocr_engine=build_ocr_engine(),
            llm_client=build_llm_client(),
            cache=build_cache_client(),
        )
        await service.process_claim_documents(claim_id=UUID(claim_id))


async def _run_risk_scoring(claim_id: str) -> None:
    async with AsyncSessionLocal() as session:
        audit_repo = AuditLogRepository(session)
        service = RiskScoringService(session=session, audit_repo=audit_repo)
        await service.score_claim(claim_id=UUID(claim_id))


@celery_app.task(bind=True, base=BaseTaskWithDLQ, max_retries=3, retry_backoff=True)
def extract_claim_documents(self, claim_id: str) -> None:
    try:
        logger.info("extraction_started", claim_id=claim_id)
        asyncio.run(_run_extraction(claim_id))
        logger.info("extraction_completed", claim_id=claim_id)
        score_claim_risk.delay(claim_id)
    except Exception as exc:
        try:
            raise self.retry(exc=exc)
        except MaxRetriesExceededError:
            logger.error("extraction_exhausted_retries", claim_id=claim_id)
            raise


@celery_app.task(bind=True, base=BaseTaskWithDLQ, max_retries=3, retry_backoff=True)
def score_claim_risk(self, claim_id: str) -> None:
    try:
        logger.info("risk_scoring_started", claim_id=claim_id)
        asyncio.run(_run_risk_scoring(claim_id))
        logger.info("risk_scoring_completed", claim_id=claim_id)
    except Exception as exc:
        try:
            raise self.retry(exc=exc)
        except MaxRetriesExceededError:
            logger.error("risk_scoring_exhausted_retries", claim_id=claim_id)
            raise


def enqueue_claim_extraction(claim_id: str) -> None:
    """Thin wrapper so ClaimService depends on a plain callable, not on Celery's API directly."""
    extract_claim_documents.delay(claim_id)
