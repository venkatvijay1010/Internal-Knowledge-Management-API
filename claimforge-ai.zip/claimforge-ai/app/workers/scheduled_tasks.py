"""
Scheduled tasks run by Celery Beat. Each wraps a small async operation the
same way extraction_tasks.py does — open a fresh session, do the work, close.
Registered on a schedule in core/celery_app.py's `beat_schedule`.
"""
import asyncio
from datetime import datetime, timedelta, timezone

import structlog
from sqlalchemy import select

from app.core.celery_app import celery_app
from app.infrastructure.db.session import AsyncSessionLocal
from app.infrastructure.db.models import Claim
from app.repositories.audit_log_repository import AuditLogRepository
from app.repositories.refresh_token_repository import RefreshTokenRepository
from app.services.risk_scoring_service import RiskScoringService

logger = structlog.get_logger()

# Claims sitting in REVIEW longer than this are re-scored — new duplicate
# claims or corrected extractions since the original score may change the outcome.
STALE_REVIEW_THRESHOLD_HOURS = 24


async def _cleanup_expired_tokens() -> int:
    async with AsyncSessionLocal() as session:
        repo = RefreshTokenRepository(session)
        deleted = await repo.delete_expired()
        await session.commit()
        return deleted


async def _rescore_stale_claims() -> int:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=STALE_REVIEW_THRESHOLD_HOURS)
    async with AsyncSessionLocal() as session:
        stmt = select(Claim).where(Claim.status == "REVIEW", Claim.updated_at < cutoff)
        stale_claims = (await session.execute(stmt)).scalars().all()

        audit_repo = AuditLogRepository(session)
        scorer = RiskScoringService(session=session, audit_repo=audit_repo)
        for claim in stale_claims:
            await scorer.score_claim(claim.id)
        return len(stale_claims)


@celery_app.task(name="app.workers.scheduled_tasks.cleanup_expired_tokens")
def cleanup_expired_tokens() -> None:
    deleted = asyncio.run(_cleanup_expired_tokens())
    logger.info("expired_tokens_cleaned", count=deleted)


@celery_app.task(name="app.workers.scheduled_tasks.rescore_stale_claims")
def rescore_stale_claims() -> None:
    count = asyncio.run(_rescore_stale_claims())
    logger.info("stale_claims_rescored", count=count)
