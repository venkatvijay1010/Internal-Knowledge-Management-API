from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, Field, field_validator


class ClaimCreateRequest(BaseModel):
    policy_number: str = Field(min_length=1, max_length=50)
    claimed_amount: Decimal = Field(gt=0)


class ClaimSubmittedResponse(BaseModel):
    claim_id: str
    status: str
    documents_received: int
    estimated_processing_time_seconds: int = 45


class ClaimSummaryResponse(BaseModel):
    id: str
    status: str
    claimed_amount: Decimal
    submitted_at: datetime

    model_config = {"from_attributes": True}

    @field_validator("id", mode="before")
    @classmethod
    def _stringify_id(cls, v):
        return str(v)


class ClaimStatusUpdateRequest(BaseModel):
    status: str = Field(description="One of SUBMITTED, PROCESSING, REVIEW, FLAGGED, APPROVED, REJECTED")
    reason: str | None = None
