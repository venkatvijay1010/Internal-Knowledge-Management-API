from datetime import datetime

from pydantic import BaseModel, field_validator


class DocumentResponse(BaseModel):
    id: str
    document_type: str
    ocr_status: str
    uploaded_at: datetime

    model_config = {"from_attributes": True}

    @field_validator("id", mode="before")
    @classmethod
    def _stringify_id(cls, v):
        return str(v)


class DocumentDownloadUrlResponse(BaseModel):
    url: str
    expires_in_seconds: int
