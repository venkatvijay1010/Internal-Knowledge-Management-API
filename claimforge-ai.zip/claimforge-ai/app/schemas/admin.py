from pydantic import BaseModel, Field


class UserRoleUpdateRequest(BaseModel):
    role: str = Field(description="One of adjuster, manager, admin")


class UserActiveStatusUpdateRequest(BaseModel):
    is_active: bool
