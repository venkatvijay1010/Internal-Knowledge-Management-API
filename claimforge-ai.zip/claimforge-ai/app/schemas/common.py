from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    items: list[T]
    page: int
    size: int
    total: int
    total_pages: int

    @classmethod
    def build(cls, items: list[T], total: int, page: int, size: int) -> "Page[T]":
        total_pages = (total + size - 1) // size if size else 0
        return cls(items=items, page=page, size=size, total=total, total_pages=total_pages)


class ErrorResponse(BaseModel):
    detail: str
    error_code: str | None = None
