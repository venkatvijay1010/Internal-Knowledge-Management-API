"""
Audit log repository. Deliberately exposes only `record()` — no update or
delete method exists on this class, mirroring the DB-level append-only
permission model described in the design doc. If you need to "fix" a bad
audit entry, you write a new correcting entry, you don't edit history.
"""
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.db.models import AuditLog


class AuditLogRepository:
    def __init__(self, session: AsyncSession):
        self._session = session

    async def record(
        self,
        *,
        claim_id: UUID,
        action: str,
        actor_id: UUID | None = None,
        metadata: dict | None = None,
    ) -> AuditLog:
        entry = AuditLog(claim_id=claim_id, actor_id=actor_id, action=action, log_metadata=metadata or {})
        self._session.add(entry)
        await self._session.flush()
        return entry
