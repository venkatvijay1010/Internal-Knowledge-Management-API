from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.db.models import Document
from app.repositories.base_repository import BaseRepository


class DocumentRepository(BaseRepository[Document]):
    def __init__(self, session: AsyncSession):
        super().__init__(session, Document)

    async def list_for_claim(self, claim_id: UUID) -> list[Document]:
        result = await self._session.execute(select(Document).where(Document.claim_id == claim_id))
        return list(result.scalars().all())

    async def get_for_claim(self, claim_id: UUID, document_id: UUID) -> Document | None:
        stmt = select(Document).where(Document.claim_id == claim_id, Document.id == document_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
