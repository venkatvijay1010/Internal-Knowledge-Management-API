from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.infrastructure.db.models import Claim
from app.repositories.base_repository import BaseRepository


class ClaimRepository(BaseRepository[Claim]):
    def __init__(self, session: AsyncSession):
        super().__init__(session, Claim)

    async def get_with_relations(self, claim_id: UUID) -> Claim | None:
        """Loads a claim with documents + risk_score in one query (avoids N+1)."""
        stmt = (
            select(Claim)
            .options(selectinload(Claim.documents), selectinload(Claim.risk_score))
            .where(Claim.id == claim_id)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_filtered(
        self,
        *,
        status: str | None = None,
        assigned_adjuster_id: UUID | None = None,
        page: int = 1,
        size: int = 20,
    ) -> tuple[list[Claim], int]:
        """
        The core adjuster-queue query: filter by status/assignee, paginate,
        oldest-first (matches the idx_claims_status_submitted composite index).
        Returns (items, total_count) so the API layer can build a pagination envelope.
        """
        base_stmt = select(Claim)
        count_stmt = select(func.count()).select_from(Claim)

        if status:
            base_stmt = base_stmt.where(Claim.status == status)
            count_stmt = count_stmt.where(Claim.status == status)
        if assigned_adjuster_id:
            base_stmt = base_stmt.where(Claim.assigned_adjuster_id == assigned_adjuster_id)
            count_stmt = count_stmt.where(Claim.assigned_adjuster_id == assigned_adjuster_id)

        base_stmt = base_stmt.order_by(Claim.submitted_at.asc()).offset((page - 1) * size).limit(size)

        items = (await self._session.execute(base_stmt)).scalars().all()
        total = (await self._session.execute(count_stmt)).scalar_one()
        return list(items), total
