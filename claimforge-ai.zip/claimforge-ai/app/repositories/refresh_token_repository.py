from datetime import datetime, timezone
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.db.models import RefreshToken
from app.repositories.base_repository import BaseRepository


class RefreshTokenRepository(BaseRepository[RefreshToken]):
    def __init__(self, session: AsyncSession):
        super().__init__(session, RefreshToken)

    async def store(self, user_id: UUID, token_hash: str, expires_at: datetime) -> RefreshToken:
        record = RefreshToken(user_id=user_id, token_hash=token_hash, expires_at=expires_at)
        return await self.add(record)

    async def get_valid_by_hash(self, token_hash: str) -> RefreshToken | None:
        """Returns the token row only if it exists, isn't revoked, and hasn't expired."""
        stmt = select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.revoked.is_(False),
        )
        result = await self._session.execute(stmt)
        token = result.scalar_one_or_none()
        if token and token.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
            return None
        return token

    async def revoke(self, token_hash: str) -> None:
        await self._session.execute(
            update(RefreshToken).where(RefreshToken.token_hash == token_hash).values(revoked=True)
        )

    async def revoke_all_for_user(self, user_id: UUID) -> None:
        """Used on password reset — invalidates every existing session for the user."""
        await self._session.execute(
            update(RefreshToken).where(RefreshToken.user_id == user_id).values(revoked=True)
        )

    async def delete_expired(self) -> int:
        """Called by the scheduled cleanup task (workers/scheduled_tasks.py)."""
        from sqlalchemy import delete

        result = await self._session.execute(
            delete(RefreshToken).where(RefreshToken.expires_at < datetime.now(timezone.utc))
        )
        return result.rowcount or 0
