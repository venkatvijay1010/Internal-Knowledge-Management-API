"""
Generic base repository.

Repository Pattern purpose: services never see SQLAlchemy Select statements
or sessions directly — they call repository methods with plain arguments and
get back ORM objects or None. This means swapping Postgres for another store
later only touches this layer, and services stay unit-testable with a mocked
repository instead of a real database.
"""
from typing import Generic, TypeVar
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.db.session import Base

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    def __init__(self, session: AsyncSession, model: type[ModelType]):
        self._session = session
        self._model = model

    async def get_by_id(self, entity_id: UUID) -> ModelType | None:
        result = await self._session.execute(select(self._model).where(self._model.id == entity_id))
        return result.scalar_one_or_none()

    async def add(self, entity: ModelType) -> ModelType:
        self._session.add(entity)
        await self._session.flush()  # assigns PK/defaults without ending the transaction
        return entity

    async def commit(self) -> None:
        await self._session.commit()

    async def refresh(self, entity: ModelType) -> None:
        await self._session.refresh(entity)
