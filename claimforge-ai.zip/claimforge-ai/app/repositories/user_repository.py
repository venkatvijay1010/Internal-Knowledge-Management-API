from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.db.models import User
from app.repositories.base_repository import BaseRepository


class UserRepository(BaseRepository[User]):
    def __init__(self, session: AsyncSession):
        super().__init__(session, User)

    async def get_by_email(self, email: str) -> User | None:
        result = await self._session.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def list_all(self, *, page: int = 1, size: int = 20) -> tuple[list[User], int]:
        from sqlalchemy import func

        items_stmt = select(User).order_by(User.created_at.desc()).offset((page - 1) * size).limit(size)
        count_stmt = select(func.count()).select_from(User)
        items = (await self._session.execute(items_stmt)).scalars().all()
        total = (await self._session.execute(count_stmt)).scalar_one()
        return list(items), total
