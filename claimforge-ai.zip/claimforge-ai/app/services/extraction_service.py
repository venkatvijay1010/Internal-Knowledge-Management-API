"""
Extraction service — the Week 5 use case: for every document on a claim,
run OCR, run LLM extraction, validate the output, and persist it. Called
from the Celery task in workers/extraction_tasks.py, but contains no Celery
imports itself, so it's unit-testable with fake OCR/LLM/storage clients.
"""
from __future__ import annotations

import hashlib
from decimal import Decimal
from uuid import UUID

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.infrastructure.ai.llm_client import ExtractedFields, ExtractionValidationError, LlmClient
from app.infrastructure.ai.ocr_client import OcrEngine
from app.infrastructure.cache.redis_client import CacheClient
from app.infrastructure.db.models import Claim, Document, ExtractedData
from app.infrastructure.storage.s3_client import StorageClient

logger = structlog.get_logger()


class ExtractionService:
    def __init__(
        self,
        session: AsyncSession,
        storage: StorageClient,
        ocr_engine: OcrEngine,
        llm_client: LlmClient,
        cache: CacheClient | None = None,
    ):
        self._session = session
        self._storage = storage
        self._ocr = ocr_engine
        self._llm = llm_client
        self._cache = cache

    async def process_claim_documents(self, claim_id: UUID) -> None:
        claim = await self._session.get(Claim, claim_id)
        if not claim:
            logger.warning("extraction_claim_not_found", claim_id=str(claim_id))
            return

        claim.status = "PROCESSING"
        await self._session.flush()

        docs_result = await self._session.execute(select(Document).where(Document.claim_id == claim_id))
        documents = docs_result.scalars().all()

        any_failed = False
        for doc in documents:
            try:
                await self._process_single_document(doc)
            except Exception:
                logger.exception("document_extraction_failed", document_id=str(doc.id))
                any_failed = True

        # Business rule: if any document failed structured extraction, route the
        # whole claim to manual review rather than silently proceeding with partial data.
        claim.status = "FLAGGED" if any_failed else "REVIEW"
        await self._session.commit()

    async def _process_single_document(self, doc: Document) -> None:
        file_bytes = self._storage.download(doc.storage_path)
        content_hash = hashlib.sha256(file_bytes).hexdigest()

        cached = self._cache.get(f"extraction:{content_hash}") if self._cache else None
        if cached:
            logger.info("extraction_cache_hit", document_id=str(doc.id))
            fields = ExtractedFields.model_validate_json(cached)
            confidence = 1.0  # cached results were already validated once
        else:
            ocr_result = self._ocr.extract_text(file_bytes, doc.document_type)
            try:
                fields = self._llm.extract_structured_fields(ocr_result.text)
            except ExtractionValidationError:
                doc.ocr_status = "EXTRACTION_FAILED"
                raise
            confidence = ocr_result.confidence
            if self._cache:
                self._cache.set(f"extraction:{content_hash}", fields.model_dump_json(), ttl_seconds=86400)

        doc.ocr_status = "COMPLETED"
        self._session.add(
            ExtractedData(
                claim_id=doc.claim_id,
                document_id=doc.id,
                structured_fields=fields.model_dump(),
                extraction_confidence=Decimal(str(round(confidence, 3))),
            )
        )
        await self._session.flush()
