"""
Auth service -- the "use case" layer for the full auth lifecycle: register,
login, refresh, logout, email verification, password reset.

Design notes:
  - Refresh tokens are stateless JWTs, but their SHA-256 hash is stored in
    refresh_tokens so `logout` and `revoke_all_for_user` (called on password
    reset) can actually invalidate a session -- a bare JWT can't be revoked
    without server-side state, so we keep a minimal amount of it.
  - Password reset and email verification never reveal whether an email
    exists in the system (the "request" endpoints always return success) --
    that's a deliberate anti-enumeration choice, not an oversight.
"""
from datetime import datetime, timezone
from uuid import UUID

import structlog

from app.core.security import (
    TokenError,
    create_access_token,
    create_email_verification_token,
    create_password_reset_token,
    create_refresh_token,
    hash_password,
    hash_token,
    safe_decode_token,
    verify_password,
)
from app.domain.exceptions import (
    EmailNotVerifiedError,
    InvalidCredentialsError,
    InvalidTokenError,
    UserAlreadyExistsError,
    UserNotFoundError,
)
from app.infrastructure.db.models import User
from app.infrastructure.email.email_client import EmailClient
from app.repositories.refresh_token_repository import RefreshTokenRepository
from app.repositories.user_repository import UserRepository
from app.schemas.auth import LoginRequest, PasswordResetConfirmRequest, RegisterRequest, TokenResponse

logger = structlog.get_logger()


class AuthService:
    def __init__(
        self,
        user_repo: UserRepository,
        refresh_token_repo: RefreshTokenRepository,
        email_client: EmailClient,
        frontend_base_url: str,
    ):
        self._user_repo = user_repo
        self._refresh_repo = refresh_token_repo
        self._email = email_client
        self._frontend_base_url = frontend_base_url

    async def register(self, payload: RegisterRequest) -> User:
        existing = await self._user_repo.get_by_email(payload.email)
        if existing:
            raise UserAlreadyExistsError(payload.email)

        user = User(
            email=payload.email,
            hashed_password=hash_password(payload.password),
            full_name=payload.full_name,
            role="adjuster",
            is_verified=False,
        )
        await self._user_repo.add(user)
        await self._user_repo.commit()

        verification_token = create_email_verification_token(str(user.id))
        link = f"{self._frontend_base_url}/verify-email?token={verification_token}"
        self._email.send(user.email, "Verify your ClaimForge AI account", f"Click to verify: {link}")

        return user

    async def login(self, payload: LoginRequest) -> TokenResponse:
        user = await self._user_repo.get_by_email(payload.email)
        if not user or not verify_password(payload.password, user.hashed_password):
            raise InvalidCredentialsError()
        if not user.is_active:
            raise InvalidCredentialsError()
        if not user.is_verified:
            raise EmailNotVerifiedError()

        access_token = create_access_token(str(user.id), user.role)
        refresh_token = create_refresh_token(str(user.id), user.role)

        payload_decoded = safe_decode_token(refresh_token, expected_type="refresh")
        expires_at = datetime.fromtimestamp(payload_decoded["exp"], tz=timezone.utc)
        await self._refresh_repo.store(user.id, hash_token(refresh_token), expires_at)
        await self._refresh_repo.commit()

        return TokenResponse(access_token=access_token, refresh_token=refresh_token)

    async def refresh(self, raw_refresh_token: str) -> TokenResponse:
        try:
            payload = safe_decode_token(raw_refresh_token, expected_type="refresh")
        except TokenError as exc:
            raise InvalidTokenError(str(exc)) from exc

        stored = await self._refresh_repo.get_valid_by_hash(hash_token(raw_refresh_token))
        if not stored:
            raise InvalidTokenError("Refresh token not found, expired, or revoked")

        user = await self._user_repo.get_by_id(UUID(payload["sub"]))
        if not user or not user.is_active:
            raise InvalidTokenError("User not found or inactive")

        # Rotate: revoke the used refresh token and issue a fresh pair. This
        # limits the blast radius if a refresh token is ever intercepted --
        # it's single-use, not indefinitely replayable.
        await self._refresh_repo.revoke(hash_token(raw_refresh_token))

        new_access = create_access_token(str(user.id), user.role)
        new_refresh = create_refresh_token(str(user.id), user.role)
        new_payload = safe_decode_token(new_refresh, expected_type="refresh")
        expires_at = datetime.fromtimestamp(new_payload["exp"], tz=timezone.utc)
        await self._refresh_repo.store(user.id, hash_token(new_refresh), expires_at)
        await self._refresh_repo.commit()

        return TokenResponse(access_token=new_access, refresh_token=new_refresh)

    async def logout(self, raw_refresh_token: str) -> None:
        await self._refresh_repo.revoke(hash_token(raw_refresh_token))
        await self._refresh_repo.commit()

    async def verify_email(self, token: str) -> None:
        try:
            payload = safe_decode_token(token, expected_type="email_verification")
        except TokenError as exc:
            raise InvalidTokenError(str(exc)) from exc

        user = await self._user_repo.get_by_id(UUID(payload["sub"]))
        if not user:
            raise UserNotFoundError()
        user.is_verified = True
        await self._user_repo.commit()

    async def request_password_reset(self, email: str) -> None:
        user = await self._user_repo.get_by_email(email)
        if not user:
            # Anti-enumeration: don't reveal whether the email is registered.
            logger.info("password_reset_requested_unknown_email", email=email)
            return

        token = create_password_reset_token(str(user.id))
        link = f"{self._frontend_base_url}/reset-password?token={token}"
        self._email.send(user.email, "Reset your ClaimForge AI password", f"Click to reset: {link}")

    async def confirm_password_reset(self, payload: PasswordResetConfirmRequest) -> None:
        try:
            token_payload = safe_decode_token(payload.token, expected_type="password_reset")
        except TokenError as exc:
            raise InvalidTokenError(str(exc)) from exc

        user = await self._user_repo.get_by_id(UUID(token_payload["sub"]))
        if not user:
            raise UserNotFoundError()

        user.hashed_password = hash_password(payload.new_password)
        # Force re-login everywhere -- a password reset should kill every existing session.
        await self._refresh_repo.revoke_all_for_user(user.id)
        await self._user_repo.commit()
