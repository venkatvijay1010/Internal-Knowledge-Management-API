"""
Risk scoring service — Week 6. Gathers the inputs the domain scorer needs
(policy limit, extraction confidence, duplicate count) from the DB, calls the
pure `assess_claim_risk()` function, persists the RiskScore, transitions the
claim's status via the domain state machine, and writes an audit log entry.
"""
from uuid import UUID

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.entities.claim import ClaimEntity, ClaimStatus, InvalidClaimTransition
from app.domain.entities.risk_score import assess_claim_risk
from app.infrastructure.db.models import Claim, Document, ExtractedData, Policy, RiskScore
from app.repositories.audit_log_repository import AuditLogRepository

logger = structlog.get_logger()

# Fields a fully-extracted document is expected to have; used to flag incomplete extractions.
_REQUIRED_FIELDS = ("amount", "date_of_service")


class RiskScoringService:
    def __init__(self, session: AsyncSession, audit_repo: AuditLogRepository):
        self._session = session
        self._audit = audit_repo

    async def score_claim(self, claim_id: UUID) -> None:
        claim = await self._session.get(Claim, claim_id)
        if not claim:
            logger.warning("risk_scoring_claim_not_found", claim_id=str(claim_id))
            return

        policy = await self._session.get(Policy, claim.policy_id)

        extracted_rows = (
            (await self._session.execute(select(ExtractedData).where(ExtractedData.claim_id == claim_id)))
            .scalars()
            .all()
        )
        avg_confidence = (
            float(sum(r.extraction_confidence for r in extracted_rows) / len(extracted_rows))
            if extracted_rows
            else 0.0
        )
        missing_fields_count = sum(
            1 for r in extracted_rows if any(not r.structured_fields.get(f) for f in _REQUIRED_FIELDS)
        )

        duplicate_count = (
            await self._session.execute(
                select(func.count())
                .select_from(Claim)
                .where(
                    Claim.policy_id == claim.policy_id,
                    Claim.claimed_amount == claim.claimed_amount,
                    Claim.id != claim.id,
                )
            )
        ).scalar_one()

        assessment = assess_claim_risk(
            claimed_amount=claim.claimed_amount,
            policy_coverage_limit=policy.coverage_limit if policy else claim.claimed_amount,
            avg_extraction_confidence=avg_confidence,
            documents_missing_required_fields=missing_fields_count,
            duplicate_claim_count=duplicate_count,
        )

        self._session.add(
            RiskScore(
                claim_id=claim.id,
                score=round(assessment.score, 2),
                risk_tier=assessment.tier,
                signals=assessment.to_signals_dict(),
            )
        )

        entity = ClaimEntity(
            id=claim.id, policy_id=claim.policy_id, claimed_amount=claim.claimed_amount,
            status=ClaimStatus(claim.status),
        )
        target_status = ClaimStatus.FLAGGED if assessment.tier == "HIGH" else ClaimStatus.REVIEW
        try:
            entity.transition_to(target_status)
            claim.status = entity.status.value
        except InvalidClaimTransition as exc:
            logger.warning("risk_scoring_skipped_invalid_transition", claim_id=str(claim_id), error=str(exc))

        await self._audit.record(
            claim_id=claim.id,
            action="RISK_SCORED",
            metadata={"score": str(assessment.score), "tier": assessment.tier, "new_status": claim.status},
        )
        await self._session.commit()
        logger.info("risk_scoring_completed", claim_id=str(claim_id), score=assessment.score, tier=assessment.tier)
