"""
Claim service — orchestrates claim submission and retrieval.

Note what this class does NOT do: it doesn't run a SQL query directly, and
it doesn't know about S3 or Celery internals beyond calling an injected
task-enqueue function. That's the seam that lets you unit-test this service
by passing in a fake repository and a no-op enqueue callable.
"""
from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import BinaryIO
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.metrics import claims_submitted_total
from app.domain.exceptions import ClaimNotFoundError, PolicyNotFoundError
from app.domain.value_objects.upload_rules import (
    MAX_DOCUMENTS_PER_CLAIM,
    TooManyFilesError,
    validate_upload,
)
from app.infrastructure.db.models import Claim, Document, Policy
from app.infrastructure.storage.s3_client import StorageClient, generate_document_key
from app.repositories.claim_repository import ClaimRepository
from app.schemas.claim import ClaimCreateRequest, ClaimSubmittedResponse


@dataclass
class IncomingFile:
    filename: str
    content_type: str
    size: int
    stream: BinaryIO


class ClaimService:
    def __init__(
        self,
        session: AsyncSession,
        claim_repo: ClaimRepository,
        storage_client: StorageClient | None = None,
        enqueue_extraction: Callable[[str], None] | None = None,
    ):
        self._session = session
        self._claim_repo = claim_repo
        self._storage = storage_client
        # Injected so tests can pass a no-op / mock instead of hitting real Celery.
        self._enqueue_extraction = enqueue_extraction or (lambda claim_id: None)

    async def submit_claim(
        self, payload: ClaimCreateRequest, files: list[IncomingFile]
    ) -> ClaimSubmittedResponse:
        if len(files) > MAX_DOCUMENTS_PER_CLAIM:
            raise TooManyFilesError(len(files))
        for f in files:
            validate_upload(f.filename, f.content_type, f.size)

        policy = (
            await self._session.execute(
                select(Policy).where(Policy.policy_number == payload.policy_number)
            )
        ).scalar_one_or_none()
        if not policy:
            raise PolicyNotFoundError(payload.policy_number)

        claim = Claim(
            policy_id=policy.id,
            claimed_amount=Decimal(payload.claimed_amount),
            status="SUBMITTED",
        )
        await self._claim_repo.add(claim)
        await self._session.flush()  # ensure claim.id is populated before we key documents to it

        for f in files:
            storage_path = self._store_file(claim.id, f)
            doc = Document(claim_id=claim.id, document_type=f.content_type, storage_path=storage_path)
            self._session.add(doc)

        await self._claim_repo.commit()
        claims_submitted_total.inc()

        # Fire-and-forget enqueue — the actual OCR/LLM work happens in a Celery worker.
        self._enqueue_extraction(str(claim.id))

        return ClaimSubmittedResponse(
            claim_id=str(claim.id),
            status=claim.status,
            documents_received=len(files),
        )

    def _store_file(self, claim_id: UUID, f: IncomingFile) -> str:
        """
        Returns the raw storage KEY (e.g. "claims/<id>/<uuid>.pdf"), not the
        upload() return value. upload() returns a display-friendly URI
        ("s3://bucket/key") for logging, but download() and
        get_presigned_url() both take a bare key — storing the URI here
        would break every subsequent read of this document.
        """
        key = generate_document_key(str(claim_id), f.filename)
        if not self._storage:
            # No storage client wired (e.g. some unit tests) — record intent without a real upload.
            return key
        self._storage.upload(f.stream, key, f.content_type)
        return key

    async def get_claim(self, claim_id: UUID) -> Claim:
        claim = await self._claim_repo.get_with_relations(claim_id)
        if not claim:
            raise ClaimNotFoundError(str(claim_id))
        return claim

    async def list_claims(self, *, status: str | None, page: int, size: int):
        return await self._claim_repo.list_filtered(status=status, page=page, size=size)
