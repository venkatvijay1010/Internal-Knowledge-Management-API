# Architecture

Full architecture (Mermaid diagrams, ER diagram, folder structure, deployment
topology) lives in `ClaimForge-AI-Design.md` at the repo root — copy or
symlink it here (`docs/mkdocs/docs/architecture.md`) when publishing the
MkDocs site so it renders alongside the API reference.
