# ClaimForge AI

AI-native insurance claims intelligence platform. See the main repository
README for quick start instructions, and `architecture.md` / `api.md` in this
docs site for the full system design (originally delivered as
`ClaimForge-AI-Design.md`).
