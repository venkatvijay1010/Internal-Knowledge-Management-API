"""
Dev/local seed script. Run inside the api container after migrations:

    docker compose -f docker/docker-compose.yml exec api python -m scripts.seed_dev_data

Creates one Policy row (POL-001) so the README's curl walkthrough has a
policy_number that actually exists to submit a claim against. Not run
automatically — deliberately a manual step so it's never accidentally
invoked against a real environment.
"""
import asyncio
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import select

from app.core.security import hash_password
from app.infrastructure.db.models import Policy, User
from app.infrastructure.db.session import AsyncSessionLocal


async def seed() -> None:
    async with AsyncSessionLocal() as session:
        existing_policy = (
            await session.execute(select(Policy).where(Policy.policy_number == "POL-001"))
        ).scalar_one_or_none()
        if not existing_policy:
            session.add(
                Policy(
                    policy_number="POL-001",
                    policyholder_name="Dev Test Policyholder",
                    coverage_limit=Decimal("50000.00"),
                    effective_date=datetime.now(timezone.utc) - timedelta(days=30),
                    expiry_date=datetime.now(timezone.utc) + timedelta(days=335),
                )
            )
            print("Seeded policy POL-001 (coverage limit $50,000).")
        else:
            print("POL-001 already exists, skipping.")

        existing_admin = (
            await session.execute(select(User).where(User.email == "admin@claimforge.dev"))
        ).scalar_one_or_none()
        if not existing_admin:
            session.add(
                User(
                    email="admin@claimforge.dev",
                    hashed_password=hash_password("devpassword123"),
                    full_name="Dev Admin",
                    role="admin",
                    is_active=True,
                    is_verified=True,  # pre-verified — skips the email step for local dev only
                )
            )
            print("Seeded admin@claimforge.dev / devpassword123 (dev only — pre-verified, do not use this pattern in prod).")
        else:
            print("admin@claimforge.dev already exists, skipping.")

        await session.commit()


if __name__ == "__main__":
    asyncio.run(seed())
