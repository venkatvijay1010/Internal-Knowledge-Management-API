"""
API test against the real FastAPI app object via HTTPX's ASGI transport.
`test_liveness` needs nothing but the app object. `test_readiness_and_full_flow`
needs a live Postgres/Redis (the docker-compose stack) and is skipped by
default in CI's unit-only run — wire it into a separate `integration` CI job
once a test database is provisioned, per the Week 11 testing plan.
"""
import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.mark.asyncio
async def test_liveness_endpoint():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


@pytest.mark.asyncio
@pytest.mark.skip(reason="Requires a live Postgres + Redis — run against docker-compose stack, not in unit CI")
async def test_full_claim_submission_flow():
    """
    Documents the intended integration test shape for Week 11:
    1. POST /api/v1/auth/register + /login to get a token
    2. POST /api/v1/claims with a real policy_number fixture + a small PDF
    3. GET /api/v1/claims/{id} and assert status starts as SUBMITTED
    4. (with Celery in eager mode) assert status progresses to REVIEW/FLAGGED
    5. GET /api/v1/claims/{id}/audit-log and assert entries were written
    """
