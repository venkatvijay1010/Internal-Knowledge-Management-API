"""
Factory Boy factories for the ORM models. Used by integration tests that
need real rows (e.g. a Policy row for a claim submission test) without
hand-writing the same boilerplate object construction in every test.

These build plain model instances — they don't persist themselves. Tests
add() + commit() them via whatever session fixture is in scope, so the same
factory works whether the test uses a real Postgres session or (in a future
lightweight-test setup) an in-memory one.
"""
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import factory

from app.core.security import hash_password
from app.infrastructure.db.models import Claim, Document, Policy, User


class UserFactory(factory.Factory):
    class Meta:
        model = User

    email = factory.Sequence(lambda n: f"adjuster{n}@claimforge.test")
    hashed_password = factory.LazyFunction(lambda: hash_password("testpassword123"))
    full_name = factory.Faker("name")
    role = "adjuster"
    is_active = True
    is_verified = True  # verified by default so login-flow tests don't need the email step


class PolicyFactory(factory.Factory):
    class Meta:
        model = Policy

    policy_number = factory.Sequence(lambda n: f"POL-TEST-{n:06d}")
    policyholder_name = factory.Faker("name")
    coverage_limit = Decimal("50000.00")
    effective_date = factory.LazyFunction(lambda: datetime.now(timezone.utc) - timedelta(days=30))
    expiry_date = factory.LazyFunction(lambda: datetime.now(timezone.utc) + timedelta(days=335))


class ClaimFactory(factory.Factory):
    class Meta:
        model = Claim

    claimed_amount = Decimal("1500.00")
    status = "SUBMITTED"


class DocumentFactory(factory.Factory):
    class Meta:
        model = Document

    document_type = "application/pdf"
    storage_path = factory.Sequence(lambda n: f"claims/test/{n}.pdf")
    ocr_status = "PENDING"
