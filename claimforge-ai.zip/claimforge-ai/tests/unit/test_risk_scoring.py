from decimal import Decimal

from app.domain.entities.risk_score import assess_claim_risk


def test_low_risk_claim_scores_low_tier():
    result = assess_claim_risk(
        claimed_amount=Decimal("500"),
        policy_coverage_limit=Decimal("50000"),
        avg_extraction_confidence=0.95,
        documents_missing_required_fields=0,
        duplicate_claim_count=0,
    )
    assert result.tier == "LOW"
    assert result.score == 0.0


def test_claim_exceeding_coverage_limit_is_high_risk():
    result = assess_claim_risk(
        claimed_amount=Decimal("60000"),
        policy_coverage_limit=Decimal("50000"),
        avg_extraction_confidence=0.9,
        documents_missing_required_fields=0,
        duplicate_claim_count=0,
    )
    assert result.tier == "HIGH"
    triggered = {s.name for s in result.signals if s.triggered}
    assert "claim_exceeds_coverage_limit" in triggered


def test_low_confidence_and_duplicates_combine_to_medium_or_higher():
    result = assess_claim_risk(
        claimed_amount=Decimal("2000"),
        policy_coverage_limit=Decimal("50000"),
        avg_extraction_confidence=0.4,
        documents_missing_required_fields=1,
        duplicate_claim_count=1,
    )
    # low_confidence(20) + missing_fields(15) + duplicate(25) = 60 -> MEDIUM tier band
    assert result.score == 60.0
    assert result.tier == "MEDIUM"


def test_score_is_capped_at_100():
    result = assess_claim_risk(
        claimed_amount=Decimal("999999"),
        policy_coverage_limit=Decimal("1000"),
        avg_extraction_confidence=0.0,
        documents_missing_required_fields=5,
        duplicate_claim_count=3,
    )
    assert result.score <= 100.0
    assert result.tier == "HIGH"
