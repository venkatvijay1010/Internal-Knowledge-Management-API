"""
Demonstrates the payoff of the Repository Pattern: ClaimService is tested here
with a mocked ClaimRepository and a mocked AsyncSession — no Postgres running,
runs in milliseconds, and would run identically in CI without a db service.
"""
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from app.domain.exceptions import PolicyNotFoundError
from app.schemas.claim import ClaimCreateRequest
from app.services.claim_service import ClaimService


@pytest.mark.asyncio
async def test_submit_claim_raises_when_policy_not_found():
    mock_session = MagicMock()
    mock_result = MagicMock()
    mock_result.scalar_one_or_none.return_value = None  # policy lookup returns nothing
    mock_session.execute = AsyncMock(return_value=mock_result)

    mock_claim_repo = MagicMock()
    service = ClaimService(mock_session, mock_claim_repo, enqueue_extraction=MagicMock())

    payload = ClaimCreateRequest(policy_number="DOES-NOT-EXIST", claimed_amount=Decimal("1000"))

    with pytest.raises(PolicyNotFoundError):
        await service.submit_claim(payload, files=[])


@pytest.mark.asyncio
async def test_submit_claim_enqueues_extraction_on_success():
    fake_policy = MagicMock(id=uuid4())
    mock_session = MagicMock()
    mock_result = MagicMock()
    mock_result.scalar_one_or_none.return_value = fake_policy
    mock_session.execute = AsyncMock(return_value=mock_result)

    mock_session.flush = AsyncMock()
    mock_session.add = MagicMock()

    mock_claim_repo = MagicMock()
    mock_claim_repo.add = AsyncMock(side_effect=lambda claim: claim)
    mock_claim_repo.commit = AsyncMock()

    enqueue_mock = MagicMock()
    service = ClaimService(mock_session, mock_claim_repo, enqueue_extraction=enqueue_mock)

    payload = ClaimCreateRequest(policy_number="POL-001", claimed_amount=Decimal("2500"))
    response = await service.submit_claim(payload, files=[])

    assert response.status == "SUBMITTED"
    assert response.documents_received == 0
    enqueue_mock.assert_called_once()
