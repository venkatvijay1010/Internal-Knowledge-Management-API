"""
These tests need no database, no FastAPI, no Celery — pure domain logic,
which is exactly what living in app/domain/ with zero framework imports buys you.
"""
from decimal import Decimal
from uuid import uuid4

import pytest

from app.domain.entities.claim import ClaimEntity, ClaimStatus, InvalidClaimTransition


def make_claim(status: ClaimStatus = ClaimStatus.SUBMITTED) -> ClaimEntity:
    return ClaimEntity(id=uuid4(), policy_id=uuid4(), claimed_amount=Decimal("500"), status=status)


def test_valid_transition_submitted_to_processing():
    claim = make_claim(ClaimStatus.SUBMITTED)
    claim.transition_to(ClaimStatus.PROCESSING)
    assert claim.status == ClaimStatus.PROCESSING


def test_invalid_transition_submitted_to_approved_raises():
    claim = make_claim(ClaimStatus.SUBMITTED)
    with pytest.raises(InvalidClaimTransition):
        claim.transition_to(ClaimStatus.APPROVED)


def test_terminal_states_have_no_valid_transitions():
    claim = make_claim(ClaimStatus.APPROVED)
    with pytest.raises(InvalidClaimTransition):
        claim.transition_to(ClaimStatus.REVIEW)


def test_high_value_threshold():
    small_claim = make_claim()
    small_claim.claimed_amount = Decimal("500")
    assert not small_claim.is_high_value()

    large_claim = make_claim()
    large_claim.claimed_amount = Decimal("15000")
    assert large_claim.is_high_value()
