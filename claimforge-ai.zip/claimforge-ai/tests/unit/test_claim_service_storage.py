"""
Regression test for a real bug caught during review: _store_file was
persisting the storage adapter's display URI (e.g. "s3://bucket/key")
instead of the bare key that download()/get_presigned_url() actually
expect. This test locks in the fix.
"""
from decimal import Decimal
from unittest.mock import MagicMock
from uuid import uuid4

from app.services.claim_service import ClaimService, IncomingFile


def test_store_file_persists_bare_key_not_upload_uri():
    mock_storage = MagicMock()
    # Simulate an S3-style adapter whose upload() returns a display URI —
    # the service must NOT persist this return value as storage_path.
    mock_storage.upload.return_value = "s3://some-bucket/claims/abc/xyz.pdf"

    service = ClaimService(session=MagicMock(), claim_repo=MagicMock(), storage_client=mock_storage)

    incoming = IncomingFile(
        filename="invoice.pdf", content_type="application/pdf", size=1024, stream=MagicMock()
    )
    stored_key = service._store_file(uuid4(), incoming)

    assert not stored_key.startswith("s3://"), (
        "storage_path must be a bare key, not the adapter's display URI — "
        "download() and get_presigned_url() both take a bare key as input"
    )
    assert stored_key.endswith(".pdf")
    mock_storage.upload.assert_called_once()


def test_store_file_without_storage_client_still_returns_a_bare_key():
    service = ClaimService(session=MagicMock(), claim_repo=MagicMock(), storage_client=None)
    incoming = IncomingFile(
        filename="bill.jpg", content_type="image/jpeg", size=512, stream=MagicMock()
    )
    stored_key = service._store_file(uuid4(), incoming)
    assert not stored_key.startswith("s3://")
    assert not stored_key.startswith("unstored://")
